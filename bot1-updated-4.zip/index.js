require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const loadCommands = require('./handlers/loadCommands');
const loadEvents = require('./handlers/loadEvents');
const startScheduler = require('./utils/scheduler');
const { registerFonts } = require('./utils/fonts');

registerFonts();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildExpressions
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember]
});

client.commands = new Collection();
client.aliases = new Collection();
client.invitesCache = new Collection();
client.voiceJoinTimestamps = new Collection();

loadCommands(client);
loadEvents(client);

console.log('🚀 جاري تشغيل البوت...');

// Validate token before login
const token = process.env.TOKEN;
if (!token || token === 'your_bot_token_here' || token.length < 50) {
  console.error('❌ TOKEN مش موجود أو غلط!');
  console.error('🔧 الحل: روح Discord Developer Portal → Bot → Reset Token → انسخ التوكن وحطه في ملف .env');
  process.exit(1);
}

client.login(token)
  .then(() => {
    console.log('✅ تم الاتصال بـ Discord Gateway');
  })
  .catch(err => {
    console.error('❌ فشل تسجيل الدخول:');
    console.error(err.message || err);
    if (err.code === 'TokenInvalid') {
      console.error('🔧 الحل: التوكن غلط. جيب توكن جديد من Discord Developer Portal');
    } else if (err.code === 'DisallowedIntents') {
      console.error('🔧 الحل: فعّل الـ Privileged Gateway Intents في Discord Developer Portal');
    }
    process.exit(1);
  });

// حماية من كراش
process.on('unhandledRejection', err => console.error('Unhandled Rejection:', err));
process.on('uncaughtException', err => console.error('Uncaught Exception:', err));

const db = require('./utils/db');
function gracefulShutdown() {
  db.flushAll();
  process.exit(0);
}
process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);
