const { sendLog, mentionWithId } = require('../utils/logs');

// ملاحظة مهمة: إيفنت voiceChannelEffectSend بيتبعت من ديسكورد بس للرومات الصوتية
// اللي "البوت نفسه" داخلها فعليًا في نفس اللحظة. البوت ده مش بينضم لرومات صوتية
// (مفيهوش نظام موسيقى/فويس كونكشن)، فعمليًا الإيفنت مش هيتسجل لحد ما البوت
// يبقى موجود جوه الروم وقت حد بيدوس ساوند بورد. سايبه هنا شغال لو البوت
// اتضاف له فويس كونكشن في المستقبل.
module.exports = {
  name: 'voiceChannelEffectSend',
  async execute(effect, client) {
    // بنسجل بس لو كان صوت ساوند بورد فعلي (مش مجرد إيموجي رياكشن عادي)
    if (!effect.soundId) return;

    const guild = effect.guild;
    if (!guild) return;
    const channel = effect.channel || guild.channels.cache.get(effect.channelId);

    sendLog(guild, 'logvoice', {
      title: '🔈 استخدام ساوند بورد',
      fields: [
        { name: 'العضو', value: mentionWithId(effect.userId), inline: true },
        { name: 'الروم', value: channel ? `${channel}` : 'غير معروف', inline: true }
      ]
    });
  }
};
