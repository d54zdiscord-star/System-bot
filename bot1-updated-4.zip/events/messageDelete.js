const { sendDetailedLog, mentionWithId } = require('../utils/logs');

async function getAboveMessageLink(message) {
  try {
    const before = await message.channel.messages.fetch({ limit: 1, before: message.id });
    const aboveMsg = before.first();
    if (!aboveMsg) return null;
    return `https://discord.com/channels/${message.guild.id}/${message.channel.id}/${aboveMsg.id}`;
  } catch {
    return null;
  }
}

module.exports = {
  name: 'messageDelete',
  async execute(message) {
    if (!message.guild) return;
    const author = message.author || null;
    if (author?.bot) return;

    const aboveLink = await getAboveMessageLink(message);

    if (message.attachments && message.attachments.size > 0) {
      for (const attachment of message.attachments.values()) {
        if (attachment.contentType?.startsWith('image/') || attachment.contentType?.startsWith('video/')) {
          const extraFields = [
            { name: '👤 المرسل', value: author ? mentionWithId(author) : 'غير معروف', inline: true },
            { name: '📢 الروم', value: `<#${message.channel.id}> | \`${message.channel.id}\``, inline: true },
            { name: '📎 النوع', value: `\`${attachment.contentType}\``, inline: true },
            { name: '📏 الحجم', value: `\`${(attachment.size / 1024).toFixed(1)} KB\``, inline: true }
          ];
          if (aboveLink) extraFields.push({ name: '🔗 الرسالة السابقة', value: `[اضغط هنا](${aboveLink})`, inline: true });

          await sendDetailedLog(message.guild, 'logpic', {
            title: '🗑️ حذف مرفق',
            iconKey: 'attachment_delete',
            extraFields,
            image: attachment.url
          });
        }
      }
      return;
    }

    const extraFields = [
      { name: '👤 المرسل', value: author ? mentionWithId(author) : 'غير معروف', inline: true },
      { name: '📢 الروم', value: `<#${message.channel.id}> | \`${message.channel.id}\``, inline: true }
    ];
    if (aboveLink) extraFields.push({ name: '🔗 الرسالة السابقة', value: `[اضغط هنا](${aboveLink})`, inline: true });
    extraFields.push({ name: '📝 المحتوى', value: '```' + (message.content ? message.content.slice(0, 800) : 'مفيش نص') + '```' });

    await sendDetailedLog(message.guild, 'channelmessage', {
      title: '🗑️ حذف رسالة',
      iconKey: 'message_delete',
      extraFields
    });
  }
};
