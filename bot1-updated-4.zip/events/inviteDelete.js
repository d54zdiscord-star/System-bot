module.exports = {
  name: 'inviteDelete',
  async execute(invite, client) {
    const map = client.invitesCache.get(invite.guild.id);
    if (map) map.delete(invite.code);
  }
};
