const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor, getInviter, buildLeaveButtons, mentionWithId } = require('../utils/logs');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member) {
    if (member.user.bot) {
      await sendDetailedLog(member.guild, 'logbots', {
        title: '🤖 مغادرة بوت',
        iconKey: 'bot_leave',
        target: member.user,
        extraFields: [
          { name: '📅 تاريخ إنشاء الحساب', value: `<t:${Math.floor(member.user.createdAt.getTime() / 1000)}:R>`, inline: true }
        ]
      });
      return;
    }

    const joinedTs = member.joinedTimestamp ? Math.floor(member.joinedTimestamp / 1000) : null;
    const inviteInfo = getInviter(member.guild, member.id);

    const kickExecutor = await getAuditExecutor(member.guild, AuditLogEvent.MemberKick, member.id);
    const banExecutor = kickExecutor ? null : await getAuditExecutor(member.guild, AuditLogEvent.MemberBanAdd, member.id);

    const extraFields = [];
    if (joinedTs) extraFields.push({ name: '📅 دخل السيرفر', value: `<t:${joinedTs}:F> (<t:${joinedTs}:R>)`, inline: true });
    if (inviteInfo) {
      extraFields.push({ 
        name: '📨 الدعوة', 
        value: `discord.gg/${inviteInfo.inviteCode || '؟'}
بواسطة: ${inviteInfo.inviterId ? `<@${inviteInfo.inviterId}> | \`${inviteInfo.inviterId}\`` : 'غير معروف'}`, 
        inline: true 
      });
    } else {
      extraFields.push({ name: '📨 الدعوة', value: 'غير معروفة', inline: true });
    }

    extraFields.push({ name: '👥 عدد الأعضاء', value: `\`${member.guild.memberCount}\``, inline: true });

    let title = '❌ مغادرة عضو';
    let iconKey;
    if (kickExecutor) {
      title = '👢 طرد';
      iconKey = 'kick';
      extraFields.push({ name: '🛡️ الطارد', value: `<@${kickExecutor.id}> | \`${kickExecutor.id}\``, inline: true });
    } else if (banExecutor) {
      title = '🔨 حظر';
      iconKey = 'ban';
      extraFields.push({ name: '🛡️ الحاظر', value: `<@${banExecutor.id}> | \`${banExecutor.id}\``, inline: true });
    }

    await sendDetailedLog(member.guild, 'logjoinleave', {
      title,
      iconKey,
      target: member.user,
      extraFields,
      thumbnail: member.user.displayAvatarURL({ size: 1024 })
    }, { components: [buildLeaveButtons(member.id)] });
  }
};
