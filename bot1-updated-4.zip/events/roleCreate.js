const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

module.exports = {
  name: 'roleCreate',
  async execute(role) {
    const executor = await getAuditExecutor(role.guild, AuditLogEvent.RoleCreate, role.id);
    if (!executor) return;

    await sendDetailedLog(role.guild, 'logroles', {
      title: '🎭 إنشاء رول',
      executor,
      extraFields: [
        { name: '🎭 الرول', value: `<@&${role.id}> | \`${role.id}\``, inline: true },
        { name: '🎨 اللون', value: `\`${role.hexColor}\``, inline: true },
        { name: '👥 عدد الأعضاء', value: `\`${role.members.size}\``, inline: true },
        { name: '🔢 الموضع', value: `\`${role.position}\``, inline: true },
        { name: '👀 يظهر بشكل منفصل', value: role.hoist ? '✅ نعم' : '❌ لا', inline: true },
        { name: '🔒 ممنوع المنشن', value: role.mentionable ? '❌ لا' : '✅ نعم', inline: true }
      ]
    });
  }
};
