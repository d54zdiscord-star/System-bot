const { AuditLogEvent, PermissionsBitField } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

function getPermissionChanges(oldRole, newRole) {
  const changes = [];
  if (oldRole.name !== newRole.name) changes.push(`📛 الاسم: \`${oldRole.name}\` → \`${newRole.name}\``);
  if (oldRole.hexColor !== newRole.hexColor) changes.push(`🎨 اللون: \`${oldRole.hexColor}\` → \`${newRole.hexColor}\``);
  if (oldRole.hoist !== newRole.hoist) changes.push(`👀 يظهر منفصل: \`${oldRole.hoist ? 'نعم' : 'لا'}\` → \`${newRole.hoist ? 'نعم' : 'لا'}\``);
  if (oldRole.mentionable !== newRole.mentionable) changes.push(`🔔 يمكن المنشن: \`${oldRole.mentionable ? 'نعم' : 'لا'}\` → \`${newRole.mentionable ? 'نعم' : 'لا'}\``);

  // Detailed permission changes
  const oldPerms = oldRole.permissions.toArray();
  const newPerms = newRole.permissions.toArray();
  const added = newPerms.filter(p => !oldPerms.includes(p));
  const removed = oldPerms.filter(p => !newPerms.includes(p));

  if (added.length) changes.push(`✅ **صلاحيات مضافة:** ${added.map(p => `\`${p}\``).join(', ')}`);
  if (removed.length) changes.push(`❌ **صلاحيات محذوفة:** ${removed.map(p => `\`${p}\``).join(', ')}`);

  return changes;
}

module.exports = {
  name: 'roleUpdate',
  async execute(oldRole, newRole) {
    const executor = await getAuditExecutor(newRole.guild, AuditLogEvent.RoleUpdate, newRole.id);
    if (!executor) return;

    const changes = getPermissionChanges(oldRole, newRole);
    if (!changes.length) return;

    await sendDetailedLog(newRole.guild, 'logroles', {
      title: '🎭 تعديل رول',
      executor,
      extraFields: [
        { name: '🎭 الرول', value: `<@&${newRole.id}> | \`${newRole.id}\``, inline: true },
        { name: '📝 التغييرات', value: changes.map(c => `• ${c}`).join('\n') }
      ]
    });
  }
};
