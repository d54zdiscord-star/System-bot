const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor, mentionWithId } = require('../utils/logs');

module.exports = {
  name: 'guildBanRemove',
  async execute(ban, client) {
    try {
      const executor = await getAuditExecutor(ban.guild, AuditLogEvent.MemberBanRemove, ban.user.id);
      if (!executor || executor.id === client.user.id) return;

      await sendDetailedLog(ban.guild, 'logbanunban', {
        title: '🔓 فك باند عضو',
        executor,
        target: ban.user,
        thumbnail: ban.user.displayAvatarURL({ extension: 'png', forceStatic: true, size: 1024 })
      });
    } catch (e) {
      console.error('[guildBanRemove log]', e.message);
    }
  }
};
