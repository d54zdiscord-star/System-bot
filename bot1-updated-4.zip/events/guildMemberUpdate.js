const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

module.exports = {
  name: 'guildMemberUpdate',
  async execute(oldMember, newMember) {
    const guild = newMember.guild;

    // Check for role changes
    const oldRoles = oldMember.roles.cache;
    const newRoles = newMember.roles.cache;

    const addedRoles = newRoles.filter(r => !oldRoles.has(r.id) && r.id !== guild.id);
    const removedRoles = oldRoles.filter(r => !newRoles.has(r.id) && r.id !== guild.id);

    if (addedRoles.size > 0) {
      const executor = await getAuditExecutor(guild, AuditLogEvent.MemberRoleUpdate, newMember.id);
      for (const role of addedRoles.values()) {
        await sendDetailedLog(guild, 'logroles', {
          title: '➕ إعطاء رول',
          iconKey: 'role_add',
          executor: executor || undefined,
          target: newMember.user,
          extraFields: [
            { name: '🎨 الرول', value: `<@&${role.id}> | \`${role.id}\``, inline: true },
            { name: '🖌️ اللون', value: `\`${role.hexColor}\``, inline: true },
            { name: '👥 أعضاء الرول', value: `\`${role.members.size}\``, inline: true }
          ]
        });
      }
    }

    if (removedRoles.size > 0) {
      const executor = await getAuditExecutor(guild, AuditLogEvent.MemberRoleUpdate, newMember.id);
      for (const role of removedRoles.values()) {
        await sendDetailedLog(guild, 'logroles', {
          title: '➖ إزالة رول',
          iconKey: 'role_remove',
          executor: executor || undefined,
          target: newMember.user,
          extraFields: [
            { name: '🎨 الرول', value: `\`${role.name}\` | \`${role.id}\``, inline: true },
            { name: '🖌️ اللون', value: `\`${role.hexColor}\``, inline: true }
          ]
        });
      }
    }

    // Check for nickname changes
    if (oldMember.nickname !== newMember.nickname) {
      const executor = await getAuditExecutor(guild, AuditLogEvent.MemberUpdate, newMember.id);
      if (executor && oldMember.nickname !== newMember.nickname) {
        await sendDetailedLog(guild, 'lognickname', {
          title: '✏️ تغيير كنية',
          iconKey: 'nickname',
          executor,
          target: newMember.user,
          extraFields: [
            { name: '📤 القديم', value: oldMember.nickname ? `\`${oldMember.nickname}\`` : 'بدون', inline: true },
            { name: '📥 الجديد', value: newMember.nickname ? `\`${newMember.nickname}\`` : 'بدون', inline: true }
          ]
        });
      }
    }

    // Check for timeout changes
    if (!oldMember.isCommunicationDisabled() && newMember.isCommunicationDisabled()) {
      const executor = await getAuditExecutor(guild, AuditLogEvent.MemberUpdate, newMember.id);
      await sendDetailedLog(guild, 'logmute', {
        title: '🔇 تايم اوت',
        executor: executor || undefined,
        target: newMember.user,
        extraFields: [
          { name: '⏱️ ينتهي', value: `<t:${Math.floor(newMember.communicationDisabledUntilTimestamp / 1000)}:R>`, inline: true }
        ]
      });
    }

    if (oldMember.isCommunicationDisabled() && !newMember.isCommunicationDisabled()) {
      const executor = await getAuditExecutor(guild, AuditLogEvent.MemberUpdate, newMember.id);
      await sendDetailedLog(guild, 'logmute', {
        title: '🔊 فك تايم',
        executor: executor || undefined,
        target: newMember.user
      });
    }
  }
};
