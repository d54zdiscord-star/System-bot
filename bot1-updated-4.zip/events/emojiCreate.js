const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

module.exports = {
  name: 'emojiCreate',
  async execute(emoji, client) {
    const executor = await getAuditExecutor(emoji.guild, AuditLogEvent.EmojiCreate, emoji.id);
    if (!executor || executor.id === client.user.id) return;

    await sendDetailedLog(emoji.guild, 'logemoji', {
      title: '➕ إضافة إيموجي',
      iconKey: 'emoji_create',
      executor,
      extraFields: [
        { name: '😀 الإيموجي', value: `${emoji} | \`:${emoji.name}:\``, inline: true },
        { name: '🆔 ID', value: `\`${emoji.id}\``, inline: true },
        { name: '📊 العدد', value: `\`${emoji.guild.emojis.cache.size}\``, inline: true },
        { name: '🔗 الرابط', value: `[فتح الإيموجي](${emoji.url})` },
        { name: '🎬 متحرك', value: emoji.animated ? '✅ نعم' : '❌ لا', inline: true }
      ],
      thumbnail: emoji.url
    });
  }
};
