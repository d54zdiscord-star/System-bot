const db = require('../utils/db');
const { baseEmbed, V2_FLAGS } = require('../utils/embed');
const { AttachmentBuilder, AuditLogEvent } = require('discord.js');
const { getWelcomeImageBuffer } = require('../utils/welcomeImage');
const { sendDetailedLog, getAuditExecutor, markJoinAndCheckRejoin, saveInviter, buildJoinButtons, mentionWithId } = require('../utils/logs');

async function findInviter(guild, client) {
  try {
    const newInvites = await guild.invites.fetch();
    const oldMap = client.invitesCache.get(guild.id) || new Map();
    let usedInvite = null;

    for (const inv of newInvites.values()) {
      const oldUses = oldMap.get(inv.code) || 0;
      if ((inv.uses || 0) > oldUses) {
        usedInvite = inv;
        break;
      }
    }

    client.invitesCache.set(guild.id, new Map(newInvites.map(inv => [inv.code, inv.uses || 0])));
    return usedInvite;
  } catch {
    return null;
  }
}

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    const guild = member.guild;
    const data = db.get(guild.id);

    // ---- تتبع الدعوات ----
    const usedInvite = await findInviter(guild, client);
    const inviter = usedInvite?.inviter || null;
    if (inviter) {
      data.settings.invites = data.settings.invites || {};
      data.settings.invites[inviter.id] = (data.settings.invites[inviter.id] || 0) + 1;
      db.commit(guild.id);
    }
    saveInviter(guild, member.id, inviter ? inviter.id : null, usedInvite ? usedInvite.code : null);

    // ---- لوق انضمام البوت ----
    if (member.user.bot) {
      const executor = await getAuditExecutor(guild, AuditLogEvent.BotAdd, member.user.id);
      const allBots = guild.members.cache.filter(m => m.user.bot).size;
      const inviteLink = `https://discord.com/api/oauth2/authorize?client_id=${member.user.id}&permissions=0&scope=bot`;
      sendDetailedLog(guild, 'logbots', {
        title: '🤖 إضافة البوت',
        executor: executor || undefined,
        target: member.user,
        extraFields: [
            { name: '🔗 رابط البوت', value: `[انقر هنا](${inviteLink})`, inline: true },
          { name: '📊 عدد البوتات', value: `\`${allBots}\``, inline: true }
        ]
      });
    } else {
      // ---- لوق انضمام العضو (مفصّل) ----
      const rejoined = markJoinAndCheckRejoin(guild, member.id);
      const createdTs = Math.floor(member.user.createdAt.getTime() / 1000);

      const extraFields = [
        { name: '📊 عدد الأعضاء', value: `\`${guild.memberCount}\``, inline: true }
      ];
      if (rejoined) extraFields.push({ name: '⚠️ ملاحظة', value: '```🔁 الحساب ده دخل وخرج قبل كده```', inline: true });

      if (usedInvite) {
        extraFields.push({ 
          name: '🔗 دعوة', 
          value: `discord.gg/${usedInvite.code}
بواسطة: ${inviter ? `<@${inviter.id}> | \`${inviter.id}\`` : 'غير معروف'}`, 
          inline: true 
        });
      } else {
        extraFields.push({ name: '🔗 دعوة', value: 'غير معروف (دعوة مؤقتة أو نظام تاني)', inline: true });
      }

      const isJailed = !!(data.prisoners && data.prisoners[member.id] && data.prisoners[member.id].jailed);
      const isTimedOut = member.isCommunicationDisabled();
      await sendDetailedLog(guild, 'logjoinleave', {
        title: '🟢 انضمام عضو',
        target: member.user,
        extraFields,
        thumbnail: member.user.displayAvatarURL({ size: 1024 })
      }, { components: [buildJoinButtons(member.id, isJailed, isTimedOut)] });
    }

    // ---- سجن تلقائي ----
    const prisoner = data.prisoners[member.id];
    if (prisoner && prisoner.jailed) {
      let jailRole = guild.roles.cache.find(r => r.name === '⛓️│مسجون');
      if (!jailRole) {
        jailRole = await guild.roles.create({ name: '⛓️│مسجون', color: 'DarkerGrey' }).catch(() => null);
        if (jailRole) {
          for (const channel of guild.channels.cache.values()) {
            if (channel.isTextBased() || channel.isVoiceBased()) {
              channel.permissionOverwrites.edit(jailRole, { ViewChannel: false }).catch(() => {});
            }
          }
        }
      }
      if (jailRole) await member.roles.add(jailRole).catch(() => {});
    }

    // ---- رول تلقائي ----
    if (data.settings.autorole && !(prisoner && prisoner.jailed)) {
      const role = guild.roles.cache.get(data.settings.autorole);
      if (role) member.roles.add(role).catch(() => {});
    }

    // ---- رسالة الترحيب ----
    const wlc = data.settings.welcome;
    if (wlc.enabled && wlc.channelId) {
      const channel = guild.channels.cache.get(wlc.channelId);
      if (channel) {
        const text = (wlc.message || 'أهلاً بيك {user} في {servername}! إنت العضو رقم {membercount} 🎉')
          .replace(/\[user\]|\{user\}/g, `${member}`)
          .replace(/\[inviter\]|\{inviter\}/g, inviter ? `${inviter}` : 'غير معروف')
          .replace(/\[servername\]|\{servername\}/g, guild.name)
          .replace(/\[membercount\]|\{membercount\}/g, guild.memberCount);

        let files = [];
        let imageRef = null;
        if (wlc.imageExt) {
          const buffer = getWelcomeImageBuffer(guild.id, wlc.imageExt);
          if (buffer) {
            const filename = `welcome.${wlc.imageExt}`;
            files = [new AttachmentBuilder(buffer, { name: filename })];
            imageRef = `attachment://${filename}`;
          }
        }

        if (wlc.mode === 'text') {
          channel.send({ content: text, files }).catch(() => {});
        } else {
          const embed = baseEmbed({
            title: text,
            image: imageRef || undefined
          });
          channel.send({ components: [embed], files, flags: V2_FLAGS }).catch(() => {});
        }
      }
    }

    // ---- ويلكم دي إم ----
    if (wlc.dmEnabled && wlc.dmMessage) {
      const text = wlc.dmMessage
        .replace(/\[user\]|\{user\}/g, member.user.username)
        .replace(/\[servername\]|\{servername\}/g, guild.name)
        .replace(/\[membercount\]|\{membercount\}/g, guild.memberCount);
      member.send({ components: [baseEmbed({ description: text })], flags: V2_FLAGS }).catch(() => {});
    }
  }
};
