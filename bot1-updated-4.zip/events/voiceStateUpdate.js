const { PermissionsBitField, ChannelType, AuditLogEvent } = require('discord.js');
const db = require('../utils/db');
const { addVoiceXp } = require('../utils/leveling');
const { updateProgress } = require('../utils/tasks');
const { sendDetailedLog, getAuditExecutor, mentionWithId } = require('../utils/logs');

module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState, client) {
    const guild = newState.guild || oldState.guild;
    const data = db.get(guild.id);
    const member = newState.member || oldState.member;

    // ================= لوق الفويس =================
    if (!member.user.bot) {
      if (!oldState.channelId && newState.channelId) {
        // دخول فويس
        sendDetailedLog(guild, 'logvoice', {
          title: '🎤 دخول روم',
          iconKey: 'voice_join',
          target: member.user,
          channel: newState.channel,
          extraFields: [
            { name: '📍 الروم', value: `<#${newState.channel.id}> | \`${newState.channel.id}\``, inline: true },
            { name: '👥 الأعضاء', value: `\`${newState.channel.members.size}\``, inline: true }
          ]
        });
      } else if (oldState.channelId && !newState.channelId) {
        // خروج فويس
        const leftChannel = oldState.channel;
        getAuditExecutor(guild, AuditLogEvent.MemberDisconnect, member.id).then(executor => {
          if (executor && executor.id !== member.id) {
            sendDetailedLog(guild, 'logvoiceadmin', {
              title: '📵 فصل من الروم',
              iconKey: 'voice_disconnect',
              executor,
              target: member.user,
              channel: leftChannel,
              extraFields: [
                { name: '📍 من', value: `<#${leftChannel.id}> | \`${leftChannel.id}\``, inline: true }
              ]
            });
          } else {
            sendDetailedLog(guild, 'logvoice', {
              title: '👋 خروج من الروم',
              iconKey: 'voice_leave',
              target: member.user,
              channel: leftChannel,
              extraFields: [
                { name: '📍 من', value: `<#${leftChannel.id}> | \`${leftChannel.id}\``, inline: true }
              ]
            });
          }
        });
      } else if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
        // نقل بين رومات
        getAuditExecutor(guild, AuditLogEvent.MemberMove, member.id).then(executor => {
          if (executor && executor.id !== member.id) {
            sendDetailedLog(guild, 'logvoiceadmin', {
              title: '🔄 نقل عضو',
              iconKey: 'voice_move',
              executor,
              target: member.user,
              extraFields: [
                { name: '⬅️ من', value: `<#${oldState.channel.id}> | \`${oldState.channel.id}\``, inline: true },
                { name: '➡️ إلى', value: `<#${newState.channel.id}> | \`${newState.channel.id}\``, inline: true }
              ]
            });
          } else {
            sendDetailedLog(guild, 'logvoice', {
              title: '🔄 انتقال لروم',
              iconKey: 'voice_move',
              target: member.user,
              extraFields: [
                { name: '⬅️ من', value: `<#${oldState.channel.id}> | \`${oldState.channel.id}\``, inline: true },
                { name: '➡️ إلى', value: `<#${newState.channel.id}> | \`${newState.channel.id}\``, inline: true }
              ]
            });
          }
        });
      }

      // شير سكرين
      if (oldState.channelId && newState.channelId && oldState.streaming !== newState.streaming) {
        sendDetailedLog(guild, 'logvoice', {
          title: newState.streaming ? '🖥️ شير سكرين' : '🚫 إيقاف شير',
          target: member.user,
          channel: newState.channel,
          extraFields: [
            { name: '📍 الروم', value: `<#${newState.channel.id}> | \`${newState.channel.id}\``, inline: true }
          ]
        });
      }

      // كاميرا
      if (oldState.channelId && newState.channelId && oldState.selfVideo !== newState.selfVideo) {
        sendDetailedLog(guild, 'logvoice', {
          title: newState.selfVideo ? '📷 كاميرا مفتوحة' : '📵 كاميرا مقفولة',
          target: member.user,
          channel: newState.channel,
          extraFields: [
            { name: '📍 الروم', value: `<#${newState.channel.id}> | \`${newState.channel.id}\``, inline: true }
          ]
        });
      }

      // ميوت/ديفن من السيرفر
      if (oldState.channelId && newState.channelId) {
        if (oldState.serverMute !== newState.serverMute) {
          getAuditExecutor(guild, AuditLogEvent.MemberUpdate, member.id).then(executor => {
            if (executor && executor.id === client.user.id) return;
            sendDetailedLog(guild, 'logvoiceadmin', {
              title: newState.serverMute ? '🔇 ميوت صوتي' : '🔊 فك ميوت',
              executor: executor || undefined,
              target: member.user,
              channel: newState.channel,
              extraFields: [
                { name: '📍 الروم', value: `<#${newState.channel.id}> | \`${newState.channel.id}\``, inline: true }
              ]
            });
          });
        }
        if (oldState.serverDeaf !== newState.serverDeaf) {
          getAuditExecutor(guild, AuditLogEvent.MemberUpdate, member.id).then(executor => {
            if (executor && executor.id === client.user.id) return;
            sendDetailedLog(guild, 'logvoiceadmin', {
              title: newState.serverDeaf ? '🔕 ديفن' : '🔔 فك ديفن',
              executor: executor || undefined,
              target: member.user,
              channel: newState.channel,
              extraFields: [
                { name: '📍 الروم', value: `<#${newState.channel.id}> | \`${newState.channel.id}\``, inline: true }
              ]
            });
          });
        }
      }
    }

    // ================= نظام اللفلات - وقت الفويس =================
    const key = `${guild.id}-${(newState.member || oldState.member).id}`;
    if (!oldState.channel && newState.channel) {
      client.voiceJoinTimestamps.set(key, Date.now());
    } else if (oldState.channel && !newState.channel) {
      const joined = client.voiceJoinTimestamps.get(key);
      if (joined) {
        const minutes = Math.floor((Date.now() - joined) / 60000);
        if (minutes > 0) {
          if (data.leveling.enabled) addVoiceXp(guild, oldState.member, minutes).catch(() => {});
          if (data.tasks.enabled) updateProgress(client, guild.id, oldState.member.id, 'voice_mins', minutes).catch(() => {});
        }
      }
      client.voiceJoinTimestamps.delete(key);
    }

    // ================= نظام التمب فويس =================
    const tv = data.tempVoice;
    if (!tv.waitingChannelId || !tv.categoryId) return;

    if (newState.channelId === tv.waitingChannelId) {
      const member = newState.member;
      const category = guild.channels.cache.get(tv.categoryId);
      if (!category) {
        console.error(`[TempVoice] الكاتيقوري المحددة (${tv.categoryId}) في السيرفر ${guild.id} مش موجودة.`);
        return;
      }

      const me = guild.members.me;
      if (!me.permissionsIn(category).has(PermissionsBitField.Flags.ManageChannels)) {
        console.error(`[TempVoice] البوت مفيهوش صلاحية Manage Channels في السيرفر ${guild.id}.`);
        return member.send('<:fals:1533733827900473366> متقدرش أعمل روم مؤقت: البوت مفيهوش صلاحية "Manage Channels".').catch(() => {});
      }
      if (!me.permissionsIn(category).has(PermissionsBitField.Flags.ManageRoles)) {
        console.error(`[TempVoice] البوت مفيهوش صلاحية Manage Roles في السيرفر ${guild.id}.`);
        return member.send('<:fals:1533733827900473366> متقدرش أعمل روم مؤقت: البوت مفيهوش صلاحية "Manage Roles".').catch(() => {});
      }
      if (tv.untrustedRoleId) {
        const untrustedRole = guild.roles.cache.get(tv.untrustedRoleId);
        if (untrustedRole && untrustedRole.position >= me.roles.highest.position) {
          console.error(`[TempVoice] رول البوت أوطى من رول غير الموثق في السيرفر ${guild.id}.`);
          return member.send('<:fals:1533733827900473366> متقدرش أعمل روم مؤقت: رول البوت لازم يكون أعلى من رول غير الموثق.').catch(() => {});
        }
      }

      const voiceChannel = await guild.channels.create({
        name: `روم ${member.user.username}`,
        type: ChannelType.GuildVoice,
        parent: tv.categoryId,
        permissionOverwrites: [
          { id: guild.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect] },
          { id: member.id, allow: [PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.MoveMembers, PermissionsBitField.Flags.MuteMembers, PermissionsBitField.Flags.DeafenMembers] }
        ]
      }).catch(() => null);

      if (voiceChannel) {
        await member.voice.setChannel(voiceChannel).catch(() => {});
        if (tv.saveSettings) {
          data.tempVoice.userChannels = data.tempVoice.userChannels || {};
          data.tempVoice.userChannels[voiceChannel.id] = { ownerId: member.id, createdAt: Date.now() };
          db.commit(guild.id);
        }
      }
    }

    // حذف روم التمب فويس لما يفضى
    if (oldState.channel && oldState.channel.parentId === tv.categoryId && oldState.channel.id !== tv.waitingChannelId) {
      if (oldState.channel.members.size === 0) {
        const isUserChannel = data.tempVoice.userChannels?.[oldState.channel.id];
        if (isUserChannel) {
          await oldState.channel.delete().catch(() => {});
          delete data.tempVoice.userChannels[oldState.channel.id];
          db.commit(guild.id);
        }
      }
    }
  }
};
