const { MessageFlags } = require('discord.js');
const ticketInteractions = require('../handlers/interactions/tickets');
const tempVoiceInteractions = require('../handlers/interactions/tempvoice');
const tempVoiceConfigInteractions = require('../handlers/interactions/tempvoiceConfig');
const welcomeInteractions = require('../handlers/interactions/welcome');
const levelingInteractions = require('../handlers/interactions/leveling');
const secretInteractions = require('../handlers/interactions/secret');
const shopInteractions = require('../handlers/interactions/shop');
const profileInteractions = require('../handlers/interactions/profile');
const { buildGiveawayActive, endGiveaway } = require('../commands/giveaway/giveaway');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    try {
      const id = interaction.customId || '';

      // ── Giveaway Join Button ──
      if (id.startsWith('giveaway_join_')) {
        const msgId = id.slice('giveaway_join_'.length);
        const db = require('../utils/db');
        const { successEmbed, errorEmbed, V2_FLAGS } = require('../utils/embed');

        if (!interaction.guild) {
          return interaction.reply({ content: 'الزر ده مش شغال في DM.', ephemeral: true }).catch(() => {});
        }

        const data = db.get(interaction.guild.id);
        if (!data.giveaways) data.giveaways = {};

        let g = data.giveaways[msgId];

        // Fallback: try to recreate from message if data missing (host wiped data)
        if (!g) {
          try {
            const msg = await interaction.channel.messages.fetch(msgId).catch(() => null);
            if (msg && msg.author.id === client.user.id) {
              // Create minimal giveaway from message
              g = {
                messageId: msgId,
                channelId: interaction.channel.id,
                prize: 'جيفاوي',
                winners: 1,
                endTime: Date.now() + 60000,
                entries: [],
                ended: false,
                hostId: interaction.guild.ownerId,
                guildId: interaction.guild.id,
                winnerIds: []
              };
              data.giveaways[msgId] = g;
              db.commit(interaction.guild.id);
            }
          } catch {}
        }

        if (!g) {
          return interaction.reply({ components: [errorEmbed('الجيفاوي ده مش موجود أو اتمسح')], flags: V2_FLAGS | MessageFlags.Ephemeral }).catch(() => {});
        }
        if (g.ended) {
          return interaction.reply({ components: [errorEmbed('الجيفاوي ده خلاص انتهى')], flags: V2_FLAGS | MessageFlags.Ephemeral }).catch(() => {});
        }

        const wasJoined = g.entries.includes(interaction.user.id);

        if (wasJoined) {
          g.entries = g.entries.filter(e => e !== interaction.user.id);
        } else {
          g.entries.push(interaction.user.id);
        }
        db.commit(interaction.guild.id);

        // Update button count
        try {
          const channel = interaction.guild.channels.cache.get(g.channelId);
          if (channel) {
            const msg = await channel.messages.fetch(msgId).catch(() => null);
            if (msg) {
              const built = await buildGiveawayActive(g);
              await msg.edit(built);
            }
          }
        } catch (e) { console.error('[Giveaway] Edit error:', e); }

        const msg = wasJoined
          ? `تم إلغاء مشاركتك`
          : `تمت إضافتك للمشاركة في **${g.prize}**`;
        return interaction.reply({ components: [successEmbed(msg)], flags: V2_FLAGS | MessageFlags.Ephemeral }).catch(() => {});
      }

      // ── AutoMod Buttons ──
      if (id.startsWith('am_')) {
        const { getAutomod, buildPanel, buildFilterPanel } = require('../commands/automod/automod');
        const db = require('../utils/db');
        const { V2_FLAGS } = require('../utils/embed');
        const am = getAutomod(interaction.guild.id);

        // فتح لوحة إعدادات فلتر معين
        if (id.startsWith('am_filter_') && !id.startsWith('am_ftoggle_') && !id.startsWith('am_fdel_') && !id.startsWith('am_fpunish_') && !id.startsWith('am_fpunishtype_') && !id.startsWith('am_fwords_')) {
          const filterKey = id.slice('am_filter_'.length);
          if (am.filters[filterKey]) {
            const panel = buildFilterPanel(am, filterKey);
            return interaction.update(panel).catch(() => {});
          }
        }

        // تشغيل/إيقاف الفلتر نفسه
        if (id.startsWith('am_ftoggle_')) {
          const filterKey = id.slice('am_ftoggle_'.length);
          if (am.filters[filterKey]) {
            am.filters[filterKey].enabled = !am.filters[filterKey].enabled;
            db.commit(interaction.guild.id);
            const panel = buildFilterPanel(am, filterKey);
            return interaction.update(panel).catch(() => {});
          }
        }

        // تشغيل/إيقاف حذف الرسالة
        if (id.startsWith('am_fdel_')) {
          const filterKey = id.slice('am_fdel_'.length);
          if (am.filters[filterKey]) {
            am.filters[filterKey].deleteMessage = !am.filters[filterKey].deleteMessage;
            db.commit(interaction.guild.id);
            const panel = buildFilterPanel(am, filterKey);
            return interaction.update(panel).catch(() => {});
          }
        }

        // تشغيل/إيقاف العقوبة
        if (id.startsWith('am_fpunish_')) {
          const filterKey = id.slice('am_fpunish_'.length);
          if (am.filters[filterKey]) {
            am.filters[filterKey].punishmentEnabled = !am.filters[filterKey].punishmentEnabled;
            db.commit(interaction.guild.id);
            const panel = buildFilterPanel(am, filterKey);
            return interaction.update(panel).catch(() => {});
          }
        }

        // تدوير نوع العقوبة (تحذير → تايم أوت → طرد → بان)
        if (id.startsWith('am_fpunishtype_')) {
          const filterKey = id.slice('am_fpunishtype_'.length);
          if (am.filters[filterKey]) {
            const types = ['warn', 'timeout', 'kick', 'ban'];
            const current = am.filters[filterKey].punishmentType;
            const nextIndex = (types.indexOf(current) + 1) % types.length;
            am.filters[filterKey].punishmentType = types[nextIndex];
            db.commit(interaction.guild.id);
            const panel = buildFilterPanel(am, filterKey);
            return interaction.update(panel).catch(() => {});
          }
        }

        // تعديل الكلمات المحظورة (مودال)
        if (id.startsWith('am_fwords_')) {
          const filterKey = id.slice('am_fwords_'.length);
          if (am.filters[filterKey]) {
            const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
            const modal = new ModalBuilder()
              .setCustomId(`am_words_modal_${filterKey}`)
              .setTitle('تعديل الكلمات المحظورة');
            const input = new TextInputBuilder()
              .setCustomId('am_words_input')
              .setLabel('اكتب الكلمات مفصولة بمسافة أو فاصلة')
              .setStyle(TextInputStyle.Paragraph)
              .setPlaceholder('كلمة1، كلمة2، كلمة3')
              .setValue((am.filters[filterKey].words || []).join('، '))
              .setRequired(false);
            modal.addComponents(new ActionRowBuilder().addComponents(input));
            return interaction.showModal(modal).catch(() => {});
          }
        }

        // رجوع للوحة الرئيسية
        if (id === 'am_back') {
          const panel = buildPanel(am);
          return interaction.update(panel).catch(() => {});
        }

        // تشغيل/إيقاف الإشراف التلقائي كله
        if (id === 'am_toggle') {
          am.enabled = !am.enabled;
          db.commit(interaction.guild.id);
          const panel = buildPanel(am);
          return interaction.update(panel).catch(() => {});
        }

        // شات اللوج - سيليكت مينيو
        if (id === 'am_log') {
          const { ChannelSelectMenuBuilder, ChannelType, ActionRowBuilder } = require('discord.js');
          const menu = new ChannelSelectMenuBuilder()
            .setCustomId('am_log_select')
            .setPlaceholder('اختر شات اللوج')
            .setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement);
          return interaction.reply({
            components: [new ActionRowBuilder().addComponents(menu)],
            flags: V2_FLAGS | MessageFlags.Ephemeral
          }).catch(() => {});
        }

        // الاستثناءات - سيليكت مينيوهات
        if (id === 'am_whitelist') {
          const { RoleSelectMenuBuilder, ChannelSelectMenuBuilder, ChannelType, ActionRowBuilder } = require('discord.js');
          const row1 = new ActionRowBuilder().addComponents(
            new RoleSelectMenuBuilder()
              .setCustomId('am_wl_role')
              .setPlaceholder('رولات مستثناة')
              .setMaxValues(5)
          );
          const row2 = new ActionRowBuilder().addComponents(
            new ChannelSelectMenuBuilder()
              .setCustomId('am_wl_channel')
              .setPlaceholder('شاتات مستثناة')
              .setChannelTypes(ChannelType.GuildText)
              .setMaxValues(5)
          );
          return interaction.reply({
            content: 'اختر الرولات والشاتات المستثناة من الإشراف التلقائي',
            components: [row1, row2],
            ephemeral: true
          }).catch(() => {});
        }
      }

      // ── AutoMod Select Menus & Modal ──
      if (id === 'am_log_select') {
        const { getAutomod } = require('../commands/automod/automod');
        const db = require('../utils/db');
        const am = getAutomod(interaction.guild.id);
        const ch = interaction.channels.first();
        if (ch) {
          am.logChannel = ch.id;
          db.commit(interaction.guild.id);
        }
        return interaction.reply({ content: `✅ تم تحديد شات اللوج`, ephemeral: true }).catch(() => {});
      }

      if (id === 'am_wl_role') {
        const { getAutomod } = require('../commands/automod/automod');
        const db = require('../utils/db');
        const am = getAutomod(interaction.guild.id);
        am.whitelistRoles = interaction.values;
        db.commit(interaction.guild.id);
        return interaction.reply({ content: `✅ تم حفظ ${interaction.values.length} رول مستثنى`, ephemeral: true }).catch(() => {});
      }

      if (id === 'am_wl_channel') {
        const { getAutomod } = require('../commands/automod/automod');
        const db = require('../utils/db');
        const am = getAutomod(interaction.guild.id);
        am.whitelistChannels = interaction.values;
        db.commit(interaction.guild.id);
        return interaction.reply({ content: `✅ تم حفظ ${interaction.values.length} شات مستثنى`, ephemeral: true }).catch(() => {});
      }

      if (id.startsWith('am_words_modal_')) {
        const filterKey = id.slice('am_words_modal_'.length);
        const { getAutomod } = require('../commands/automod/automod');
        const db = require('../utils/db');
        const am = getAutomod(interaction.guild.id);
        if (am.filters[filterKey]) {
          const input = interaction.fields.getTextInputValue('am_words_input');
          const words = input.split(/[,\s]+/).map(w => w.trim()).filter(w => w);
          am.filters[filterKey].words = words;
          db.commit(interaction.guild.id);
          return interaction.reply({ content: `✅ تم حفظ ${words.length} كلمة`, ephemeral: true }).catch(() => {});
        }
      }

      if (id.startsWith('annbtn_')) {
        const btnId = id.slice('annbtn_'.length);
        const db = require('../utils/db');
        const { baseEmbed, V2_FLAGS } = require('../utils/embed');
        const data = db.get(interaction.guild.id);
        let found = null;
        for (const entry of Object.values(data.announceEmbeds || {})) {
          const btn = (entry.buttons || []).find(b => b.id === btnId);
          if (btn) { found = btn; break; }
        }
        if (!found) return interaction.reply({ content: 'الزر ده مش موجود أو اتحذف.', ephemeral: true });
        return interaction.reply({ components: [baseEmbed({ description: found.message })], flags: V2_FLAGS | MessageFlags.Ephemeral });
      }

      if (id.startsWith('ticket_') || id.startsWith('ticketadmins_')) {
        return ticketInteractions(interaction, client);
      }
      if (id.startsWith('tvcfg_')) {
        return tempVoiceConfigInteractions(interaction, client);
      }
      if (id.startsWith('tv_')) {
        return tempVoiceInteractions(interaction, client);
      }
      if (id.startsWith('wlc_') || id.startsWith('editwlc_')) {
        return welcomeInteractions(interaction, client);
      }
      if (id.startsWith('lvl_')) {
        return levelingInteractions(interaction, client);
      }
      if (id.startsWith('secret_')) {
        return secretInteractions(interaction, client);
      }
      if (id.startsWith('zajil_') || id.startsWith('setonli_') || id.startsWith('setlog_') || id.startsWith('setsug_')) {
        return require('../handlers/interactions/settingsChannels')(interaction, client);
      }
      if (id.startsWith('joinlog_')) {
        return require('../handlers/interactions/joinLog')(interaction, client);
      }
      if (id.startsWith('shop_') || id.startsWith('setshop_') || id.startsWith('setshopm_') || id.startsWith('resetpoints_')) {
        return shopInteractions(interaction, client);
      }
      if (id.startsWith('pf_')) {
        return profileInteractions(interaction, client);
      }

      // ── تتبع من كتب /bump (نظام مهام المتجر) ──
      if (interaction.guild && interaction.isChatInputCommand?.() && interaction.commandName === 'bump') {
        const db = require('../utils/db');
        const data = db.get(interaction.guild.id);
        data.tasks.lastBumper = interaction.user.id;
        db.commit(interaction.guild.id);
      }
    } catch (err) {
      console.error('خطأ في التفاعل:', err);
      if (!interaction.isRepliable()) return;
      const errorMessage = `<:fals:1533733827900473366> حدث خطأ غير متوقع: ${err.message || err}`;
      if (interaction.deferred && !interaction.replied) {
        const { errorEmbed, V2_FLAGS } = require('../utils/embed');
        interaction.editReply({ components: [errorEmbed(err.message || String(err))], flags: V2_FLAGS }).catch(() => {});
      } else if (!interaction.replied) {
        interaction.reply({ content: errorMessage, ephemeral: true }).catch(() => {});
      } else {
        interaction.followUp({ content: errorMessage, ephemeral: true }).catch(() => {});
      }
    }
  }
};
