const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

module.exports = {
  name: 'roleDelete',
  async execute(role) {
    const executor = await getAuditExecutor(role.guild, AuditLogEvent.RoleDelete);
    if (!executor) return;

    await sendDetailedLog(role.guild, 'logroles', {
      title: '🎭 حذف رول',
      executor,
      extraFields: [
        { name: '📝 الاسم', value: `\`${role.name}\``, inline: true },
        { name: '🆔 ID الرول', value: `\`${role.id}\``, inline: true },
        { name: '🎨 اللون', value: `\`${role.hexColor}\``, inline: true },
        { name: '🔢 الموضع', value: `\`${role.position}\``, inline: true }
      ]
    });
  }
};
