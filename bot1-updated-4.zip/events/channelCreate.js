const { AuditLogEvent, ChannelType } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

const typeMap = {
  [ChannelType.GuildText]: 'نصي',
  [ChannelType.GuildVoice]: 'صوتي',
  [ChannelType.GuildCategory]: 'كاتيجوري',
  [ChannelType.GuildAnnouncement]: 'إعلانات',
  [ChannelType.GuildForum]: 'فورم',
  [ChannelType.GuildStageVoice]: 'ستيدج',
  [ChannelType.GuildDirectory]: 'دليل'
};

module.exports = {
  name: 'channelCreate',
  async execute(channel) {
    if (!channel.guild) return;
    const executor = await getAuditExecutor(channel.guild, AuditLogEvent.ChannelCreate, channel.id);
    if (!executor) return;

    await sendDetailedLog(channel.guild, 'logchannels', {
      title: '📂 إنشاء روم',
      iconKey: 'channel_create',
      executor,
      channel,
      extraFields: [
        { name: '🏷️ النوع', value: `\`${typeMap[channel.type] || 'أخرى'}\``, inline: true },
        { name: '📊 عدد الرومات', value: `\`${channel.guild.channels.cache.size}\``, inline: true },
        { name: '🔗 المنشن', value: `<#${channel.id}>`, inline: true }
      ]
    });
  }
};
