const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

module.exports = {
  name: 'emojiDelete',
  async execute(emoji, client) {
    const executor = await getAuditExecutor(emoji.guild, AuditLogEvent.EmojiDelete);
    if (!executor || executor.id === client.user.id) return;

    await sendDetailedLog(emoji.guild, 'logemoji', {
      title: '🗑️ حذف إيموجي',
      iconKey: 'emoji_delete',
      executor,
      extraFields: [
        { name: '🏷️ الاسم', value: `\`:${emoji.name}:\``, inline: true },
        { name: '🆔 ID', value: `\`${emoji.id}\``, inline: true },
        { name: '📊 المتبقي', value: `\`${emoji.guild.emojis.cache.size}\``, inline: true },
        { name: '🎬 متحرك', value: emoji.animated ? '✅ نعم' : '❌ لا', inline: true }
      ],
      thumbnail: emoji.url || undefined
    });
  }
};
