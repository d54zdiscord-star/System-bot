const { sendDetailedLog, mentionWithId } = require('../utils/logs');

module.exports = {
  name: 'messageUpdate',
  async execute(oldMessage, newMessage) {
    try {
      if (!oldMessage.guild) return;
      if (!oldMessage.author || oldMessage.author.bot) return;
      if (oldMessage.content === newMessage.content) return;

      await sendDetailedLog(oldMessage.guild, 'channelmessage', {
        title: '✏️ تعديل رسالة',
        iconKey: 'message_edit',
        target: oldMessage.author,
        channel: oldMessage.channel,
        extraFields: [
          { name: '🔗 الرابط', value: `[اضغط هنا](${oldMessage.url})`, inline: true },
          { name: '⬅️ القديم', value: '```' + (oldMessage.content || 'غير متوفر').slice(0, 500) + '```' },
          { name: '➡️ الجديد', value: '```' + (newMessage.content || 'غير متوفر').slice(0, 500) + '```' }
        ]
      });
    } catch (e) {
      console.error('[messageUpdate log]', e.message);
    }
  }
};
