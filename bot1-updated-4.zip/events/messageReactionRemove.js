const db = require('../utils/db');
const { sendLog, mentionWithId } = require('../utils/logs');

module.exports = {
  name: 'messageReactionRemove',
  async execute(reaction, user) {
    if (user.bot) return;
    if (reaction.partial) await reaction.fetch().catch(() => {});
    if (!reaction.message.guild) return;

    // ================= لوق التفاعلات (بقى في نفس شات log-messages) =================
    sendLog(reaction.message.guild, 'channelmessage', {
      title: '➖ إزالة تفاعل',
      fields: [
        { name: 'العضو', value: mentionWithId(user), inline: true },
        { name: 'الشات', value: `${reaction.message.channel}`, inline: true },
        { name: 'التفاعل', value: `${reaction.emoji}`, inline: true },
        { name: 'الرسالة', value: `[اضغط هنا](${reaction.message.url})` }
      ]
    });

    const data = db.get(reaction.message.guild.id);
    const config = data.reactionRoles[reaction.message.id];
    if (!config) return;

    const emojiKey = reaction.emoji.id || reaction.emoji.name;
    const roleId = config[emojiKey];
    if (!roleId) return;

    const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
    if (!member) return;
    member.roles.remove(roleId).catch(() => {});
  }
};
