module.exports = {
  name: 'inviteCreate',
  async execute(invite, client) {
    const map = client.invitesCache.get(invite.guild.id) || new Map();
    map.set(invite.code, invite.uses || 0);
    client.invitesCache.set(invite.guild.id, map);
  }
};
