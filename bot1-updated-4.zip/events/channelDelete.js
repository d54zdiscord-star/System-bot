const { AuditLogEvent, ChannelType } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

const typeMap = {
  [ChannelType.GuildText]: 'نصي',
  [ChannelType.GuildVoice]: 'صوتي',
  [ChannelType.GuildCategory]: 'كاتيجوري',
  [ChannelType.GuildAnnouncement]: 'إعلانات',
  [ChannelType.GuildForum]: 'فورم',
  [ChannelType.GuildStageVoice]: 'ستيدج'
};

module.exports = {
  name: 'channelDelete',
  async execute(channel) {
    if (!channel.guild) return;
    const executor = await getAuditExecutor(channel.guild, AuditLogEvent.ChannelDelete);
    if (!executor) return;

    await sendDetailedLog(channel.guild, 'logchannels', {
      title: '🗑️ حذف روم',
      iconKey: 'channel_delete',
      executor,
      extraFields: [
        { name: '🏷️ اسم الروم', value: `\`${channel.name}\``, inline: true },
        { name: '🏷️ النوع', value: `\`${typeMap[channel.type] || 'أخرى'}\``, inline: true },
        { name: '📊 عدد الرومات', value: `\`${channel.guild.channels.cache.size}\``, inline: true },
        { name: '🆔 ID الروم', value: `\`${channel.id}\``, inline: true }
      ]
    });
  }
};
