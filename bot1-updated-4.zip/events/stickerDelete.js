const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

module.exports = {
  name: 'stickerDelete',
  async execute(sticker, client) {
    const executor = await getAuditExecutor(sticker.guild, AuditLogEvent.StickerDelete);
    if (!executor || executor.id === client.user.id) return;

    await sendDetailedLog(sticker.guild, 'logemoji', {
      title: '🗑️ حذف ستيكر',
      iconKey: 'sticker_delete',
      executor,
      extraFields: [
        { name: '🏷️ الاسم', value: `\`${sticker.name}\``, inline: true },
        { name: '🆔 ID', value: `\`${sticker.id}\``, inline: true },
        { name: '📊 المتبقي', value: `\`${sticker.guild.stickers.cache.size}\``, inline: true }
      ],
      thumbnail: sticker.url || undefined
    });
  }
};
