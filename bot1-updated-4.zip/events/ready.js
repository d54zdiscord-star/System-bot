const { ActivityType } = require('discord.js');
const db = require('../utils/db');
const { reconnectAllOnlineChannels } = require('../utils/onlineVoice');
const { startScheduler } = require('../utils/scheduler');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    try {
      console.log(`✅ البوت اشتغل باسم ${client.user.tag} (${client.user.id})`);
      console.log(`📊 في ${client.guilds.cache.size} سيرفر`);

      client.user.setPresence({
        activities: [{ name: 'استخدم $help', type: ActivityType.Watching }],
        status: 'online'
      });
      console.log('🟢 Status set to online');

      // Check ended giveaways (in case bot was offline)
      try {
        const { endGiveaway } = require('../commands/giveaway/giveaway');
        for (const guild of client.guilds.cache.values()) {
          const data = db.get(guild.id);
          if (data.giveaways) {
            for (const [msgId, g] of Object.entries(data.giveaways)) {
              if (!g.ended && g.endTime <= Date.now()) {
                await endGiveaway(client, guild.id, msgId).catch(() => {});
              }
            }
          }
        }
        console.log('🎉 Checked ended giveaways');
      } catch (e) {
        console.error('⚠️ Giveaway check error:', e.message);
      }

      // Start scheduler after bot is fully ready
      try {
        startScheduler(client);
        console.log('⏰ Scheduler started');
      } catch (e) {
        console.error('⚠️ Scheduler error:', e.message);
      }

      // Reconnect voice channels
      try {
        reconnectAllOnlineChannels(client, db);
      } catch (e) {
        console.error('⚠️ Voice reconnect error:', e.message);
      }

      // Cache invites
      for (const guild of client.guilds.cache.values()) {
        try {
          const invites = await guild.invites.fetch();
          client.invitesCache.set(
            guild.id,
            new Map(invites.map(inv => [inv.code, inv.uses || 0]))
          );
        } catch (e) {
          // No permission to fetch invites, ignore
        }
      }
      console.log('✅ Ready event completed');
    } catch (err) {
      console.error('❌ Error in ready event:', err);
    }
  }
};
