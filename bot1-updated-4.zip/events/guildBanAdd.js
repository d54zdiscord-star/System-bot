const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor, mentionWithId } = require('../utils/logs');

module.exports = {
  name: 'guildBanAdd',
  async execute(ban, client) {
    try {
      const executor = await getAuditExecutor(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);
      if (!executor || executor.id === client.user.id) return;

      const createdTs = Math.floor(ban.user.createdAt.getTime() / 1000);

      await sendDetailedLog(ban.guild, 'logbanunban', {
        title: '🔨 باند عضو',
        executor,
        target: ban.user,
        extraFields: [
          { name: '📊 عدد الأعضاء', value: `\`${ban.guild.memberCount}\``, inline: true }
        ],
        thumbnail: ban.user.displayAvatarURL({ extension: 'png', forceStatic: true, size: 1024 })
      });
    } catch (e) {
      console.error('[guildBanAdd log]', e.message);
    }
  }
};
