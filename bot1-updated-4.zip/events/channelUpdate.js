const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

module.exports = {
  name: 'channelUpdate',
  async execute(oldChannel, newChannel) {
    if (!oldChannel.guild) return;
    if (oldChannel.name === newChannel.name) return;

    const executor = await getAuditExecutor(oldChannel.guild, AuditLogEvent.ChannelUpdate, oldChannel.id);
    if (!executor) return;

    await sendDetailedLog(oldChannel.guild, 'logchannels', {
      title: '✏️ تعديل روم',
      iconKey: 'channel_update',
      executor,
      channel: newChannel,
      extraFields: [
        { name: '🆔 ID الروم', value: `\`${oldChannel.id}\``, inline: true },
        { name: '📤 الاسم القديم', value: `\`${oldChannel.name}\``, inline: true },
        { name: '📥 الاسم الجديد', value: `\`${newChannel.name}\``, inline: true }
      ]
    });
  }
};
