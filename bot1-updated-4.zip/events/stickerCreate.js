const { AuditLogEvent } = require('discord.js');
const { sendDetailedLog, getAuditExecutor } = require('../utils/logs');

module.exports = {
  name: 'stickerCreate',
  async execute(sticker, client) {
    const executor = await getAuditExecutor(sticker.guild, AuditLogEvent.StickerCreate, sticker.id);
    if (!executor || executor.id === client.user.id) return;

    await sendDetailedLog(sticker.guild, 'logemoji', {
      title: '➕ إضافة ستيكر',
      iconKey: 'sticker_create',
      executor,
      extraFields: [
        { name: '🎨 الستيكر', value: `\`${sticker.name}\``, inline: true },
        { name: '🆔 ID', value: `\`${sticker.id}\``, inline: true },
        { name: '📊 العدد', value: `\`${sticker.guild.stickers.cache.size}\``, inline: true },
        { name: '🏷️ التاج', value: `\`${sticker.tags || 'مفيش'}\``, inline: true },
        { name: '🔗 الرابط', value: `[فتح الستيكر](${sticker.url})` }
      ],
      thumbnail: sticker.url
    });
  }
};
