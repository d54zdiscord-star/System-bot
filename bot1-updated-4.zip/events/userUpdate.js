const db = require('../utils/db');
const { baseEmbed, V2_FLAGS } = require('../utils/embed');

module.exports = {
  name: 'userUpdate',
  async execute(oldUser, newUser, client) {
    for (const guild of client.guilds.cache.values()) {
      const member = guild.members.cache.get(newUser.id);
      if (!member) continue;
      const data = db.get(guild.id);

      if (oldUser.username !== newUser.username && data.settings.logChannels.nameUpdates) {
        const channel = guild.channels.cache.get(data.settings.logChannels.nameUpdates);
        if (channel) {
          channel
            .send({
              components: [
                baseEmbed({
                  title: 'تحديث اسم',
                  description: `${newUser} غيّر اسمه من **${oldUser.username}** لـ **${newUser.username}**`
                })
              ],
              flags: V2_FLAGS
            })
            .catch(() => {});
        }
      }

      if (oldUser.avatar !== newUser.avatar && data.settings.logChannels.avatarUpdates) {
        const channel = guild.channels.cache.get(data.settings.logChannels.avatarUpdates);
        if (channel) {
          channel
            .send({
              components: [
                baseEmbed({
                  title: 'تحديث صورة',
                  description: `${newUser} غيّر صورته الشخصية`,
                  thumbnail: newUser.displayAvatarURL({ dynamic: true })
                })
              ],
              flags: V2_FLAGS
            })
            .catch(() => {});
        }
      }
    }
  }
};
