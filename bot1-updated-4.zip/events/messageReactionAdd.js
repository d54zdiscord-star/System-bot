const db = require('../utils/db');
const { updateProgress } = require('../utils/tasks');
const { sendLog, mentionWithId } = require('../utils/logs');

module.exports = {
  name: 'messageReactionAdd',
  async execute(reaction, user, client) {
    if (user.bot) return;
    if (reaction.partial) await reaction.fetch().catch(() => {});
    if (!reaction.message.guild) return;

    const data = db.get(reaction.message.guild.id);

    // ================= لوق التفاعلات (بقى في نفس شات log-messages) =================
    sendLog(reaction.message.guild, 'channelmessage', {
      title: '➕ إضافة تفاعل',
      fields: [
        { name: 'العضو', value: mentionWithId(user), inline: true },
        { name: 'الشات', value: `${reaction.message.channel}`, inline: true },
        { name: 'التفاعل', value: `${reaction.emoji}`, inline: true },
        { name: 'الرسالة', value: `[اضغط هنا](${reaction.message.url})` }
      ]
    });

    // ================= مهام المتجر: تفاعلات =================
    if (data.tasks.enabled) {
      updateProgress(client, reaction.message.guild.id, user.id, 'reactions', 1).catch(() => {});
    }

    const config = data.reactionRoles[reaction.message.id];
    if (!config) return;

    const emojiKey = reaction.emoji.id || reaction.emoji.name;
    const roleId = config[emojiKey];
    if (!roleId) return;

    const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
    if (!member) return;
    member.roles.add(roleId).catch(() => {});
  }
};
