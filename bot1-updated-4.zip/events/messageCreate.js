const db = require('../utils/db');
const { errorEmbed, V2_FLAGS, sectionedContainer } = require('../utils/embed');
const permissions = require('../utils/permissions');
const { addChatXp } = require('../utils/leveling');
const afk = require('../utils/afk');
const { updateProgress } = require('../utils/tasks');
const { checkAutomod } = require('../commands/automod/automod');

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (!message.guild) return;

    // ================= AutoMod Check (before everything) =================
    const automodBlocked = await checkAutomod(message).catch(() => false);
    if (automodBlocked) return;

    // ================= رسالة تأكيد bump من Disboard (نظام مهام المتجر) =================
    if (message.author.bot) {
      if (message.author.id === '302050872383242240' && message.embeds?.[0]?.description?.includes('Bump done')) {
        const data = db.get(message.guild.id);
        const lastBumper = data.tasks.lastBumper;
        if (lastBumper) {
          updateProgress(client, message.guild.id, lastBumper, 'bump', 1).catch(() => {});
          delete data.tasks.lastBumper;
          db.commit(message.guild.id);
        }
      }
      return;
    }

    const data = db.get(message.guild.id);
    const isStaffLike = permissions.isBotOwnerInGuild(message.member);

    // ================= مهام المتجر: رسائل + صور =================
    if (data.tasks.enabled) {
      updateProgress(client, message.guild.id, message.author.id, 'messages', 1).catch(() => {});
      if (message.attachments.some(a => a.contentType?.startsWith('image/'))) {
        updateProgress(client, message.guild.id, message.author.id, 'images', 1).catch(() => {});
      }
    }

    // ================= AFK: رجوع الشخص من الـ AFK =================
    const guildPrefix = data.prefix || require('../config').defaultPrefix;
    const isAfkCommandMsg = message.content.trim().toLowerCase().startsWith(`${guildPrefix}afk`.toLowerCase());
    if (!isAfkCommandMsg) {
      const removed = afk.removeAfk(message.guild.id, message.author.id);
      if (removed) {
        const details = [`تم إلغاء وضع الـ AFK — كنت غايب لمدة ${afk.formatDuration(Date.now() - removed.since)}.`];
        if (removed.mentions.length) {
          details.push('');
          details.push(`في ${removed.mentions.length} منشن ليك وانت غايب:`);
          for (const m of removed.mentions) {
            details.push(`**${m.authorTag}** من ${afk.formatDuration(Date.now() - m.timestamp)} — [روح للرسالة](${m.url})`);
          }
        } else {
          details.push('');
          details.push('مفيش حد عملك منشن وانت غايب');
        }
        message.channel
          .send({
            components: [sectionedContainer(`**أهلاً بيك تاني، ${message.author}!**`, details)],
            flags: V2_FLAGS
          })
          .catch(() => {});
      }
    }

    // ================= AFK: منشن حد AFK =================
    if (message.mentions.users.size) {
      let notified = 0;
      for (const [, user] of message.mentions.users) {
        if (notified >= 3) break;
        if (user.id === message.author.id || user.bot) continue;
        const entry = afk.getAfk(message.guild.id, user.id);
        if (!entry) continue;

        afk.addMention(message.guild.id, user.id, {
          authorTag: message.author.tag,
          timestamp: Date.now(),
          url: message.url
        });

        message.channel
          .send({
            components: [
              sectionedContainer(`**${user} في وضع الـ AFK**`, [
                `من ${afk.formatDuration(Date.now() - entry.since)}`,
                `السبب: ${entry.reason}`
              ])
            ],
            flags: V2_FLAGS
          })
          .catch(() => {});
        notified++;
      }
    }

    // ================= فيتشرز الشات (applay / picOnly / autoReact / autoLine) =================
    const feat = (data.settings.chatFeatures || {})[message.channel.id];
    if (feat && !isStaffLike) {
      const hasAttachment = message.attachments.size > 0;
      const hasMention = message.mentions.users.size > 0 || message.mentions.roles.size > 0;

      if (feat.picOnly && !hasAttachment) {
        return message.delete().catch(() => {});
      }
      if (feat.applayOnly && !hasAttachment && !hasMention) {
        return message.delete().catch(() => {});
      }
    }
    if (feat) {
      if (feat.autoReact) message.react(feat.autoReact).catch(() => {});
      if (feat.autoLine) {
        message.channel
          .send(feat.autoLineImage ? { files: [feat.autoLineImage] } : { content: '───────────────' })
          .catch(() => {});
      }
    }

    // ---- الرد التلقائي (autoreply) ----
    const autoReplies = data.autoReplies || {};
    const contentLower = message.content.trim().toLowerCase();
    if (autoReplies[contentLower]) {
      message.reply(autoReplies[contentLower]).catch(() => {});
    }

    // ---- XP الشات (نظام اللفلات) ----
    if (data.leveling.enabled) {
      addChatXp(message).catch(() => {});
    }

    // ---- تحليل الأمر ----
    const prefix = data.prefix || require('../config').defaultPrefix;

    let usedPrefix = null;
    if (message.content.startsWith(prefix)) {
      usedPrefix = prefix;
    } else {
      const firstWord = message.content.trim().split(/\s+/)[0]?.toLowerCase();
      const noPrefixList = data.settings.noPrefixCommands || [];
      const isKnownCmd =
        client.commands.has(firstWord) || client.aliases.has(firstWord) || (data.settings.customAliases || {})[firstWord];

      if (noPrefixList.includes(firstWord) || (data.settings.adminNoPrefix && isKnownCmd)) {
        usedPrefix = '';
      }
    }

    if (usedPrefix === null) return;

    const args = message.content.slice(usedPrefix.length).trim().split(/\s+/);
    let cmdName = args.shift().toLowerCase();
    if (!cmdName) return;

    const customAlias = (data.settings.customAliases || {})[cmdName];
    if (customAlias) cmdName = customAlias;

    const command =
      client.commands.get(cmdName) ||
      client.commands.get(client.aliases.get(cmdName));

    if (!command) return;

    // ---- تشات البلاك ليست ----
    if (data.settings.blacklistChannels.includes(message.channel.id) && !isStaffLike) {
      return;
    }

    // ---- شات الأوامر الرسمي ----
    const restrictedChannels = data.settings.commandChannels || [];
    if (
      restrictedChannels.length &&
      !restrictedChannels.includes(message.channel.id) &&
      !isStaffLike &&
      command.category === 'عامة'
    ) {
      return message
        .reply({ components: [errorEmbed(`استخدم الأوامر في ${restrictedChannels.map(id => `<#${id}>`).join(' أو ')} بس.`)], flags: V2_FLAGS })
        .catch(() => {});
    }

    // ---- الصلاحيات ----
    if (!permissions.canUseCommand(message.member, command)) {
      return message.reply({
        components: [errorEmbed('معندكش صلاحية تستخدم الأمر ده.')],
        flags: V2_FLAGS
      }).catch(() => {});
    }

    try {
      await command.execute(message, args, client);
    } catch (err) {
      console.error(`خطأ في تنفيذ أمر ${command.name}:`, err);
      message.reply({ components: [errorEmbed('حدث خطأ أثناء تنفيذ الأمر!')], flags: V2_FLAGS }).catch(() => {});
    }
  }
};
