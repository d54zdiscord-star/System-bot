const { UserSelectMenuBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField, MessageFlags } = require('discord.js');
const db = require('../../utils/db');
const { successEmbed, errorEmbed, V2_FLAGS } = require('../../utils/embed');
const { createTicket, sendTicketLog } = require('../../utils/tickets');
const permissions = require('../../utils/permissions');

module.exports = async function handleTicketInteraction(interaction) {
  const guild = interaction.guild;
  const data = db.get(guild.id);

  // ---- اختيار نوع التكت (قائمة منسدلة) ----
  if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_select') {
    const typeId = interaction.values[0];
    await interaction.deferReply({ ephemeral: true });
    const channel = await createTicket(interaction, guild, interaction.member, typeId);
    if (!channel) {
      return interaction.editReply({ components: [errorEmbed('نوع التكت مش موجود.')], flags: V2_FLAGS });
    }
    return interaction.editReply({ components: [successEmbed(`تم فتح تكتك: ${channel}`)], flags: V2_FLAGS });
  }

  // ---- اختيار نوع التكت (زرار) ----
  if (interaction.isButton() && interaction.customId.startsWith('ticket_open_')) {
    const typeId = interaction.customId.slice('ticket_open_'.length);
    await interaction.deferReply({ ephemeral: true });
    const channel = await createTicket(interaction, guild, interaction.member, typeId);
    if (!channel) {
      return interaction.editReply({ components: [errorEmbed('نوع التكت مش موجود.')], flags: V2_FLAGS });
    }
    return interaction.editReply({ components: [successEmbed(`تم فتح تكتك: ${channel}`)], flags: V2_FLAGS });
  }

  // ---- اختيار الرولات الإدارية للتكتات ----
  if (interaction.isRoleSelectMenu() && interaction.customId === 'ticketadmins_roleselect') {
    data.tickets.adminRoleIds = interaction.values;
    db.commit(guild.id);

    // نضيف الصلاحية لكل التكتات المفتوحة حاليًا كمان
    for (const channelId of Object.keys(data.tickets.open)) {
      const ch = guild.channels.cache.get(channelId);
      if (!ch) continue;
      for (const roleId of interaction.values) {
        await ch.permissionOverwrites
          .edit(roleId, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true, EmbedLinks: true })
          .catch(() => {});
      }
    }

    return interaction.update({
      content: interaction.values.length ? `<:true:1533733814105407619> الرولات الإدارية للتكتات: ${interaction.values.map(id => `<@&${id}>`).join(', ')}` : '<:true:1533733814105407619> اتشالت كل الرولات الإدارية',
      components: []
    });
  }

  if (!interaction.isButton() && !interaction.isUserSelectMenu()) return;

  const parts = interaction.customId.split('_');
  const action = parts[1];
  const channelId = parts[2];
  const ticketInfo = data.tickets.open[channelId];

  const canManage =
    permissions.isBotOwnerInGuild(interaction.member) ||
    interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels);

  if (interaction.isButton() && action === 'lock') {
    if (!canManage) {
      return interaction.reply({ components: [errorEmbed('للإدارة بس.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    if (!ticketInfo) return interaction.reply({ components: [errorEmbed('التكت ده مش مسجل.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

    ticketInfo.locked = true;
    db.commit(guild.id);

    await interaction.channel.permissionOverwrites
      .edit(ticketInfo.ownerId, { SendMessages: false })
      .catch(() => {});

    // لوج القفل + الترانسكريبت (زي بوت ١) - بيتبعت في الخلفية من غير ما نستنى عشان الرد يرجع بسرعة
    sendTicketLog(guild, 'close', { channel: interaction.channel, ticketInfo, userId: interaction.user.id }).catch(() => {});

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`ticket_reopen_${channelId}`).setLabel('فتح').setEmoji('🔓').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`ticket_delete_${channelId}`).setLabel('مسح').setEmoji('🗑️').setStyle(ButtonStyle.Danger)
    );

    return interaction.reply({
      components: [successEmbed('تم قفل التكت'), row],
      flags: V2_FLAGS
    });
  }

  if (interaction.isButton() && action === 'reopen') {
    if (!canManage) {
      return interaction.reply({ components: [errorEmbed('للإدارة بس.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    if (!ticketInfo) return interaction.reply({ components: [errorEmbed('التكت ده مش مسجل.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

    ticketInfo.locked = false;
    db.commit(guild.id);
    await interaction.channel.permissionOverwrites
      .edit(ticketInfo.ownerId, { SendMessages: true })
      .catch(() => {});

    return interaction.update({ components: [successEmbed('تم فتح التكت')], flags: V2_FLAGS });
  }

  if (interaction.isButton() && action === 'delete') {
    if (!canManage) {
      return interaction.reply({ components: [errorEmbed('للإدارة بس.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    await interaction.reply({ components: [successEmbed('جاري مسح التكت...')], flags: V2_FLAGS });
    sendTicketLog(guild, 'delete', { channel: interaction.channel, ticketInfo, userId: interaction.user.id }).catch(() => {});
    delete data.tickets.open[channelId];
    db.commit(guild.id);
    setTimeout(() => interaction.channel.delete().catch(() => {}), 1500);
    return;
  }

  if (interaction.isButton() && action === 'mentionmember') {
    if (!ticketInfo) return interaction.reply({ components: [errorEmbed('التكت ده مش مسجل.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    return interaction.reply({ content: `<@${ticketInfo.ownerId}>` });
  }

  if (interaction.isButton() && action === 'mentionadmin') {
    return interaction.reply({ content: '🔔 تم استدعاء الإدارة @here' });
  }

  if (interaction.isButton() && (action === 'addmember' || action === 'removemember')) {
    if (!canManage) {
      return interaction.reply({ components: [errorEmbed('للإدارة بس.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const menu = new UserSelectMenuBuilder()
      .setCustomId(`ticket_${action}select_${channelId}`)
      .setPlaceholder('اختار العضو...');
    return interaction.reply({
      components: [new ActionRowBuilder().addComponents(menu)],
      ephemeral: true
    });
  }

  if (interaction.isUserSelectMenu() && (action === 'addmemberselect' || action === 'removememberselect')) {
    const userId = interaction.values[0];
    if (action === 'addmemberselect') {
      await interaction.channel.permissionOverwrites.edit(userId, {
        ViewChannel: true,
        SendMessages: true,
        ReadMessageHistory: true
      });
      return interaction.update({ content: `<:true:1533733814105407619> تم إضافة <@${userId}> للتكت.`, components: [] });
    } else {
      await interaction.channel.permissionOverwrites.delete(userId).catch(() => {});
      return interaction.update({ content: `<:true:1533733814105407619> تم إزالة <@${userId}> من التكت.`, components: [] });
    }
  }
};
