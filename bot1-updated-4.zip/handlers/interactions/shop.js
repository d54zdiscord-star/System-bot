// ─────────────────────────────────────────────────────────────────
//  handlers/interactions/shop.js
//  كل تفاعلات نظام المتجر الدائمة (تفضل شغالة حتى بعد ريستارت البوت)
//  منقولة حرفيًا من بوت ١: shop.js + setshop.js + resetpoints.js
// ─────────────────────────────────────────────────────────────────
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, ChannelSelectMenuBuilder, ChannelType, ContainerBuilder, TextDisplayBuilder,
  SeparatorBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder,
  ModalBuilder, TextInputBuilder, TextInputStyle,
  AttachmentBuilder, MessageFlags
} = require('discord.js');
const db = require('../../utils/db');
const { errorEmbed, successEmbed, baseEmbed, V2_FLAGS } = require('../../utils/embed');
const { renderShopProfileCard } = require('../../utils/cards');
const { generateDailyTasks, generateWeeklyTasks, getDailyResetTimestamp, getWeeklyResetTimestamp } = require('../../utils/tasks');
const { buildShopPanel, parseEmoji } = require('../../utils/shopUI');
const config = require('../../config');

const TRUE = config.emojis.trueTick;
const FALSE = config.emojis.falseTick;

function buildProgressBar(cur, max) {
  const f = Math.min(10, Math.floor((cur / max) * 10));
  return '▓'.repeat(f) + '░'.repeat(10 - f);
}

function buildTasksContainer(tasks, isWeekly) {
  const title = isWeekly ? '## المهام الأسبوعية' : '## المهام اليومية';
  const done = tasks.filter(t => t.done).length;
  const resetTs = isWeekly ? getWeeklyResetTimestamp() : getDailyResetTimestamp();
  const resetLabel = isWeekly ? 'تتجدد الأسبوع القادم' : 'تتجدد غداً';
  let lines = `${title}\n-# ${done}/${tasks.length} مكتملة  ·  <t:${resetTs}:R> ${resetLabel}\n\n`;

  tasks.forEach((t, i) => {
    const icon = t.done ? TRUE : FALSE;
    const pct = t.done ? 100 : Math.floor(((t.progress || 0) / t.target) * 100);
    const bar = t.done ? '▓▓▓▓▓▓▓▓▓▓' : buildProgressBar(t.progress || 0, t.target);
    lines += `${icon} **${i + 1}.** ${t.text}\n`;
    lines += `> ${bar} **${pct}%** | **+${t.points}** نقطة | ${t.diff}\n`;
    if (!t.done) lines += `> -# ${t.progress || 0} / ${t.target}\n`;
    lines += '\n';
  });

  const container = new ContainerBuilder()
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(lines.trim()))
    .addSeparatorComponents(new SeparatorBuilder());

  if (!isWeekly) {
    container.addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('shop_weekly').setLabel('المهام الأسبوعية').setStyle(ButtonStyle.Secondary).setEmoji(parseEmoji(config.emojis.shopTasks))
      )
    );
  }
  return container;
}

// ─── حفظ نسخة احتياطية من إعدادات المتجر (زي بوت ١) ───
function backupShopConfig(guildId) {
  // البيانات محفوظة أصلًا في data/guilds/<id>.json عن طريق db.commit، فمفيش داعي لملف منفصل هنا
  db.commit(guildId);
}

module.exports = async function shopInteractions(interaction, client) {
  if (!interaction.guild) return;
  const id = interaction.customId || '';
  const guildId = interaction.guild.id;

  try {
    // ═══════════════════════════ المتجر (عرض الرتب) ═══════════════════════════
    if (id === 'shop_ranks') {
      const data = db.get(guildId);
      const pts = data.points[interaction.user.id] || 0;
      const list = data.shop.ranks;

      if (!list.length) return interaction.reply({ components: [errorEmbed('لسه مفيش رتب متاحة.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

      function buildOptions(slice, startIndex) {
        return slice.map((r, i) => {
          const role = interaction.guild.roles.cache.get(r.roleId);
          const owned = interaction.member?.roles?.cache?.has(r.roleId);
          const num = startIndex + i + 1;
          const name = role ? role.name : `رتبة ${r.roleId.slice(-4)}`;
          const label = `${num}. ${name}`.slice(0, 25);
          const desc = owned ? `✅ تملكها — ${r.points} نقطة` : `${r.points} نقطة`;
          const opt = { label, description: desc, value: r.roleId };
          if (role?.unicodeEmoji) opt.emoji = role.unicodeEmoji;
          return opt;
        });
      }

      const rankLines = list.map((r, i) => {
        const role = interaction.guild.roles.cache.get(r.roleId);
        const owned = interaction.member?.roles?.cache?.has(r.roleId);
        const tick = owned ? TRUE : FALSE;
        const name = role ? role.toString() : `<@&${r.roleId}>`;
        return `${tick} **${i + 1}.** ${name} — **${r.points}** نقطة`;
      }).join('\n');

      const half = Math.ceil(list.length / 2);
      const page1 = list.slice(0, half);
      const page2 = list.slice(half);

      const container = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
          `${config.emojis.shopRanks} المتجر\n> نقاطك الحالية: **${pts}** نقطة\n\n${rankLines}`
        ))
        .addSeparatorComponents(new SeparatorBuilder())
        .addActionRowComponents(
          new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder().setCustomId('shop_buy_select').setPlaceholder(`الرتب 1 — ${page1.length}`).addOptions(buildOptions(page1, 0))
          )
        );

      if (page2.length > 0) {
        container.addActionRowComponents(
          new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder().setCustomId('shop_buy_select_p2').setPlaceholder(`الرتب ${page1.length + 1} — ${list.length}`).addOptions(buildOptions(page2, page1.length))
          )
        );
      }

      return interaction.reply({ components: [container], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    // ═══════════════════════════ شراء رتبة ═══════════════════════════
    if (id === 'shop_buy_select' || id === 'shop_buy_select_p2') {
      const roleId = interaction.values[0];
      const data = db.get(guildId);
      const def = data.shop.ranks.find(r => r.roleId === roleId);
      if (!def) return interaction.reply({ components: [errorEmbed('الرتبة دي مش موجودة.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

      const role = interaction.guild.roles.cache.get(roleId);
      if (!role) return interaction.reply({ components: [errorEmbed('الرتبة دي محذوفة.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

      if (interaction.member.roles.cache.has(roleId)) {
        return interaction.reply({ components: [errorEmbed('الرتبة دي عندك بالفعل.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
      }

      const cur = data.points[interaction.user.id] || 0;
      const defPts = parseInt(def.points) || 0;
      if (cur < defPts) {
        return interaction.reply({
          components: [errorEmbed(`نقاطك مش كفاية.\nمحتاج: **${defPts}** | عندك: **${cur}**`)],
          flags: V2_FLAGS | MessageFlags.Ephemeral
        });
      }

      await interaction.member.roles.add(roleId).catch(() => {});
      data.points[interaction.user.id] = cur - defPts;
      db.commit(guildId);

      return interaction.reply({
        components: [successEmbed(`تم شراء رتبة \`${role.name}\` بنجاح!\nنقاطك المتبقية: **${cur - defPts}**`)],
        flags: V2_FLAGS | MessageFlags.Ephemeral
      });
    }

    // ═══════════════════════════ Info ═══════════════════════════
    if (id === 'shop_info') {
      const data = db.get(guildId);
      if (!data.shop.infoText) return interaction.reply({ components: [errorEmbed('لسه محدش حط محتوى الـ Info.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

      return interaction.reply({
        components: [baseEmbed({ title: `${config.emojis.shopInfo} معلومات`, description: data.shop.infoText, image: data.shop.infoImage || undefined })],
        flags: V2_FLAGS | MessageFlags.Ephemeral
      });
    }

    // ═══════════════════════════ بروفايل ═══════════════════════════
    if (id === 'shop_profile') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const data = db.get(guildId);
      const userId = interaction.user.id;
      const member = interaction.member;
      const points = data.points[userId] || 0;

      const voiceKey = `${guildId}-${userId}`;
      const joinNow = client.voiceJoinTimestamps?.get(voiceKey);
      const liveMs = joinNow ? Date.now() - joinNow : 0;
      const totalMs = (data.leveling?.users?.[userId]?.voiceXp || 0) * 60000 + liveMs;
      const hours = Math.floor(totalMs / 3600000);
      const mins = Math.floor((totalMs % 3600000) / 60000);

      const dailyTasks = generateDailyTasks(guildId, userId);
      const weeklyTasks = generateWeeklyTasks(guildId, userId);

      const buffer = await renderShopProfileCard({
        username: member.user.username,
        avatarURL: member.displayAvatarURL({ extension: 'png', size: 256 }),
        points,
        voiceHours: hours,
        voiceMinutes: mins,
        dailyDone: dailyTasks.filter(t => t.done).length,
        dailyTotal: dailyTasks.length || 5,
        weeklyDone: weeklyTasks.filter(t => t.done).length,
        weeklyTotal: weeklyTasks.length || 3,
        dailyTasks
      });

      const att = new AttachmentBuilder(buffer, { name: 'profile_card.png' });
      const container = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`${config.emojis.shopProfile} بروفايلي`))
        .addSeparatorComponents(new SeparatorBuilder())
        .addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL('attachment://profile_card.png')));

      return interaction.editReply({ components: [container], flags: V2_FLAGS, files: [att] });
    }

    // ═══════════════════════════ مهامي اليومية / الأسبوعية ═══════════════════════════
    if (id === 'shop_tasks') {
      const tasks = generateDailyTasks(guildId, interaction.user.id);
      if (!tasks.length) return interaction.reply({ components: [errorEmbed('نظام المهام مش مفعّل دلوقتي.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
      return interaction.reply({ components: [buildTasksContainer(tasks, false)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    if (id === 'shop_weekly') {
      const tasks = generateWeeklyTasks(guildId, interaction.user.id);
      if (!tasks.length) return interaction.reply({ components: [errorEmbed('نظام المهام مش مفعّل دلوقتي.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
      return interaction.reply({ components: [buildTasksContainer(tasks, true)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    // ═══════════════════════════ setshop: إضافة رتبة ═══════════════════════════
    if (id === 'setshop_add') {
      const modal = new ModalBuilder().setCustomId('setshopm_add').setTitle('إضافة رتبة للمتجر').addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('role_id').setLabel('ID الرتبة').setStyle(TextInputStyle.Short).setPlaceholder('مثال: 123456789012345678').setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('role_points').setLabel('عدد النقاط المطلوبة للشراء').setStyle(TextInputStyle.Short).setPlaceholder('مثال: 100').setRequired(true)
        )
      );
      return interaction.showModal(modal);
    }

    if (id === 'setshopm_add') {
      const roleId = interaction.fields.getTextInputValue('role_id').trim();
      const pts = parseInt(interaction.fields.getTextInputValue('role_points'));
      if (isNaN(pts) || pts < 1) return interaction.reply({ components: [errorEmbed('عدد النقاط مش صحيح.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

      const role = interaction.guild.roles.cache.get(roleId);
      if (!role) return interaction.reply({ components: [errorEmbed('آيدي الرتبة مش صحيح.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

      const data = db.get(guildId);
      if (data.shop.ranks.find(r => r.roleId === roleId)) {
        return interaction.reply({ components: [errorEmbed('الرتبة دي مضافة بالفعل.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
      }
      data.shop.ranks.push({ roleId, points: pts });
      backupShopConfig(guildId);
      return interaction.reply({ components: [successEmbed(`تم إضافة رتبة \`${role.name}\` بـ ${pts} نقطة.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    // ═══════════════════════════ setshop: عرض الرتب ═══════════════════════════
    if (id === 'setshop_list') {
      const data = db.get(guildId);
      if (!data.shop.ranks.length) return interaction.reply({ components: [errorEmbed('لسه مفيش رتب اتضافت.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

      const text = data.shop.ranks.map((r, i) => {
        const role = interaction.guild.roles.cache.get(r.roleId);
        const name = role ? role.toString() : `<@&${r.roleId}>`;
        return `**${i + 1}.** ${name} — **${r.points}** نقطة`;
      }).join('\n');

      return interaction.reply({ components: [baseEmbed({ title: 'الرتب المتاحة', description: text })], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    // ═══════════════════════════ setshop: حذف رتبة ═══════════════════════════
    if (id === 'setshop_del') {
      const data = db.get(guildId);
      if (!data.shop.ranks.length) return interaction.reply({ components: [errorEmbed('مفيش رتب دلوقتي.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

      const options = data.shop.ranks.slice(0, 25).map(r => {
        const role = interaction.guild.roles.cache.get(r.roleId);
        const opt = { label: role ? role.name.slice(0, 25) : `ID: ${r.roleId}`, description: `${r.points} نقطة`, value: r.roleId };
        if (role?.unicodeEmoji) opt.emoji = role.unicodeEmoji;
        return opt;
      });

      return interaction.reply({
        components: [
          new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent('اختر الرتبة للحذف:')),
          new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('setshop_dodel').setPlaceholder('اختر رتبة...').addOptions(options))
        ],
        flags: V2_FLAGS | MessageFlags.Ephemeral
      });
    }

    if (id === 'setshop_dodel') {
      const roleId = interaction.values[0];
      const data = db.get(guildId);
      data.shop.ranks = data.shop.ranks.filter(r => r.roleId !== roleId);
      backupShopConfig(guildId);
      return interaction.reply({ components: [successEmbed('تم حذف الرتبة.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    // ═══════════════════════════ setshop: نص Info ═══════════════════════════
    if (id === 'setshop_setinfo') {
      const modal = new ModalBuilder().setCustomId('setshopm_setinfo').setTitle('تعيين محتوى صفحة Info').addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('info_text').setLabel('النص (يدعم Markdown)').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1500)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('info_image').setLabel('رابط صورة (اختياري)').setStyle(TextInputStyle.Short).setRequired(false)
        )
      );
      return interaction.showModal(modal);
    }

    if (id === 'setshopm_setinfo') {
      const text = interaction.fields.getTextInputValue('info_text');
      const image = interaction.fields.getTextInputValue('info_image').trim();
      const data = db.get(guildId);
      data.shop.infoText = text;
      if (image) data.shop.infoImage = image;
      backupShopConfig(guildId);
      return interaction.reply({ components: [successEmbed('تم حفظ نص الـ Info.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    // ═══════════════════════════ setshop: تخصيص Embed ═══════════════════════════
    if (id === 'setshop_setembed') {
      const modal = new ModalBuilder().setCustomId('setshopm_setembed').setTitle('تخصيص لوحة المتجر').addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('embed_text').setLabel('النص الرئيسي (يدعم Markdown)').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1500)
            .setPlaceholder('مثال:\n## نظام النقاط\n> اكسب نقاطك وحصّل رتبتك!')
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('embed_image').setLabel('رابط صورة (ضروري)').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('https://...')
        )
      );
      return interaction.showModal(modal);
    }

    if (id === 'setshopm_setembed') {
      const text = interaction.fields.getTextInputValue('embed_text');
      const image = interaction.fields.getTextInputValue('embed_image').trim();
      const data = db.get(guildId);
      data.shop.embedText = text;
      data.shop.embedImage = image;
      backupShopConfig(guildId);
      return interaction.reply({ components: [successEmbed('تم حفظ تخصيص اللوحة.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    // ═══════════════════════════ setshop: إرسال اللوحة ═══════════════════════════
    if (id === 'setshop_sendembed') {
      const row = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder().setCustomId('setshop_dosendembed').setPlaceholder('اختر الشات اللي هتتبعت فيه اللوحة').addChannelTypes(ChannelType.GuildText)
      );
      return interaction.reply({ content: 'اختر الشات اللي عايز ترسل فيه لوحة المتجر:', components: [row], flags: MessageFlags.Ephemeral });
    }

    if (id === 'setshop_dosendembed') {
      const channel = interaction.channels.first();
      if (!channel) return interaction.reply({ components: [errorEmbed('الشات مش موجود.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

      await channel.send({ components: [buildShopPanel(guildId)], flags: V2_FLAGS }).catch(() => {});
      return interaction.reply({ components: [successEmbed(`تم إرسال لوحة المتجر في <#${channel.id}>`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    // ═══════════════════════════ setshop: شات الإشعارات ═══════════════════════════
    if (id === 'setshop_setgeneral') {
      const channels = interaction.guild.channels.cache.filter(c => c.type === 0).map(c => ({ label: c.name.slice(0, 25), value: c.id })).slice(0, 25);
      return interaction.reply({
        content: 'اختر شات الإشعارات (اللي تُرسل فيه رسائل إنجاز المهام لو الـ DM مقفول):',
        components: [new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('setshop_dosetgeneral').setPlaceholder('اختر الشات...').addOptions(channels))],
        flags: MessageFlags.Ephemeral
      });
    }

    if (id === 'setshop_dosetgeneral') {
      const channelId = interaction.values[0];
      const data = db.get(guildId);
      data.shop.generalChannelId = channelId;
      backupShopConfig(guildId);
      return interaction.reply({ components: [successEmbed(`تم تعيين <#${channelId}> شاتاً للإشعارات.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    // ═══════════════════════════ resetpoints ═══════════════════════════
    if (id === 'resetpoints_cancel') {
      return interaction.update({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent('❌ **تم الإلغاء.**'))], flags: V2_FLAGS });
    }

    if (id === 'resetpoints_confirm') {
      const hasPerm = interaction.member?.permissions?.has('Administrator');
      if (!hasPerm) return interaction.reply({ content: '❌ معندكش صلاحية.', flags: MessageFlags.Ephemeral });

      await interaction.deferUpdate().catch(() => {});
      const data = db.get(guildId);
      const count = Object.keys(data.points).length;
      data.points = {};
      db.commit(guildId);

      return interaction.editReply({
        components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent(
          `## ✅ تم التصفير\n> تم تصفير نقاط **${count}** عضو في السيرفر.\n-# بواسطة ${interaction.user.username}`
        ))],
        flags: V2_FLAGS
      }).catch(() => {});
    }

  } catch (e) {
    console.error('[shop interactions] error:', e);
    try {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ components: [errorEmbed(e.message || String(e))], flags: V2_FLAGS | MessageFlags.Ephemeral });
      } else {
        await interaction.reply({ components: [errorEmbed(e.message || String(e))], flags: V2_FLAGS | MessageFlags.Ephemeral });
      }
    } catch {}
  }
};
