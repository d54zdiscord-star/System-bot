const {
  ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelType,
  ActionRowBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags
} = require('discord.js');
const db = require('../../utils/db');
const { successEmbed, V2_FLAGS } = require('../../utils/embed');
const { interfacePanelRows } = require('../../utils/tempvoice');

module.exports = async function handleTempVoiceConfigInteraction(interaction) {
  const guild = interaction.guild;
  const data = db.get(guild.id);
  const action = interaction.customId.replace('tvcfg_', '').replace('select', '').replace('_modal', '');

  if (interaction.isButton() && interaction.customId === 'tvcfg_waiting') {
    const menu = new ChannelSelectMenuBuilder()
      .setCustomId('tvcfg_waitingselect')
      .setChannelTypes(ChannelType.GuildVoice)
      .setPlaceholder('اختار قناة الانتظار...');
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isButton() && interaction.customId === 'tvcfg_category') {
    const menu = new ChannelSelectMenuBuilder()
      .setCustomId('tvcfg_categoryselect')
      .setChannelTypes(ChannelType.GuildCategory)
      .setPlaceholder('اختار الكاتيقوري...');
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isButton() && interaction.customId === 'tvcfg_trusted') {
    const menu = new RoleSelectMenuBuilder().setCustomId('tvcfg_trustedselect').setPlaceholder('اختار رول الموثق...');
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isButton() && interaction.customId === 'tvcfg_untrusted') {
    const menu = new RoleSelectMenuBuilder().setCustomId('tvcfg_untrustedselect').setPlaceholder('اختار رول الغير موثق...');
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isButton() && interaction.customId === 'tvcfg_jail') {
    const menu = new RoleSelectMenuBuilder().setCustomId('tvcfg_jailselect').setPlaceholder('اختار رول السجن...');
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isButton() && interaction.customId === 'tvcfg_soundboard') {
    const menu = new RoleSelectMenuBuilder().setCustomId('tvcfg_soundboardselect').setPlaceholder('اختار رول الساوند بورد...');
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isButton() && interaction.customId === 'tvcfg_adminroles') {
    const menu = new RoleSelectMenuBuilder()
      .setCustomId('tvcfg_adminrolesselect')
      .setPlaceholder('اختار الرولات الإدارية (تتحكم في كل الرومات)...')
      .setMinValues(0)
      .setMaxValues(10);
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isButton() && interaction.customId === 'tvcfg_image') {
    const modal = new ModalBuilder().setCustomId('tvcfg_image_modal').setTitle('صورة البانل');
    const input = new TextInputBuilder().setCustomId('tvcfg_image_input').setLabel('رابط الصورة').setStyle(TextInputStyle.Short).setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (interaction.isButton() && interaction.customId === 'tvcfg_infomsg') {
    const modal = new ModalBuilder().setCustomId('tvcfg_infomsg_modal').setTitle('رسالة Info');
    const input = new TextInputBuilder()
      .setCustomId('tvcfg_infomsg_input')
      .setLabel('ابعت رسالة الإنفو')
      .setStyle(TextInputStyle.Paragraph)
      .setMaxLength(1500)
      .setRequired(true)
      .setValue(data.tempVoice.infoMessage || '');
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (interaction.isModalSubmit() && interaction.customId === 'tvcfg_infomsg_modal') {
    data.tempVoice.infoMessage = interaction.fields.getTextInputValue('tvcfg_infomsg_input').trim();
    db.commit(guild.id);
    return interaction.reply({ components: [successEmbed('تم حفظ رسالة الإنفو - هتظهر لأي عضو يدوس على زرار ℹ️ في لوحة تحكم الروم (ليه هو بس).')], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  if (interaction.isModalSubmit() && interaction.customId === 'tvcfg_image_modal') {
    data.tempVoice.panelImage = interaction.fields.getTextInputValue('tvcfg_image_input');
    db.commit(guild.id);
    return interaction.reply({ components: [successEmbed('تم حفظ صورة البانل.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  if (interaction.isChannelSelectMenu() && interaction.customId === 'tvcfg_waitingselect') {
    data.tempVoice.waitingChannelId = interaction.values[0];
    db.commit(guild.id);
    return interaction.update({ content: `<:true:1533733814105407619> قناة الانتظار: <#${interaction.values[0]}>`, components: [] });
  }

  if (interaction.isChannelSelectMenu() && interaction.customId === 'tvcfg_categoryselect') {
    data.tempVoice.categoryId = interaction.values[0];
    db.commit(guild.id);
    return interaction.update({ content: `<:true:1533733814105407619> الكاتيقوري تم تحديدها.`, components: [] });
  }

  if (interaction.isRoleSelectMenu() && interaction.customId === 'tvcfg_trustedselect') {
    data.tempVoice.trustedRoleId = interaction.values[0];
    db.commit(guild.id);
    return interaction.update({ content: `<:true:1533733814105407619> رول الموثق: <@&${interaction.values[0]}>`, components: [] });
  }

  if (interaction.isRoleSelectMenu() && interaction.customId === 'tvcfg_untrustedselect') {
    data.tempVoice.untrustedRoleId = interaction.values[0];
    db.commit(guild.id);
    return interaction.update({ content: `<:true:1533733814105407619> رول الغير موثق: <@&${interaction.values[0]}>`, components: [] });
  }

  if (interaction.isRoleSelectMenu() && interaction.customId === 'tvcfg_jailselect') {
    data.tempVoice.jailRoleId = interaction.values[0];
    db.commit(guild.id);
    return interaction.update({ content: `<:true:1533733814105407619> رول السجن: <@&${interaction.values[0]}>`, components: [] });
  }

  if (interaction.isRoleSelectMenu() && interaction.customId === 'tvcfg_soundboardselect') {
    data.tempVoice.soundboardRoleId = interaction.values[0];
    db.commit(guild.id);
    return interaction.update({ content: `<:true:1533733814105407619> رول الساوند بورد: <@&${interaction.values[0]}>`, components: [] });
  }

  if (interaction.isRoleSelectMenu() && interaction.customId === 'tvcfg_adminrolesselect') {
    data.tempVoice.adminRoleIds = interaction.values;
    db.commit(guild.id);
    return interaction.update({
      content: interaction.values.length ? `<:true:1533733814105407619> الرولات الإدارية: ${interaction.values.map(id => `<@&${id}>`).join(', ')}` : '<:true:1533733814105407619> اتشالت كل الرولات الإدارية',
      components: []
    });
  }

  if (interaction.isButton() && interaction.customId === 'tvcfg_send') {
    if (!data.tempVoice.waitingChannelId || !data.tempVoice.categoryId) {
      return interaction.reply({ content: '<:fals:1533733827900473366> لازم تحدد قناة الانتظار والكاتيقوري الأول.', ephemeral: true });
    }
    const menu = new ChannelSelectMenuBuilder()
      .setCustomId('tvcfg_sendchannelselect')
      .setChannelTypes(ChannelType.GuildText)
      .setPlaceholder('اختار الروم اللي هتتبعت فيه لوحة التحكم...');
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isChannelSelectMenu() && interaction.customId === 'tvcfg_sendchannelselect') {
    const targetChannel = guild.channels.cache.get(interaction.values[0]);
    await targetChannel.send({
      content: 'ظبط التيمب بتاعتك من الأزرار اللي تحت، الشرح موجود في آخر زرار',
      components: interfacePanelRows()
    });
    return interaction.update({ content: `<:true:1533733814105407619> تم إرسال رسالة التحكم في ${targetChannel}`, components: [] });
  }
};
