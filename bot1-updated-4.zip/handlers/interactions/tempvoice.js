const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  UserSelectMenuBuilder,
  StringSelectMenuBuilder,
  PermissionsBitField,
  MessageFlags
} = require('discord.js');
const db = require('../../utils/db');
const { successEmbed, errorEmbed, baseEmbed, V2_FLAGS } = require('../../utils/embed');
const { getOwnedRoom, getCurrentRoom } = require('../../utils/tempvoice');
const { sendLog, mentionWithId } = require('../../utils/logs');

const REGIONS = [
  { label: 'تلقائي', value: 'auto' },
  { label: 'روتردام', value: 'rotterdam' },
  { label: 'فرانكفورت', value: 'frankfurt' },
  { label: 'لندن', value: 'london' },
  { label: 'الهند', value: 'india' },
  { label: 'سنغافورة', value: 'singapore' },
  { label: 'شرق أمريكا', value: 'us-east' },
  { label: 'غرب أمريكا', value: 'us-west' }
];

function ephemeralNoRoom(interaction) {
  return interaction.reply({
    components: [errorEmbed('لازم يكون عندك روم مؤقت مملوك ليك عشان تستخدم الزرار ده (لو الأونر مش موجود استخدم زرار استلام).')],
    flags: V2_FLAGS | MessageFlags.Ephemeral
  });
}

module.exports = async function handleTempVoiceInteraction(interaction) {
  const guild = interaction.guild;
  const data = db.get(guild.id);
  const action = interaction.customId.split('_')[1];

  // ================= أزرار تفتح مودال =================
  if (interaction.isButton() && action === 'name') {
    const owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) return ephemeralNoRoom(interaction);

    const modal = new ModalBuilder().setCustomId('tv_name_modal').setTitle('تغيير اسم الروم');
    const input = new TextInputBuilder()
      .setCustomId('tv_name_input')
      .setLabel('الاسم الجديد')
      .setStyle(TextInputStyle.Short)
      .setMaxLength(90)
      .setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (interaction.isButton() && action === 'limit') {
    const owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) return ephemeralNoRoom(interaction);

    const modal = new ModalBuilder().setCustomId('tv_limit_modal').setTitle('تحديد عدد الأعضاء');
    const input = new TextInputBuilder()
      .setCustomId('tv_limit_input')
      .setLabel('العدد (0 = بدون حد)')
      .setStyle(TextInputStyle.Short)
      .setMaxLength(2)
      .setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  // ================= مودالز (استقبال البيانات) =================
  if (interaction.isModalSubmit() && interaction.customId === 'tv_name_modal') {
    const owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) return ephemeralNoRoom(interaction);
    const name = interaction.fields.getTextInputValue('tv_name_input');
    const channel = guild.channels.cache.get(owned.channelId);
    const oldName = channel.name;
    await channel.setName(name).catch(() => {});
    sendLog(guild, 'logtempvoice', {
      title: '✏️ تغيير اسم الروم',
      fields: [
        { name: 'بواسطة', value: `${interaction.user}`, inline: true },
        { name: 'من', value: oldName, inline: true },
        { name: 'إلى', value: name, inline: true }
      ]
    });
    return interaction.reply({ components: [successEmbed(`تم تغيير اسم الروم لـ **${name}**`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  if (interaction.isModalSubmit() && interaction.customId === 'tv_limit_modal') {
    const owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) return ephemeralNoRoom(interaction);
    const raw = interaction.fields.getTextInputValue('tv_limit_input');
    const limit = parseInt(raw, 10);
    if (isNaN(limit) || limit < 0 || limit > 99) {
      return interaction.reply({ components: [errorEmbed('لازم رقم من 0 لحد 99.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const channel = guild.channels.cache.get(owned.channelId);
    await channel.setUserLimit(limit).catch(() => {});
    sendLog(guild, 'logtempvoice', {
      title: '👥 تحديد عدد الأعضاء',
      fields: [
        { name: 'بواسطة', value: `${interaction.user}`, inline: true },
        { name: 'الروم', value: `${channel}`, inline: true },
        { name: 'العدد', value: limit === 0 ? 'بدون حد' : `${limit}`, inline: true }
      ]
    });
    return interaction.reply({ components: [successEmbed(`تم تحديد عدد الأعضاء لـ **${limit === 0 ? 'بدون حد' : limit}**`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ================= Privacy =================
  if (interaction.isButton() && action === 'privacy') {
    const owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) return ephemeralNoRoom(interaction);

    const menu = new StringSelectMenuBuilder()
      .setCustomId('tv_privacyselect')
      .setPlaceholder('اختار نوع الخصوصية...')
      .addOptions([
        { label: 'قفل', description: 'الموثوقين بس يقدروا يدخلوا', value: 'lock', emoji: '🔒' },
        { label: 'فتح', description: 'أي حد يقدر يدخل', value: 'unlock', emoji: '🔓' },
        { label: 'قفل الشات', description: 'الموثوقين بس يقدروا يكتبوا في الشات', value: 'closechat', emoji: '💬' },
        { label: 'فتح الشات', description: 'أي حد يقدر يكتب في الشات', value: 'openchat', emoji: '📝' }
      ]);
    return interaction.reply({
      content: 'اختار نوع الخصوصية:',
      components: [new ActionRowBuilder().addComponents(menu)],
      ephemeral: true
    });
  }

  if (interaction.isStringSelectMenu() && interaction.customId === 'tv_privacyselect') {
    const owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) return ephemeralNoRoom(interaction);
    const channel = guild.channels.cache.get(owned.channelId);
    const choice = interaction.values[0];
    const everyone = guild.roles.everyone.id;

    if (choice === 'lock') {
      await channel.permissionOverwrites.edit(everyone, { Connect: false });
      owned.room.locked = true;
    } else if (choice === 'unlock') {
      await channel.permissionOverwrites.edit(everyone, { Connect: true });
      owned.room.locked = false;
    } else if (choice === 'closechat') {
      await channel.permissionOverwrites.edit(everyone, { SendMessages: false });
      owned.room.chatClosed = true;
    } else if (choice === 'openchat') {
      await channel.permissionOverwrites.edit(everyone, { SendMessages: true });
      owned.room.chatClosed = false;
    }
    db.commit(guild.id);
    const privacyLabels = { lock: '🔒 قفل الروم', unlock: '🔓 فتح الروم', closechat: '💬 قفل شات الروم', openchat: '📝 فتح شات الروم' };
    sendLog(guild, 'logtempvoice', {
      title: privacyLabels[choice] || 'تحديث إعدادات الخصوصية',
      fields: [
        { name: 'بواسطة', value: `${interaction.user}`, inline: true },
        { name: 'الروم', value: `${channel}`, inline: true }
      ]
    });
    return interaction.reply({ components: [successEmbed('تم تحديث إعدادات الخصوصية.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ================= Trust / Untrust / Invite / Kick / Block / Unblock (كلهم UserSelect) =================
  if (interaction.isButton() && ['trust', 'untrust', 'invite', 'kick', 'block', 'unblock', 'transfer', 'jail', 'soundboard'].includes(action)) {
    let owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) {
      // لو العضو معاه رول إداري متحدد، يقدر يتحكم في الروم اللي هو متصل بيها حاليًا حتى لو مش صاحبها
      const data = db.get(guild.id);
      const isAdminRole = (data.tempVoice.adminRoleIds || []).some(id => interaction.member.roles.cache.has(id));
      const current = getCurrentRoom(guild.id, interaction.member);
      if (isAdminRole && current) owned = current;
    }
    if (!owned) return ephemeralNoRoom(interaction);

    const actionLabels = {
      trust: 'إضافة موثوق', untrust: 'إزالة موثوق', invite: 'دعوة', kick: 'طرد',
      block: 'حظر', unblock: 'فك حظر', transfer: 'نقل الملكية له', jail: 'سجن', soundboard: 'إعطاء/سحب رول الساوند بورد'
    };
    const actionLabel = actionLabels[action] || action;
    const menu = new UserSelectMenuBuilder().setCustomId(`tv_${action}select`).setPlaceholder(`دور على العضو اللي عايز تعمله ${actionLabel}...`);
    return interaction.reply({
      content: `اختار العضو اللي عايز تعمله ${actionLabel}:`,
      components: [new ActionRowBuilder().addComponents(menu)],
      ephemeral: true
    });
  }

  if (interaction.isUserSelectMenu() && interaction.customId.startsWith('tv_') && interaction.customId.endsWith('select')) {
    const realAction = interaction.customId.replace('tv_', '').replace('select', '');
    let owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) {
      const data = db.get(guild.id);
      const isAdminRole = (data.tempVoice.adminRoleIds || []).some(id => interaction.member.roles.cache.has(id));
      const current = getCurrentRoom(guild.id, interaction.member);
      if (isAdminRole && current) owned = current;
    }
    if (!owned) return ephemeralNoRoom(interaction);

    const channel = guild.channels.cache.get(owned.channelId);
    const targetId = interaction.values[0];

    const logTv = (title) => sendLog(guild, 'logtempvoice', {
      title,
      fields: [
        { name: 'بواسطة', value: `${interaction.user}`, inline: true },
        { name: 'العضو', value: mentionWithId(targetId), inline: true },
        { name: 'الروم', value: `${channel}`, inline: true }
      ]
    });

    if (realAction === 'trust') {
      if (!owned.room.trusted.includes(targetId)) owned.room.trusted.push(targetId);
      await channel.permissionOverwrites.edit(targetId, { Connect: true, ViewChannel: true, Speak: true });
      db.commit(guild.id);
      logTv('🤝 إضافة موثوق');
      return interaction.reply({ components: [successEmbed(`تم إضافة <@${targetId}> كموثوق.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    if (realAction === 'untrust') {
      owned.room.trusted = owned.room.trusted.filter(id => id !== targetId);
      await channel.permissionOverwrites.delete(targetId).catch(() => {});
      db.commit(guild.id);
      logTv('❌ إزالة موثوق');
      return interaction.reply({ components: [successEmbed(`تم إزالة الثقة عن <@${targetId}>.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    if (realAction === 'invite') {
      await channel.permissionOverwrites.edit(targetId, { ViewChannel: true, Connect: true });
      const target = await guild.members.fetch(targetId).catch(() => null);
      if (target) target.send(`🔊 اتدعيت تنضم لروم **${channel.name}** في **${guild.name}**.`).catch(() => {});
      logTv('✉️ دعوة عضو');
      return interaction.reply({ components: [successEmbed(`تم دعوة <@${targetId}>.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    if (realAction === 'kick') {
      const target = await guild.members.fetch(targetId).catch(() => null);
      if (target && target.voice.channelId === channel.id) {
        await target.voice.disconnect().catch(() => {});
      }
      logTv('👢 طرد من الروم');
      return interaction.reply({ components: [successEmbed(`تم طرد <@${targetId}> من الروم.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    if (realAction === 'block') {
      if (!owned.room.blocked.includes(targetId)) owned.room.blocked.push(targetId);
      await channel.permissionOverwrites.edit(targetId, { ViewChannel: false, Connect: false });
      const target = await guild.members.fetch(targetId).catch(() => null);
      if (target && target.voice.channelId === channel.id) target.voice.disconnect().catch(() => {});
      db.commit(guild.id);
      logTv('🚫 حظر من الروم');
      return interaction.reply({ components: [successEmbed(`تم حظر <@${targetId}> من الروم.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    if (realAction === 'unblock') {
      owned.room.blocked = owned.room.blocked.filter(id => id !== targetId);
      await channel.permissionOverwrites.delete(targetId).catch(() => {});
      db.commit(guild.id);
      logTv('✅ فك حظر من الروم');
      return interaction.reply({ components: [successEmbed(`تم رفع الحظر عن <@${targetId}>.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    if (realAction === 'transfer') {
      owned.room.ownerId = targetId;
      await channel.permissionOverwrites.edit(targetId, {
        ManageChannels: true,
        MuteMembers: true,
        MoveMembers: true,
        ViewChannel: true,
        Connect: true
      });
      db.commit(guild.id);
      logTv('👑 نقل ملكية الروم');
      return interaction.reply({ components: [successEmbed(`تم نقل ملكية الروم لـ <@${targetId}>.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    if (realAction === 'jail') {
      const data = db.get(guild.id);
      const jailRoleId = data.tempVoice.jailRoleId;
      if (!jailRoleId) return interaction.reply({ components: [errorEmbed('رول السجن مش متحدد، لازم أونر يحدده من panel temp.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
      const target = await guild.members.fetch(targetId).catch(() => null);
      if (!target) return interaction.reply({ components: [errorEmbed('العضو مش موجود.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
      await target.roles.add(jailRoleId).catch(() => {});
      if (target.voice.channelId === channel.id) target.voice.disconnect().catch(() => {});
      logTv('⛓️ سجن عضو');
      return interaction.reply({ components: [successEmbed(`تم سجن <@${targetId}>.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    if (realAction === 'soundboard') {
      const data = db.get(guild.id);
      const soundboardRoleId = data.tempVoice.soundboardRoleId;
      if (!soundboardRoleId) return interaction.reply({ components: [errorEmbed('رول الساوند بورد مش متحدد، لازم أونر يحدده من panel temp.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
      const target = await guild.members.fetch(targetId).catch(() => null);
      if (!target) return interaction.reply({ components: [errorEmbed('العضو مش موجود.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
      const has = target.roles.cache.has(soundboardRoleId);
      if (has) await target.roles.remove(soundboardRoleId).catch(() => {});
      else await target.roles.add(soundboardRoleId).catch(() => {});
      logTv(has ? '🔇 إزالة رول الساوند بورد' : '🔈 إعطاء رول الساوند بورد');
      return interaction.reply({ components: [successEmbed(has ? `تم إزالة رول الساوند بورد من <@${targetId}>.` : `تم إعطاء رول الساوند بورد لـ <@${targetId}>.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
  }

  // ================= Region =================
  if (interaction.isButton() && action === 'region') {
    const owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) return ephemeralNoRoom(interaction);
    const menu = new StringSelectMenuBuilder()
      .setCustomId('tv_regionselect')
      .setPlaceholder('اختار الريجن...')
      .addOptions(REGIONS);
    return interaction.reply({
      content: 'اختار السيرفر ريجن:',
      components: [new ActionRowBuilder().addComponents(menu)],
      ephemeral: true
    });
  }

  if (interaction.isStringSelectMenu() && interaction.customId === 'tv_regionselect') {
    const owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) return ephemeralNoRoom(interaction);
    const channel = guild.channels.cache.get(owned.channelId);
    const region = interaction.values[0];
    const regionLabel = REGIONS.find(r => r.value === region)?.label || region;
    await channel.setRTCRegion(region === 'auto' ? null : region).catch(() => {});
    sendLog(guild, 'logtempvoice', {
      title: '🌍 تغيير الريجن',
      fields: [
        { name: 'بواسطة', value: `${interaction.user}`, inline: true },
        { name: 'الروم', value: `${channel}`, inline: true },
        { name: 'الريجن', value: regionLabel, inline: true }
      ]
    });
    return interaction.reply({ components: [successEmbed(`تم تغيير الريجن لـ **${regionLabel}**`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ================= Microphone =================
  if (interaction.isButton() && action === 'microphone') {
    const owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) return ephemeralNoRoom(interaction);
    const channel = guild.channels.cache.get(owned.channelId);
    const everyone = guild.roles.everyone.id;
    const current = channel.permissionOverwrites.cache.get(everyone);
    const currentlyMuted = current && current.deny.has(PermissionsBitField.Flags.Speak);

    await channel.permissionOverwrites.edit(everyone, { Speak: currentlyMuted ? null : false });
    sendLog(guild, 'logtempvoice', {
      title: currentlyMuted ? '🔊 فك كتم الميكروفون للكل' : '🔇 كتم الميكروفون لغير الموثوقين',
      fields: [
        { name: 'بواسطة', value: `${interaction.user}`, inline: true },
        { name: 'الروم', value: `${channel}`, inline: true }
      ]
    });
    return interaction.reply({
      components: [successEmbed(currentlyMuted ? 'تم إلغاء كتم الميكروفون للكل.' : 'تم كتم الميكروفون لكل الغير موثوقين.')],
      flags: V2_FLAGS | MessageFlags.Ephemeral
    });
  }

  // ================= Claim =================
  if (interaction.isButton() && action === 'claim') {
    const current = getCurrentRoom(guild.id, interaction.member);
    if (!current) {
      return interaction.reply({ components: [errorEmbed('لازم تكون متصل جوه روم مؤقت عشان تستلم ملكيته.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const ownerStillHere = current.room.ownerId && guild.members.cache.get(current.room.ownerId)?.voice.channelId === current.channelId;
    if (ownerStillHere) {
      return interaction.reply({ components: [errorEmbed('الأونر لسه موجود جوه الروم، متقدرش تستلم ملكيته.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    current.room.ownerId = interaction.user.id;
    db.commit(guild.id);
    const channel = guild.channels.cache.get(current.channelId);
    await channel.permissionOverwrites.edit(interaction.user.id, {
      ManageChannels: true,
      MuteMembers: true,
      MoveMembers: true,
      ViewChannel: true,
      Connect: true
    });
    sendLog(guild, 'logtempvoice', {
      title: '👑 استلام ملكية الروم',
      fields: [
        { name: 'العضو الجديد', value: `${interaction.user}`, inline: true },
        { name: 'الروم', value: `${channel}`, inline: true }
      ]
    });
    return interaction.reply({ components: [successEmbed('مبروك، بقيت أونر الروم دلوقتي 👑')], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ================= Transfer button handled above via UserSelect =================

  // ================= Delete =================
  if (interaction.isButton() && action === 'delete') {
    const owned = getOwnedRoom(guild.id, interaction.user.id);
    if (!owned) return ephemeralNoRoom(interaction);
    const channel = guild.channels.cache.get(owned.channelId);
    delete data.tempVoice.rooms[owned.channelId];
    db.commit(guild.id);
    sendLog(guild, 'logtempvoice', {
      title: '🗑️ حذف روم مؤقت (بالأمر)',
      fields: [
        { name: 'بواسطة', value: `${interaction.user}`, inline: true },
        { name: 'اسم الروم', value: channel ? channel.name : owned.channelId, inline: true }
      ]
    });
    await interaction.reply({ components: [successEmbed('تم حذف الروم.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    return channel.delete().catch(() => {});
  }

  // ================= Info =================
  if (interaction.isButton() && action === 'info') {
    // لو الأونر حدد رسالة إنفو من panel temp، دي اللي بتظهر (ليه هو بس - Ephemeral)
    // ولو مفيش رسالة محددة، بيتفرج على معلومات الروم الافتراضية بدالها
    const infoMessage = data.tempVoice.infoMessage;
    if (infoMessage) {
      return interaction.reply({
        components: [baseEmbed({ title: 'ℹ️ معلومات', description: infoMessage })],
        flags: V2_FLAGS | MessageFlags.Ephemeral
      });
    }

    const current = getCurrentRoom(guild.id, interaction.member) || getOwnedRoom(guild.id, interaction.user.id);
    if (!current) {
      return interaction.reply({ components: [errorEmbed('انت مش جوه روم مؤقت دلوقتي.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const room = current.room;
    return interaction.reply({
      components: [
        baseEmbed({
          title: 'معلومات الروم',
          fields: [
            { name: 'الأونر', value: `<@${room.ownerId}>`, inline: true },
            { name: 'مقفول؟', value: room.locked ? 'أيوه 🔒' : 'لأ 🔓', inline: true },
            { name: 'الشات مقفول؟', value: room.chatClosed ? 'أيوه' : 'لأ', inline: true },
            { name: 'عدد الموثوقين', value: `${room.trusted.length}`, inline: true },
            { name: 'عدد المحظورين', value: `${room.blocked.length}`, inline: true }
          ]
        })
      ],
      flags: V2_FLAGS | MessageFlags.Ephemeral
    });
  }
};
