const {
  ChannelSelectMenuBuilder,
  StringSelectMenuBuilder,
  ChannelType,
  ActionRowBuilder,
  MessageFlags
} = require('discord.js');
const db = require('../../utils/db');
const { successEmbed, errorEmbed, V2_FLAGS } = require('../../utils/embed');
const { saveWelcomeImage, clearWelcomeImage } = require('../../utils/welcomeImage');

module.exports = async function handleWelcomeInteraction(interaction) {
  const guild = interaction.guild;
  const data = db.get(guild.id);

  // ---- زرار رسالة الويلكم ----
  if (interaction.isButton() && interaction.customId === 'editwlc_message') {
    await interaction.reply({
      components: [successEmbed('ابعت نص رسالة الويلكم دلوقتي في الشات - استخدم `{user}` `{inviter}` `{servername}` `{membercount}`. عندك دقيقتين.')],
      flags: V2_FLAGS | MessageFlags.Ephemeral
    });
    const collected = await interaction.channel
      .awaitMessages({ filter: m => m.author.id === interaction.user.id, max: 1, time: 120000 })
      .catch(() => null);
    if (!collected || !collected.size) {
      return interaction.followUp({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const reply = collected.first();
    data.settings.welcome.message = reply.content;
    db.commit(guild.id);
    reply.delete().catch(() => {});
    return interaction.followUp({ components: [successEmbed('تم حفظ رسالة الويلكم بنجاح.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ---- زرار شات الويلكم ----
  if (interaction.isButton() && interaction.customId === 'editwlc_channel') {
    const menu = new ChannelSelectMenuBuilder()
      .setCustomId('editwlc_channelselect')
      .setChannelTypes(ChannelType.GuildText)
      .setPlaceholder('اختار شات الويلكم...');
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], flags: MessageFlags.Ephemeral });
  }

  // ---- زرار رسالة الخاص (DM) - اختياري ----
  if (interaction.isButton() && interaction.customId === 'editwlc_dm') {
    await interaction.reply({
      components: [successEmbed('ابعت نص رسالة الخاص دلوقتي، أو اكتب "إلغاء" عشان توقفها. عندك دقيقتين.')],
      flags: V2_FLAGS | MessageFlags.Ephemeral
    });
    const collected = await interaction.channel
      .awaitMessages({ filter: m => m.author.id === interaction.user.id, max: 1, time: 120000 })
      .catch(() => null);
    if (!collected || !collected.size) {
      return interaction.followUp({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const reply = collected.first();
    const text = reply.content.trim();
    reply.delete().catch(() => {});
    if (text === 'إلغاء') {
      data.settings.welcome.dmMessage = null;
      data.settings.welcome.dmEnabled = false;
      db.commit(guild.id);
      return interaction.followUp({ components: [successEmbed('اتلغت رسالة الخاص - النظام هيشتغل عادي من غيرها.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    data.settings.welcome.dmMessage = text;
    data.settings.welcome.dmEnabled = true;
    db.commit(guild.id);
    return interaction.followUp({ components: [successEmbed('تم حفظ رسالة الخاص وتفعيلها.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ---- زرار صورة الويلكم (صورة مرفوعة فعليًا، مش لينك) ----
  if (interaction.isButton() && interaction.customId === 'editwlc_image') {
    await interaction.reply({
      components: [successEmbed('ابعت الصورة كمرفق (attachment) في الشات دلوقتي - عندك دقيقتين. اكتب "إلغاء" عشان تشيل الصورة الحالية.')],
      flags: V2_FLAGS | MessageFlags.Ephemeral
    });

    const collected = await interaction.channel
      .awaitMessages({
        filter: m => m.author.id === interaction.user.id && (m.attachments.size > 0 || m.content.trim() === 'إلغاء'),
        max: 1,
        time: 120000
      })
      .catch(() => null);

    if (!collected || !collected.size) {
      return interaction.followUp({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    const reply = collected.first();

    if (reply.content.trim() === 'إلغاء') {
      clearWelcomeImage(guild.id);
      data.settings.welcome.imageUrl = null;
      data.settings.welcome.imageExt = null;
      db.commit(guild.id);
      reply.delete().catch(() => {});
      return interaction.followUp({ components: [successEmbed('تم إلغاء صورة الويلكم.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    const attachment = reply.attachments.first();
    if (!attachment.contentType || !attachment.contentType.startsWith('image/')) {
      return interaction.followUp({ components: [errorEmbed('لازم ترفع صورة فعلية (مش لينك ولا ملف تاني).')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    // بنحفظ الصورة محليًا على سيرفر البوت (مش بس اللينك) عشان لينكات مرفقات ديسكورد
    // بتنتهي صلاحيتها بعد فترة وبعدين الصورة تختفي/متظهرش لما عضو جديد يدخل
    const ext = await saveWelcomeImage(guild.id, attachment);
    data.settings.welcome.imageExt = ext;
    data.settings.welcome.imageUrl = attachment.url;
    db.commit(guild.id);
    reply.delete().catch(() => {});
    return interaction.followUp({ components: [successEmbed('تم حفظ صورة الويلكم.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ---- زرار تشغيل/تعطيل الويلكم ----
  if (interaction.isButton() && interaction.customId === 'editwlc_toggle') {
    data.settings.welcome.enabled = !data.settings.welcome.enabled;
    db.commit(guild.id);
    return interaction.reply({
      components: [successEmbed(data.settings.welcome.enabled ? 'تم تشغيل الويلكم <:true:1533733814105407619>' : 'تم تعطيل الويلكم ⛔ - مش هيبعت رسايل ترحيب لحد ما تشغله تاني.')],
      flags: V2_FLAGS | MessageFlags.Ephemeral
    });
  }

  // ---- زرار شكل رسالة الويلكم ----
  if (interaction.isButton() && interaction.customId === 'editwlc_mode') {
    const menu = new StringSelectMenuBuilder()
      .setCustomId('editwlc_modeselect')
      .setPlaceholder('اختار شكل رسالة الويلكم...')
      .addOptions(
        { label: 'رسالة عادية + صورة بس', description: 'من غير إيمبد، نص عادي وتحته الصورة', value: 'text' },
        { label: 'رسالة إمبد', description: 'الشكل الحالي - نص جوه إيمبد', value: 'embed' }
      );
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], flags: MessageFlags.Ephemeral });
  }

  // ---- استلام اختيار شكل الرسالة ----
  if (interaction.isStringSelectMenu() && interaction.customId === 'editwlc_modeselect') {
    data.settings.welcome.mode = interaction.values[0];
    db.commit(guild.id);
    const label = interaction.values[0] === 'text' ? 'رسالة عادية + صورة بس' : 'رسالة إمبد';
    return interaction.update({ components: [successEmbed(`تم تحديد شكل الويلكم: ${label}`)], flags: V2_FLAGS });
  }

  // ---- استلام اختيار الشات ----
  if (interaction.isChannelSelectMenu() && interaction.customId === 'editwlc_channelselect') {
    const channelId = interaction.values[0];
    data.settings.welcome.channelId = channelId;
    db.commit(guild.id);
    return interaction.update({
      components: [successEmbed(`تم تحديد <#${channelId}> كشات الويلكم.`)],
      flags: V2_FLAGS
    });
  }
};
