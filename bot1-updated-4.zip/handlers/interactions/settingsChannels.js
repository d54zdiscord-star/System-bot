const { PermissionsBitField } = require('discord.js');
const db = require('../../utils/db');
const { successEmbed, V2_FLAGS } = require('../../utils/embed');

module.exports = async function handleSettingsChannelsInteraction(interaction) {
  const guild = interaction.guild;
  const data = db.get(guild.id);

  if (interaction.isChannelSelectMenu() && interaction.customId === 'zajil_channelselect') {
    const channelId = interaction.values[0];
    const channel = guild.channels.cache.get(channelId);
    data.settings.zajilChannelId = channelId;
    db.commit(guild.id);

    // الشات ده يشوفه الأونرز بس (أونر السيرفر + أونرات البوت المسجلين)
    await channel.permissionOverwrites.edit(guild.roles.everyone, { ViewChannel: false }).catch(() => {});
    await channel.permissionOverwrites.edit(guild.ownerId, { ViewChannel: true }).catch(() => {});
    for (const ownerId of data.owners) {
      await channel.permissionOverwrites.edit(ownerId, { ViewChannel: true }).catch(() => {});
    }
    await channel.permissionOverwrites.edit(guild.members.me.id, {
      ViewChannel: true,
      SendMessages: true
    }).catch(() => {});

    return interaction.update({
      components: [successEmbed(`تم تفعيل الزاجل في ${channel} - يشوفه الأونرز بس`)],
      flags: V2_FLAGS
    });
  }
  if (interaction.isChannelSelectMenu() && interaction.customId === 'setonli_channelselect') {
    const channelId = interaction.values[0];
    const channel = guild.channels.cache.get(channelId);
    data.settings.onlineVoiceChannelId = channelId;
    db.commit(guild.id);

    const { joinVoiceOnlineChannel } = require('../../utils/onlineVoice');
    try {
      joinVoiceOnlineChannel(channel);
    } catch (e) {
      console.error('[setonli] فشل دخول الفويس:', e.message);
    }

    return interaction.update({ content: `<:true:1533733814105407619> تم تعيين ${channel} ودخل البوت الفويس`, components: [] });
  }

  if (interaction.isChannelSelectMenu() && interaction.customId === 'setsug_channelselect') {
    const channelId = interaction.values[0];
    data.settings.suggestions.channelId = channelId;
    db.commit(guild.id);
    return interaction.update({ content: `<:true:1533733814105407619> تم تحديد <#${channelId}> لشات الاقتراحات`, components: [] });
  }
};
