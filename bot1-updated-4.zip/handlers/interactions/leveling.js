const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ChannelSelectMenuBuilder,
  ChannelType,
  RoleSelectMenuBuilder,
  UserSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags
} = require('discord.js');
const db = require('../../utils/db');
const { successEmbed, errorEmbed, V2_FLAGS } = require('../../utils/embed');
const { getUserLevelData, levelFromXp, totalXpForLevel, announceLevelUp } = require('../../utils/leveling');

module.exports = async function handleLevelingInteraction(interaction) {
  const guild = interaction.guild;
  const data = db.get(guild.id);

  if (interaction.isButton() && interaction.customId === 'lvl_toggle') {
    data.leveling.enabled = !data.leveling.enabled;
    db.commit(guild.id);
    return interaction.reply({ components: [successEmbed(`نظام اللفلات دلوقتي ${data.leveling.enabled ? 'مفعل <:true:1533733814105407619>' : 'معطل <:fals:1533733827900473366>'}`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  if (interaction.isButton() && interaction.customId === 'lvl_setchannel') {
    const menu = new ChannelSelectMenuBuilder().setCustomId('lvl_channelselect').setChannelTypes(ChannelType.GuildText).setPlaceholder('اختار روم الإشعارات...');
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isChannelSelectMenu() && interaction.customId === 'lvl_channelselect') {
    data.leveling.channelId = interaction.values[0];
    db.commit(guild.id);
    return interaction.update({ content: `<:true:1533733814105407619> روم الإشعارات: <#${interaction.values[0]}>`, components: [] });
  }

  if (interaction.isButton() && interaction.customId === 'lvl_message') {
    const modal = new ModalBuilder().setCustomId('lvl_message_modal').setTitle('رسالة اللفل أب');
    const input = new TextInputBuilder()
      .setCustomId('lvl_message_input')
      .setLabel('استخدم {user} {level} {type}')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (interaction.isModalSubmit() && interaction.customId === 'lvl_message_modal') {
    data.leveling.levelUpMessage = interaction.fields.getTextInputValue('lvl_message_input');
    db.commit(guild.id);
    return interaction.reply({ components: [successEmbed('تم حفظ رسالة اللفل أب.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  if (interaction.isButton() && (interaction.customId === 'lvl_addchatrole' || interaction.customId === 'lvl_addvoicerole')) {
    const type = interaction.customId === 'lvl_addchatrole' ? 'chat' : 'voice';
    const modal = new ModalBuilder().setCustomId(`lvl_level_modal_${type}`).setTitle('رقم اللفل');
    const input = new TextInputBuilder().setCustomId('lvl_level_input').setLabel('رقم اللفل').setStyle(TextInputStyle.Short).setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (interaction.isModalSubmit() && interaction.customId.startsWith('lvl_level_modal_')) {
    const type = interaction.customId.replace('lvl_level_modal_', '');
    const level = parseInt(interaction.fields.getTextInputValue('lvl_level_input'), 10);
    if (isNaN(level) || level < 1) {
      return interaction.reply({ content: '<:fals:1533733827900473366> رقم اللفل لازم يكون صحيح.', ephemeral: true });
    }
    const menu = new RoleSelectMenuBuilder().setCustomId(`lvl_roleselect_${type}_${level}`).setPlaceholder('اختار الرول...');
    return interaction.reply({ content: `اختار الرول اللي هيتديله عند وصول لفل ${type === 'chat' ? 'شات' : 'فويس'} رقم ${level}:`, components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isRoleSelectMenu() && interaction.customId.startsWith('lvl_roleselect_')) {
    const [, , type, level] = interaction.customId.split('_');
    const roleMap = type === 'chat' ? data.leveling.chatRoles : data.leveling.voiceRoles;
    roleMap[level] = interaction.values[0];
    db.commit(guild.id);
    return interaction.update({ content: `<:true:1533733814105407619> تم ربط <@&${interaction.values[0]}> بلفل ${level} (${type === 'chat' ? 'شات' : 'فويس'})`, components: [] });
  }

  if (interaction.isButton() && interaction.customId === 'lvl_manage_xp') {
    const menu = new UserSelectMenuBuilder().setCustomId('lvl_manage_userselect').setPlaceholder('اختار العضو...');
    return interaction.reply({ components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }

  if (interaction.isUserSelectMenu() && interaction.customId === 'lvl_manage_userselect') {
    const userId = interaction.values[0];
    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`lvl_xp_add_chat_${userId}`).setLabel('زود XP شات').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`lvl_xp_sub_chat_${userId}`).setLabel('قلل XP شات').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(`lvl_xp_set_chat_${userId}`).setLabel('حدد لفل شات').setStyle(ButtonStyle.Secondary)
    );
    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`lvl_xp_add_voice_${userId}`).setLabel('زود XP فويس').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`lvl_xp_sub_voice_${userId}`).setLabel('قلل XP فويس').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(`lvl_xp_set_voice_${userId}`).setLabel('حدد لفل فويس').setStyle(ButtonStyle.Secondary)
    );
    return interaction.update({ content: `اختار الإجراء اللي عايزه لـ <@${userId}>:`, components: [row1, row2] });
  }

  if (interaction.isButton() && /^lvl_xp_(add|sub|set)_(chat|voice)_(\d+)$/.test(interaction.customId)) {
    const [, action, type, userId] = interaction.customId.match(/^lvl_xp_(add|sub|set)_(chat|voice)_(\d+)$/);
    const modal = new ModalBuilder()
      .setCustomId(`lvl_xp_modal_${action}_${type}_${userId}`)
      .setTitle(action === 'set' ? 'حدد اللفل' : 'قيمة الـ XP');
    const input = new TextInputBuilder()
      .setCustomId('lvl_xp_value')
      .setLabel(action === 'set' ? 'رقم اللفل الجديد' : 'قد إيه XP')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (interaction.isModalSubmit() && interaction.customId.startsWith('lvl_xp_modal_')) {
    const [, action, type, userId] = interaction.customId.match(/^lvl_xp_modal_(add|sub|set)_(chat|voice)_(\d+)$/);
    const value = parseInt(interaction.fields.getTextInputValue('lvl_xp_value'), 10);
    if (isNaN(value) || value < 0) {
      return interaction.reply({ components: [errorEmbed('القيمة لازم تكون رقم صحيح.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    const user = getUserLevelData(guild.id, userId);
    const xpKey = type === 'chat' ? 'chatXp' : 'voiceXp';
    const levelKey = type === 'chat' ? 'chatLevel' : 'voiceLevel';
    const oldLevel = user[levelKey];

    if (action === 'set') {
      user[xpKey] = totalXpForLevel(value);
      user[levelKey] = value;
    } else if (action === 'add') {
      user[xpKey] += value;
      user[levelKey] = levelFromXp(user[xpKey]);
    } else {
      user[xpKey] = Math.max(0, user[xpKey] - value);
      user[levelKey] = levelFromXp(user[xpKey]);
    }
    db.commit(guild.id);

    if (user[levelKey] > oldLevel && data.leveling.enabled) {
      const member = await guild.members.fetch(userId).catch(() => null);
      if (member) await announceLevelUp(guild, member, type, user[levelKey], interaction.channel);
    }

    const typeLabel = type === 'chat' ? 'شات' : 'فويس';
    const actionLabel = action === 'set' ? `تحديد لفل ${typeLabel} لـ **${value}**` : `${action === 'add' ? 'زيادة' : 'تقليل'} XP ${typeLabel} بـ **${value}**`;
    return interaction.reply({
      components: [successEmbed(`تم ${actionLabel} لـ <@${userId}> (اللفل الحالي: ${user[levelKey]})`)],
      flags: V2_FLAGS | MessageFlags.Ephemeral
    });
  }
};
