const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const db = require('../../utils/db');
const { successEmbed, errorEmbed, V2_FLAGS } = require('../../utils/embed');
const { sendLog, sendDetailedLog, mentionWithId } = require('../../utils/logs');

module.exports = async function handleJoinLogInteraction(interaction) {
  const id = interaction.customId;
  const guild = interaction.guild;

  // ====== زرار عرض الآي دي - متاح للكل ======
  if (id.startsWith('joinlog_id_')) {
    const userId = id.replace('joinlog_id_', '');
    return interaction.reply({
      components: [successEmbed(`آي دي العضو: \`${userId}\``)],
      flags: V2_FLAGS | MessageFlags.Ephemeral
    });
  }

  // ====== زرار السجن ======
  if (id.startsWith('joinlog_prison_')) {
    const userId = id.replace('joinlog_prison_', '');
    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ components: [errorEmbed('معندكش صلاحية تسجن أعضاء.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return interaction.reply({ components: [errorEmbed('العضو مش موجود في السيرفر (يمكن غادر).')], flags: V2_FLAGS | MessageFlags.Ephemeral });

    let role = guild.roles.cache.find(r => r.name === '⛓️│مسجون');
    if (!role) {
      role = await guild.roles.create({ name: '⛓️│مسجون', color: 'DarkerGrey' }).catch(() => null);
      if (role) {
        for (const channel of guild.channels.cache.values()) {
          if (channel.isTextBased() || channel.isVoiceBased()) {
            channel.permissionOverwrites.edit(role, { ViewChannel: false }).catch(() => {});
          }
        }
      }
    }
    if (!role) return interaction.reply({ components: [errorEmbed('متقدرش أعمل رول السجن - تأكد من صلاحيات البوت.')], flags: V2_FLAGS | MessageFlags.Ephemeral });

    const data = db.get(guild.id);
    const savedRoleIds = member.roles.cache.filter(r => r.id !== guild.id).map(r => r.id);
    data.prisoners[member.id] = { savedRoleIds, reason: 'سجن من لوق الانضمام', mod: interaction.user.id, date: Date.now(), jailed: true };
    data.infractions[member.id] = data.infractions[member.id] || { mutes: [], bans: [], prisons: [] };
    data.infractions[member.id].prisons.push({ reason: 'سجن من لوق الانضمام', mod: interaction.user.id, date: Date.now() });
    db.commit(guild.id);

    await member.roles.set([role.id]).catch(() => {});

    sendLog(guild, 'logprisonunprison', {
      title: '⛓️ سجن عضو',
      fields: [
        { name: 'العضو', value: mentionWithId(member), inline: true },
        { name: 'بواسطة', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'من', value: 'لوق الانضمام', inline: true }
      ]
    });

    return interaction.reply({ components: [successEmbed(`تم سجن ${member} وشيل كل رولاته.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ====== زرار الباند ======
  if (id.startsWith('joinlog_ban_')) {
    const userId = id.replace('joinlog_ban_', '');
    if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
      return interaction.reply({ components: [errorEmbed('معندكش صلاحية تبند أعضاء.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    await guild.members.ban(userId, { reason: `باند من لوق الانضمام بواسطة ${interaction.user.tag}` }).catch(() => {});

    sendLog(guild, 'logbanunban', {
      title: '🔨 باند عضو',
      fields: [
        { name: 'العضو', value: mentionWithId(userId), inline: true },
        { name: 'بواسطة', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'من', value: 'لوق الانضمام', inline: true }
      ]
    });

    return interaction.reply({ components: [successEmbed(`تم باند <@${userId}>.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ====== زرار فك السجن ======
  if (id.startsWith('joinlog_unprison_')) {
    const userId = id.replace('joinlog_unprison_', '');
    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ components: [errorEmbed('معندكش صلاحية تفك سجن أعضاء.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return interaction.reply({ components: [errorEmbed('العضو مش موجود في السيرفر (يمكن غادر).')], flags: V2_FLAGS | MessageFlags.Ephemeral });

    const data = db.get(guild.id);
    const prisoner = data.prisoners[member.id];
    const role = guild.roles.cache.find(r => r.name === '⛓️│مسجون');

    if (role) await member.roles.remove(role).catch(() => {});
    const rolesToRestore = (prisoner?.savedRoleIds || []).filter(id => guild.roles.cache.has(id));
    if (rolesToRestore.length) await member.roles.add(rolesToRestore).catch(() => {});

    delete data.prisoners[member.id];
    db.commit(guild.id);

    sendLog(guild, 'logprisonunprison', {
      title: '🔓 فك سجن عضو',
      fields: [
        { name: 'العضو', value: mentionWithId(member), inline: true },
        { name: 'بواسطة', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'من', value: 'لوق الانضمام', inline: true }
      ]
    });

    return interaction.reply({ components: [successEmbed(`تم فك سجن ${member} ورجعله رولاته اللي كانت معاه قبل السجن.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ====== زرار التايم (إسكات كتابي) ======
  if (id.startsWith('joinlog_timeout_')) {
    const userId = id.replace('joinlog_timeout_', '');
    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ components: [errorEmbed('معندكش صلاحية تعمل تايم لأعضاء.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return interaction.reply({ components: [errorEmbed('العضو مش موجود في السيرفر (يمكن غادر).')], flags: V2_FLAGS | MessageFlags.Ephemeral });

    const durationMs = 10 * 60 * 1000; // 10 دقايق افتراضي
    await member.timeout(durationMs, 'تايم من لوق الانضمام').catch(() => {});
    const data = db.get(guild.id);
    data.infractions[member.id] = data.infractions[member.id] || { mutes: [], bans: [], prisons: [] };
    data.infractions[member.id].mutes.push({ reason: 'تايم من لوق الانضمام', mod: interaction.user.id, date: Date.now(), duration: durationMs });
    db.commit(guild.id);

    sendLog(guild, 'logmute', {
      title: '🔇 تايم',
      fields: [
        { name: 'العضو', value: mentionWithId(member), inline: true },
        { name: 'بواسطة', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'المدة', value: '10 دقايق', inline: true }
      ]
    });

    return interaction.reply({ components: [successEmbed(`تم عمل تايم لـ ${member} لمدة 10 دقايق.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ====== زرار فك التايم ======
  if (id.startsWith('joinlog_untimeout_')) {
    const userId = id.replace('joinlog_untimeout_', '');
    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ components: [errorEmbed('معندكش صلاحية تفك تايم أعضاء.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return interaction.reply({ components: [errorEmbed('العضو مش موجود في السيرفر (يمكن غادر).')], flags: V2_FLAGS | MessageFlags.Ephemeral });

    await member.timeout(null).catch(() => {});
    sendLog(guild, 'logmute', {
      title: '🔊 فك تايم',
      fields: [
        { name: 'العضو', value: mentionWithId(member), inline: true },
        { name: 'بواسطة', value: `<@${interaction.user.id}>`, inline: true }
      ]
    });

    return interaction.reply({ components: [successEmbed(`تم فك تايم ${member}.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }

  // ====== زرار الطرد ======
  if (id.startsWith('joinlog_kick_')) {
    const userId = id.replace('joinlog_kick_', '');
    if (!interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) {
      return interaction.reply({ components: [errorEmbed('معندكش صلاحية تطرد أعضاء.')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return interaction.reply({ components: [errorEmbed('العضو مش موجود في السيرفر (يمكن غادر).')], flags: V2_FLAGS | MessageFlags.Ephemeral });

    await member.kick('طرد من لوق الانضمام').catch(() => {});
    sendLog(guild, 'logkick', {
      title: '👢 طرد عضو',
      fields: [
        { name: 'العضو', value: mentionWithId(userId), inline: true },
        { name: 'بواسطة', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'من', value: 'لوق الانضمام', inline: true }
      ]
    });

    return interaction.reply({ components: [successEmbed(`تم طرد <@${userId}>.`)], flags: V2_FLAGS | MessageFlags.Ephemeral });
  }
};
