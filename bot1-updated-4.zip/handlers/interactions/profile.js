// ─────────────────────────────────────────────────────────────────
//  handlers/interactions/profile.js
//  كل تفاعلات نظام البروفايل (بوستات/متابعة/لايك/إعدادات)
//  منقولة حرفيًا من بوت ١ (Commands/Puplic/profile.js -> init)
// ─────────────────────────────────────────────────────────────────
const {
  ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, ContainerBuilder, TextDisplayBuilder,
  SeparatorBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder,
  MessageFlags
} = require('discord.js');
const fs = require('fs');
const path = require('path');
const profileDB = require('../../utils/profileDB');
const { buildProfileCanvas, POSTS_DIR, BANNERS_DIR } = require('../../utils/profileCard');
const { errorEmbed, V2_FLAGS } = require('../../utils/embed');

function getProfile(userId) {
  return profileDB.get(userId);
}
function saveProfile() {
  profileDB.commit();
}

const { buildOwnerButtons, buildViewButtons } = require('../../utils/profileCard');

// ─── أزرار الإعدادات ───
function buildSettingsButtons(targetId) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`pf_addpost_${targetId}`).setLabel('إضافة بوست').setEmoji('1477958685388181615').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`pf_delpost_${targetId}`).setLabel('حذف بوست').setEmoji('1463691945510436895').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`pf_setbio_${targetId}`).setLabel('نبذة عني').setEmoji('✏️').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`pf_setbanner_${targetId}`).setLabel('تغيير البنر').setEmoji('🖼️').setStyle(ButtonStyle.Secondary)
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`pf_setbg_${targetId}`).setLabel('تغيير اللون').setEmoji('🎨').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`pf_setinsta_${targetId}`).setLabel('Instagram').setEmoji('📸').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`pf_settiktok_${targetId}`).setLabel('TikTok').setEmoji('🎵').setStyle(ButtonStyle.Secondary)
    )
  ];
}

// ─── تحديث رسالة البروفايل ───
async function updateProfileMessage(interaction, client, targetId, components, page = 0) {
  try {
    const buffer = await buildProfileCanvas(client, targetId, page);
    if (!buffer) return;
    const att = new AttachmentBuilder(buffer, { name: 'profile.png' });
    const originalMsg = await interaction.channel.messages.fetch(interaction.message.id).catch(() => null);
    if (originalMsg) await originalMsg.edit({ files: [att], components }).catch(() => {});
  } catch (e) {
    console.error('[profile] updateProfileMessage error:', e.message);
  }
}

// ─── تنزيل صورة من مرفق ديسكورد وحفظها محليًا (بدل axios - fetch الأصلي في Node) ───
async function downloadAttachment(url, filePath) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status}`);
  const buffer = Buffer.from(await res.arrayBuffer());
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, buffer);
}

// ─── بناء رسالة عرض بوست واحد ───
async function buildPostEmbed(client, targetId, postIndex) {
  const profile = getProfile(targetId);
  const post = profile.posts[postIndex];
  if (!post) return null;

  const user = await client.users.fetch(targetId).catch(() => null);
  const postPath = path.join(POSTS_DIR, post.file);

  const container = new ContainerBuilder()
    .addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(user?.displayAvatarURL({ size: 1024 }) || '')))
    .addSeparatorComponents(new SeparatorBuilder())
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`## بوست رقم ${postIndex + 1}`))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`**${user?.username || 'Unknown'}**`))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`> <:emoji_42:1478306101182201889> **لايكات:** ${post.likes?.length || 0}`))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# بوست ${postIndex + 1} من ${profile.posts.length}`));

  if (fs.existsSync(postPath)) {
    const att = new AttachmentBuilder(postPath, { name: `post_${postIndex + 1}.png` });
    container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(`attachment://post_${postIndex + 1}.png`)));
    return { container, att };
  }
  return { container, att: null };
}

module.exports = async function profileInteractions(interaction, client) {
  if (!interaction.guild) return;

  try {
    const parts = interaction.customId.split('_');
    if (parts[0] !== 'pf') return;
    const action = parts[1];
    const targetId = parts[2];
    if (!action || !targetId) return;

    const viewerId = interaction.user.id;
    const isOwner = viewerId === targetId;
    const currentPage = parseInt(parts[3] ?? '0') || 0;

    // ── إعدادات ──
    if (action === 'settings') {
      if (!isOwner) return interaction.reply({ content: 'الأمر مش ليك.', flags: MessageFlags.Ephemeral });
      return interaction.reply({ content: '**⚙️ إعدادات البروفايل**', components: buildSettingsButtons(targetId), flags: MessageFlags.Ephemeral });
    }

    // ── التنقل بين الصفحات ──
    if (action === 'prevpage' || action === 'nextpage') {
      const newPage = action === 'nextpage' ? 1 : 0;
      const components = isOwner ? buildOwnerButtons(targetId, newPage) : buildViewButtons(targetId, newPage);
      await interaction.deferUpdate();
      return updateProfileMessage(interaction, client, targetId, components, newPage);
    }

    // ── Show: عرض قائمة البوستات ──
    if (action === 'show') {
      const profile = getProfile(targetId);
      if (profile.posts.length === 0) return interaction.reply({ content: 'مفيش بوستات لسه.', flags: MessageFlags.Ephemeral });

      const options = profile.posts.map((p, i) => ({ label: `بوست ${i + 1}`, description: `${p.likes?.length || 0} لايك`, value: i.toString(), emoji: '1476252979228053677' }));
      return interaction.reply({
        content: '**اختر البوست اللي تبي تشوفه:**',
        components: [new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId(`pf_showpost_${targetId}`).setPlaceholder('اختر رقم البوست...').addOptions(options))],
        flags: MessageFlags.Ephemeral
      });
    }

    // ── عرض البوست المحدد ──
    if (action === 'showpost') {
      const idx = parseInt(interaction.values[0]);
      const result = await buildPostEmbed(client, targetId, idx);
      if (!result) return interaction.reply({ content: 'البوست غير موجود.', flags: MessageFlags.Ephemeral });

      const { container, att } = result;
      container.addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`pf_showpostlike_${targetId}_${idx}`).setLabel('لايك').setEmoji('1461768577546981437').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(`pf_showpostfollow_${targetId}`).setLabel('متابعة').setEmoji('1461768625726816400').setStyle(ButtonStyle.Secondary)
        )
      );

      const replyData = { flags: V2_FLAGS | MessageFlags.Ephemeral, components: [container] };
      if (att) replyData.files = [att];
      return interaction.reply(replyData);
    }

    // ── لايك من البوست المعروض ──
    if (action === 'showpostlike') {
      const idx = parseInt(parts[3]);
      const profile = getProfile(targetId);
      const post = profile.posts[idx];
      if (!post) return interaction.reply({ content: 'البوست غير موجود.', flags: MessageFlags.Ephemeral });
      if (!post.likes) post.likes = [];
      if (post.likes.includes(viewerId)) {
        post.likes = post.likes.filter(id => id !== viewerId);
        await interaction.reply({ content: 'تم إزالة اللايك.', flags: MessageFlags.Ephemeral });
      } else {
        post.likes.push(viewerId);
        await interaction.reply({ content: 'تم اللايك.', flags: MessageFlags.Ephemeral });
      }
      saveProfile();
      return;
    }

    // ── فولو من البوست المعروض ──
    if (action === 'showpostfollow') {
      if (isOwner) return interaction.reply({ content: 'متقدرش تتابع نفسك.', flags: MessageFlags.Ephemeral });
      const tp = getProfile(targetId);
      const vp = getProfile(viewerId);
      const already = tp.followers.includes(viewerId);
      if (already) {
        tp.followers = tp.followers.filter(id => id !== viewerId);
        vp.following = vp.following.filter(id => id !== targetId);
        await interaction.reply({ content: 'تم إلغاء المتابعة.', flags: MessageFlags.Ephemeral });
      } else {
        tp.followers.push(viewerId);
        vp.following.push(targetId);
        await interaction.reply({ content: 'تمت المتابعة.', flags: MessageFlags.Ephemeral });
      }
      saveProfile();
      return;
    }

    // ── تغيير البنر ──
    if (action === 'setbanner') {
      if (!isOwner) return interaction.reply({ content: 'الأمر مش ليك.', flags: MessageFlags.Ephemeral });
      await interaction.reply({ content: '**🖼️ أرسل صورة البنر:**', flags: MessageFlags.Ephemeral });
      const collected = await interaction.channel.awaitMessages({ filter: m => m.author.id === targetId && m.attachments.size > 0, max: 1, time: 60000 }).catch(() => null);
      const msg = collected?.first();
      if (!msg) return interaction.editReply({ content: '❌ انتهت المهلة' }).catch(() => {});
      const attachment = msg.attachments.first();
      try {
        const fname = `banner_${targetId}_${Date.now()}.png`;
        const fpath = path.join(BANNERS_DIR, fname);
        await downloadAttachment(attachment.url, fpath);
        await msg.delete().catch(() => {});
        const profile = getProfile(targetId);
        profile.bannerFile = fpath;
        saveProfile();
        await interaction.editReply({ content: '✅ تم حفظ البنر' }).catch(() => {});
        await updateProfileMessage(interaction, client, targetId, buildOwnerButtons(targetId, currentPage), currentPage);
      } catch (e) {
        await msg.delete().catch(() => {});
        await interaction.editReply({ content: `❌ خطأ: ${e.message}` }).catch(() => {});
      }
      return;
    }

    // ── About Me ──
    if (action === 'setbio') {
      if (!isOwner) return interaction.reply({ content: 'الأمر مش ليك.', flags: MessageFlags.Ephemeral });
      await interaction.reply({ content: '**✏️ أرسل نبذة عنك (حد أقصى 100 حرف):**', flags: MessageFlags.Ephemeral });
      const collected = await interaction.channel.awaitMessages({ filter: m => m.author.id === targetId, max: 1, time: 30000 }).catch(() => null);
      const msg = collected?.first();
      await msg?.delete().catch(() => {});
      if (!msg) return interaction.editReply({ content: '❌ انتهت المهلة' }).catch(() => {});
      const profile = getProfile(targetId);
      profile.bio = msg.content.trim().slice(0, 100);
      saveProfile();
      await interaction.editReply({ content: '✅ تم حفظ النبذة' }).catch(() => {});
      await updateProfileMessage(interaction, client, targetId, buildOwnerButtons(targetId, currentPage), currentPage);
      return;
    }

    // ── تغيير لون الخلفية ──
    if (action === 'setbg') {
      if (!isOwner) return interaction.reply({ content: 'الأمر مش ليك.', flags: MessageFlags.Ephemeral });
      const bgColors = [
        { label: '⚫ أسود', value: '#1a1a2e' },
        { label: '🔴 أحمر', value: '#2d0a0a' },
        { label: '🔵 أزرق', value: '#0a1628' },
        { label: '🟢 أخضر', value: '#0a2010' },
        { label: '🟣 بنفسجي', value: '#1a0a2e' },
        { label: '🟡 ذهبي', value: '#261e00' },
        { label: '🌸 وردي', value: '#2e0a18' },
        { label: '⚫ رمادي', value: '#1e1e1e' }
      ];
      const sel = new StringSelectMenuBuilder().setCustomId(`pf_pickbg_${targetId}`).setPlaceholder('🎨 اختر لون الخلفية').addOptions(bgColors);
      return interaction.reply({ content: '**🎨 اختر لون الخلفية:**', components: [new ActionRowBuilder().addComponents(sel)], flags: MessageFlags.Ephemeral });
    }

    if (action === 'pickbg') {
      if (!isOwner) return interaction.reply({ content: 'الأمر مش ليك.', flags: MessageFlags.Ephemeral });
      const profile = getProfile(targetId);
      profile.bg = interaction.values[0];
      saveProfile();
      await interaction.update({ content: '✅ تم تغيير لون الخلفية', components: [] }).catch(() => {});
      await updateProfileMessage(interaction, client, targetId, buildOwnerButtons(targetId, currentPage), currentPage);
      return;
    }

    // ── Instagram ──
    if (action === 'setinsta') {
      if (!isOwner) return interaction.reply({ content: 'الأمر مش ليك.', flags: MessageFlags.Ephemeral });
      await interaction.reply({ content: '**📸 أرسل يوزر الإنستقرام (بدون @):**', flags: MessageFlags.Ephemeral });
      const collected = await interaction.channel.awaitMessages({ filter: m => m.author.id === targetId, max: 1, time: 30000 }).catch(() => null);
      const msg = collected?.first();
      await msg?.delete().catch(() => {});
      if (!msg) return interaction.editReply({ content: '❌ انتهت المهلة' }).catch(() => {});
      const profile = getProfile(targetId);
      profile.insta = msg.content.trim().replace('@', '');
      saveProfile();
      await interaction.editReply({ content: `✅ تم: @${profile.insta}` }).catch(() => {});
      await updateProfileMessage(interaction, client, targetId, buildOwnerButtons(targetId, currentPage), currentPage);
      return;
    }

    // ── TikTok ──
    if (action === 'settiktok') {
      if (!isOwner) return interaction.reply({ content: 'الأمر مش ليك.', flags: MessageFlags.Ephemeral });
      await interaction.reply({ content: '**🎵 أرسل يوزر التيك توك (بدون @):**', flags: MessageFlags.Ephemeral });
      const collected = await interaction.channel.awaitMessages({ filter: m => m.author.id === targetId, max: 1, time: 30000 }).catch(() => null);
      const msg = collected?.first();
      await msg?.delete().catch(() => {});
      if (!msg) return interaction.editReply({ content: '❌ انتهت المهلة' }).catch(() => {});
      const profile = getProfile(targetId);
      profile.tiktok = msg.content.trim().replace('@', '');
      saveProfile();
      await interaction.editReply({ content: `✅ تم: @${profile.tiktok}` }).catch(() => {});
      await updateProfileMessage(interaction, client, targetId, buildOwnerButtons(targetId, currentPage), currentPage);
      return;
    }

    // ── فولو / أنفولو (من الزرار الرئيسي) ──
    if (action === 'follow') {
      if (isOwner) return interaction.reply({ content: 'متقدرش تتابع نفسك.', flags: MessageFlags.Ephemeral });
      const tp = getProfile(targetId);
      const vp = getProfile(viewerId);
      const already = tp.followers.includes(viewerId);
      if (already) {
        tp.followers = tp.followers.filter(id => id !== viewerId);
        vp.following = vp.following.filter(id => id !== targetId);
        await interaction.reply({ content: 'تم إلغاء المتابعة.', flags: MessageFlags.Ephemeral });
      } else {
        tp.followers.push(viewerId);
        vp.following.push(targetId);
        await interaction.reply({ content: 'تمت المتابعة.', flags: MessageFlags.Ephemeral });
      }
      saveProfile();
      await updateProfileMessage(interaction, client, targetId, buildViewButtons(targetId, currentPage), currentPage);
      return;
    }

    // ── لايك: عرض قائمة البوستات ──
    if (action === 'like') {
      const profile = getProfile(targetId);
      if (profile.posts.length === 0) return interaction.reply({ content: 'مفيش بوستات لسه.', flags: MessageFlags.Ephemeral });
      const options = profile.posts.map((p, i) => ({ label: `بوست ${i + 1}`, description: `${p.likes?.length || 0} لايك`, value: i.toString(), emoji: '1461768577546981437' }));
      return interaction.reply({
        content: '**اختر البوست:**',
        components: [new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId(`pf_dolike_${targetId}`).setPlaceholder('اختر البوست').addOptions(options))],
        flags: MessageFlags.Ephemeral
      });
    }

    // ── تنفيذ اللايك ──
    if (action === 'dolike') {
      const idx = parseInt(interaction.values[0]);
      const profile = getProfile(targetId);
      const post = profile.posts[idx];
      if (!post) return interaction.reply({ content: 'البوست غير موجود.', flags: MessageFlags.Ephemeral });
      if (!post.likes) post.likes = [];
      if (post.likes.includes(viewerId)) {
        post.likes = post.likes.filter(id => id !== viewerId);
        await interaction.reply({ content: 'تم إزالة اللايك.', flags: MessageFlags.Ephemeral });
      } else {
        post.likes.push(viewerId);
        await interaction.reply({ content: 'تم اللايك.', flags: MessageFlags.Ephemeral });
      }
      saveProfile();
      await updateProfileMessage(interaction, client, targetId, buildViewButtons(targetId, currentPage), currentPage);
      return;
    }

    // ── فولورز / فولوينج ──
    if (action === 'followers') {
      const profile = getProfile(targetId);
      if (profile.followers.length === 0) return interaction.reply({ content: 'مفيش متابعين لسه.', flags: MessageFlags.Ephemeral });
      const list = profile.followers.map((id, i) => `**${i + 1}.** <@${id}>`).join('\n');
      return interaction.reply({ content: `**المتابعون:**\n${list}`, flags: MessageFlags.Ephemeral });
    }

    if (action === 'following') {
      const profile = getProfile(targetId);
      if (profile.following.length === 0) return interaction.reply({ content: 'لسه مش متابع حد.', flags: MessageFlags.Ephemeral });
      const list = profile.following.map((id, i) => `**${i + 1}.** <@${id}>`).join('\n');
      return interaction.reply({ content: `**تتابع:**\n${list}`, flags: MessageFlags.Ephemeral });
    }

    // ── إضافة بوست (حد أقصى 12) ──
    if (action === 'addpost') {
      if (!isOwner) return interaction.reply({ content: 'غير مسموح.', flags: MessageFlags.Ephemeral });
      const profile = getProfile(targetId);
      if (profile.posts.length >= 12) return interaction.reply({ content: 'الحد الأقصى 12 بوست.', flags: MessageFlags.Ephemeral });

      await interaction.reply({ content: '**أرسل الصورة الآن في الشات (60 ثانية) وستُحذف تلقائياً:**', flags: MessageFlags.Ephemeral });
      const collected = await interaction.channel.awaitMessages({ filter: m => m.author.id === viewerId && m.attachments.size > 0, max: 1, time: 60000 }).catch(() => null);
      if (!collected || collected.size === 0) return interaction.followUp({ content: 'انتهى الوقت.', flags: MessageFlags.Ephemeral });

      const msg = collected.first();
      const attachment = msg.attachments.first();
      const fileName = `${targetId}_${Date.now()}.png`;
      const filePath = path.join(POSTS_DIR, fileName);

      try {
        await downloadAttachment(attachment.url, filePath);
      } catch (e) {
        console.error('[profile] save error:', e.message);
        await msg.delete().catch(() => {});
        return interaction.followUp({ content: 'فشل حفظ الصورة، حاول مرة ثانية.', flags: MessageFlags.Ephemeral });
      }

      await msg.delete().catch(() => {});
      profile.posts.push({ file: fileName, likes: [] });
      saveProfile();

      const newPage = profile.posts.length > 6 ? 1 : 0;
      await updateProfileMessage(interaction, client, targetId, buildOwnerButtons(targetId, newPage), newPage);
      return interaction.followUp({ content: `تم إضافة البوست #${profile.posts.length}.`, flags: MessageFlags.Ephemeral });
    }

    // ── حذف بوست ──
    if (action === 'delpost') {
      if (!isOwner) return interaction.reply({ content: 'غير مسموح.', flags: MessageFlags.Ephemeral });
      const profile = getProfile(targetId);
      if (profile.posts.length === 0) return interaction.reply({ content: 'مفيش بوستات لسه.', flags: MessageFlags.Ephemeral });
      const options = profile.posts.map((p, i) => ({ label: `بوست ${i + 1}`, description: `${p.likes?.length || 0} لايك`, value: i.toString(), emoji: '1463691945510436895' }));
      return interaction.reply({
        content: '**اختر البوست للحذف:**',
        components: [new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId(`pf_confirmdelete_${targetId}`).setPlaceholder('اختر البوست').addOptions(options))],
        flags: MessageFlags.Ephemeral
      });
    }

    // ── تأكيد الحذف ──
    if (action === 'confirmdelete') {
      if (!isOwner) return interaction.reply({ content: 'غير مسموح.', flags: MessageFlags.Ephemeral });
      const idx = parseInt(interaction.values[0]);
      const profile = getProfile(targetId);
      const deleted = profile.posts.splice(idx, 1)[0];
      if (deleted) {
        const filePath = path.join(POSTS_DIR, deleted.file);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      }
      saveProfile();
      await updateProfileMessage(interaction, client, targetId, buildOwnerButtons(targetId, 0), 0);
      return interaction.reply({ content: 'تم حذف البوست.', flags: MessageFlags.Ephemeral });
    }

  } catch (e) {
    console.error('[profile] error:', e.message);
    try {
      if (interaction.replied || interaction.deferred) await interaction.followUp({ content: `حدث خطأ: ${e.message}`, flags: MessageFlags.Ephemeral });
      else await interaction.reply({ content: `حدث خطأ: ${e.message}`, flags: MessageFlags.Ephemeral });
    } catch {}
  }
};
