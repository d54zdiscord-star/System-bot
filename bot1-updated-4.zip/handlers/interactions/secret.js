const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags
} = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, errorEmbed, V2_FLAGS } = require('../../utils/embed');
const secrets = require('../../utils/secretMessages');
const permissions = require('../../utils/permissions');

module.exports = async function handleSecretInteraction(interaction) {
  const guild = interaction.guild;
  const data = db.get(guild.id);

  // ---- زرار "اكتب رسالتك" ----
  if (interaction.isButton() && interaction.customId.startsWith('secret_write_')) {
    const [, , senderId, targetId] = interaction.customId.split('_');
    if (interaction.user.id !== senderId) {
      return interaction.reply({ components: [errorEmbed('الزرار ده مش ليك')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }

    const modal = new ModalBuilder()
      .setCustomId(`secret_modal_${senderId}_${targetId}`)
      .setTitle('رسالة سرية');
    const input = new TextInputBuilder()
      .setCustomId('secret_modal_input')
      .setLabel('اكتب رسالتك هنا')
      .setStyle(TextInputStyle.Paragraph)
      .setMaxLength(1000)
      .setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  // ---- إرسال المودال ----
  if (interaction.isModalSubmit() && interaction.customId.startsWith('secret_modal_')) {
    const [, , senderId, targetId] = interaction.customId.split('_');
    const text = interaction.fields.getTextInputValue('secret_modal_input');

    const logChannelId = data.settings.zajilChannelId;
    if (!logChannelId || !guild.channels.cache.get(logChannelId)) {
      return interaction.reply({
        components: [errorEmbed('نظام الزاجل مش متفعل لسه، لازم أونر يستخدم أمر zajil الأول')],
        flags: V2_FLAGS | MessageFlags.Ephemeral
      });
    }
    const logChannel = guild.channels.cache.get(logChannelId);

    const id = secrets.create(senderId, targetId, text);
    const sender = await guild.members.fetch(senderId).catch(() => null);
    const target = await guild.members.fetch(targetId).catch(() => null);
    const now = Math.floor(Date.now() / 1000);

    // الرسالة اللي بتظهر في نفس الشات اللي اتكتب فيه الأمر - محتواها متخبي وبيتشاف بزرار "عرض" بس
    const publicEmbed = baseEmbed({
      description:
        `👁️ رسالة مخفية\n\n` +
        `من: <@${senderId}>\n` +
        `إلى: <@${targetId}>\n\n` +
        `مرسل من: ${sender ? sender.user.username : senderId} | <t:${now}:f>`
    });
    const viewRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`secret_view_${id}`).setLabel('عرض').setEmoji('💬').setStyle(ButtonStyle.Primary)
    );
    await interaction.channel.send({ components: [publicEmbed, viewRow], flags: V2_FLAGS });

    // نمسح رسالة "اضغط الزر لكتابة رسالتك السرية" الأصلية بعد ما اتبعتت الرسالة الجديدة
    if (interaction.message) interaction.message.delete().catch(() => {});

    // اللوج الإداري - بيتبعت بالنص الكامل عشان الأدمنز يقدروا يراقبوا (لو حد شتم مثلاً)
    const logEmbed = baseEmbed({
      description:
        `👁️ لوج رسالة مخفية\n\n` +
        `من: <@${senderId}> (${sender ? sender.user.tag : senderId})\n` +
        `إلى: <@${targetId}> (${target ? target.user.tag : targetId})\n` +
        `الشات: <#${interaction.channel.id}>\n\n` +
        `النص:\n${text}\n\n` +
        `<t:${now}:f>`
    });
    await logChannel.send({ components: [logEmbed], flags: V2_FLAGS });

    return interaction.reply({ content: '<:true:1533733814105407619> اتبعتت رسالتك السرية', ephemeral: true }); // رسالة نصية بسيطة من غير كونتينر - مفيش خط جانبي أصلاً
  }

  // ---- زرار "عرض" ----
  if (interaction.isButton() && interaction.customId.startsWith('secret_view_')) {
    const id = interaction.customId.replace('secret_view_', '');
    const secret = secrets.get(id);
    if (!secret) {
      return interaction.reply({ components: [errorEmbed('الرسالة دي مبقتش متاحة')], flags: V2_FLAGS | MessageFlags.Ephemeral });
    }
    const isOwner = permissions.isBotOwnerInGuild(interaction.member);
    if (interaction.user.id !== secret.senderId && interaction.user.id !== secret.targetId && !isOwner) {
      return interaction.reply({ content: '<:fals:1533733827900473366> الرسالة دي مش ليك!', ephemeral: true });
    }
    return interaction.reply({
      components: [baseEmbed({ description: secret.text })],
      flags: V2_FLAGS | MessageFlags.Ephemeral
    });
  }
};
