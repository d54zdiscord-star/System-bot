const fs = require('fs');
const path = require('path');

// تحويل اسم مجلد الأوامر (إنجليزي) لاسم الفئة العربي اللي هيظهر في !help
const CATEGORY_LABELS = {
  general: 'عامة',
  settings: 'إعدادات',
  admin: 'إدارة',
  roles: 'رولات',
  voice: 'رومات صوتية',
  tickets: 'تكتات',
  owner: 'مالك البوت',
  chats: 'شاتات',
  shop: 'المتجر',
  giveaway: 'السحوبات',
  automod: 'الإشراف التلقائي'
};

/**
 * يقرأ كل ملفات الأوامر جوه commands/<category>/*.js
 * كل ملف بيصدّر array من الأوامر أو أمر واحد.
 * بيرجع Map<name, command> + بيسجل الـ aliases كمان.
 */
function loadCommands(client) {
  const commandsPath = path.join(__dirname, '..', 'commands');
  const categories = fs.readdirSync(commandsPath).filter(f =>
    fs.statSync(path.join(commandsPath, f)).isDirectory()
  );

  for (const category of categories) {
    const catPath = path.join(commandsPath, category);
    const files = fs.readdirSync(catPath).filter(f => f.endsWith('.js'));

    for (const file of files) {
      delete require.cache[require.resolve(path.join(catPath, file))];
      const mod = require(path.join(catPath, file));
      const list = Array.isArray(mod) ? mod : [mod];

      for (const cmd of list) {
        if (!cmd.name || !cmd.execute) continue;
        cmd.category = cmd.category || CATEGORY_LABELS[category] || category;
        client.commands.set(cmd.name, cmd);
        if (Array.isArray(cmd.aliases)) {
          for (const alias of cmd.aliases) {
            client.aliases.set(alias, cmd.name);
          }
        }
      }
    }
  }

  console.log(`✅ تم تحميل ${client.commands.size} أمر من ${categories.length} فئات.`);
}

module.exports = loadCommands;
