const { PermissionFlagsBits, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, successEmbed, errorEmbed, usageEmbed, V2_FLAGS } = require('../../utils/embed');
const config = require('../../config');

function prefixOf(guildId) {
  return db.get(guildId).prefix || config.defaultPrefix;
}

async function ask(message, question) {
  await message.channel.send({ components: [baseEmbed({ description: question })], flags: V2_FLAGS });
  const collected = await message.channel
    .awaitMessages({ filter: m => m.author.id === message.author.id, max: 1, time: 120000 })
    .catch(() => null);
  if (!collected || !collected.size) return null;
  return collected.first();
}

function chatFeatures(data, channelId) {
  data.settings.chatFeatures = data.settings.chatFeatures || {};
  if (!data.settings.chatFeatures[channelId]) {
    data.settings.chatFeatures[channelId] = {
      autoLine: false,
      autoLineImage: null,
      autoReact: null,
      applayOnly: false,
      picOnly: false
    };
  }
  return data.settings.chatFeatures[channelId];
}

module.exports = [
  {
    name: 'ochat',
    usage: '',
    description: 'تحديد شات الأوامر (تفعيل/تعطيل تقييد الأوامر لهذا الشات)',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const data = db.get(message.guild.id);
      data.settings.commandChannels = data.settings.commandChannels || [];
      const idx = data.settings.commandChannels.indexOf(message.channel.id);
      if (idx === -1) {
        data.settings.commandChannels.push(message.channel.id);
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed('تم تحديد الشات ده كشات أوامر رسمي.')], flags: V2_FLAGS });
      } else {
        data.settings.commandChannels.splice(idx, 1);
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed('تم إلغاء تحديد الشات ده.')], flags: V2_FLAGS });
      }
    }
  },
  {
    name: 'hide',
    usage: '',
    description: 'إخفاء الشات عن الكل',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: false });
      return message.channel.send({ components: [successEmbed('تم إخفاء الشات.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'unhide',
    usage: '',
    description: 'إظهار الشات للكل',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: true });
      return message.reply({ components: [successEmbed('تم إظهار الشات.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'lock',
    usage: '',
    description: 'قفل الروم',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false });
      return message.channel.send({ components: [successEmbed('🔒 تم قفل الروم.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'unlock',
    usage: '',
    description: 'فتح الروم',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: true });
      return message.channel.send({ components: [successEmbed('🔓 تم فتح الروم.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'slowmode',
    usage: '[ثواني]',
    description: 'الوضع البطيء',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message, args) {
      const seconds = parseInt(args[0], 10);
      if (isNaN(seconds) || seconds < 0 || seconds > 21600) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await message.channel.setRateLimitPerUser(seconds);
      return message.reply({ components: [successEmbed(seconds === 0 ? 'تم إلغاء الوضع البطيء.' : `تم تفعيل الوضع البطيء (${seconds} ثانية).`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'autoreply',
    usage: '[الكلمة] | [الرد] (أو من غير حاجة والبوت هيسألك)',
    description: 'إضافة كلمة وردها',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message, args) {
      const data = db.get(message.guild.id);

      // لو مكتوب بالطريقة القديمة "كلمة | رد" في نفس الأمر
      if (args.length) {
        const full = args.join(' ');
        const [trigger, ...rest] = full.split('|');
        const response = rest.join('|').trim();
        if (!trigger || !response) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
        data.autoReplies[trigger.trim().toLowerCase()] = response;
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed(`لو حد كتب **${trigger.trim()}** هرد **${response}**`)], flags: V2_FLAGS });
      }

      // من غير أي حاجة - البوت يسأل خطوة خطوة
      const triggerMsg = await ask(message, '✍️ اكتب الكلمة أو الجملة اللي عايز تضيف ليها رد تلقائي:');
      if (!triggerMsg) return message.channel.send({ components: [errorEmbed('انتهى الوقت، حاول تاني.')], flags: V2_FLAGS });
      const trigger = triggerMsg.content.trim().toLowerCase();
      if (!trigger) return message.channel.send({ components: [errorEmbed('لازم تكتب كلمة أو جملة صحيحة.')], flags: V2_FLAGS });

      const responseMsg = await ask(message, `تمام <:true:1533733814105407619> دلوقتي اكتب الرد اللي عايز البوت يرد بيه لما حد يكتب **${triggerMsg.content.trim()}**:`);
      if (!responseMsg) return message.channel.send({ components: [errorEmbed('انتهى الوقت، حاول تاني.')], flags: V2_FLAGS });
      const response = responseMsg.content.trim();
      if (!response) return message.channel.send({ components: [errorEmbed('لازم تكتب رد صحيح.')], flags: V2_FLAGS });

      data.autoReplies[trigger] = response;
      db.commit(message.guild.id);
      return message.channel.send({ components: [successEmbed(`تم <:true:1533733814105407619> لو حد كتب **${triggerMsg.content.trim()}** هرد **${response}**`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'dreply',
    usage: '',
    description: 'حذف كلمة وردها (بتختار من شريط اختيار)',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const data = db.get(message.guild.id);
      const entries = Object.entries(data.autoReplies || {});
      if (!entries.length) return message.reply({ components: [errorEmbed('مفيش ردود تلقائية مسجلة أصلاً.')], flags: V2_FLAGS });

      const options = entries.slice(0, 25).map(([trigger, response]) => ({
        label: trigger.slice(0, 100),
        description: response.slice(0, 100),
        value: trigger
      }));

      const menu = new StringSelectMenuBuilder()
        .setCustomId('dreply_select')
        .setPlaceholder('اختار الجملة اللي عايز تشيل الرد التلقائي بتاعها...')
        .addOptions(options);

      const note = entries.length > 25 ? '\n-# (في أكتر من 25 رد، ظاهرلك أول 25 بس)' : '';
      const sent = await message.reply({
        components: [baseEmbed({ description: `اختار من تحت الجملة اللي عايز تشيل الرد بتاعها:${note}` }), new ActionRowBuilder().addComponents(menu)],
        flags: V2_FLAGS
      });

      const collector = sent.createMessageComponentCollector({ time: 60000, max: 1 });
      collector.on('collect', async i => {
        if (i.user.id !== message.author.id) return i.reply({ content: 'الأمر ده مش ليك.', ephemeral: true });
        const trigger = i.values[0];
        delete data.autoReplies[trigger];
        db.commit(message.guild.id);
        await i.update({ components: [successEmbed(`تم حذف الرد التلقائي بتاع **${trigger}**`)], flags: V2_FLAGS });
      });

      collector.on('end', collected => {
        if (!collected.size) sent.edit({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS }).catch(() => {});
      });
    }
  },
  {
    name: 'mhide',
    usage: '[منشن العضو]',
    description: 'إخفاء الشات عن عضو',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await message.channel.permissionOverwrites.edit(member.id, { ViewChannel: false });
      return message.reply({ components: [successEmbed(`تم إخفاء الشات عن ${member}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'mshow',
    usage: '[منشن العضو]',
    description: 'إظهار الشات لعضو',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await message.channel.permissionOverwrites.edit(member.id, { ViewChannel: true });
      return message.reply({ components: [successEmbed(`تم إظهار الشات لـ ${member}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'autoline',
    usage: '',
    description: 'فاصل تلقائي بالشات',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      const data = db.get(message.guild.id);
      const feat = chatFeatures(data, message.channel.id);
      feat.autoLine = true;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed('تم تفعيل الفاصل التلقائي في الشات ده.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'setpickautoline',
    usage: '(أرفق صورة)',
    description: 'تحديد صورة الفاصل',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      const attachment = message.attachments.first();
      if (!attachment) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      const feat = chatFeatures(data, message.channel.id);
      feat.autoLineImage = attachment.url;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed('تم تحديد صورة الفاصل.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'unline',
    usage: '',
    description: 'تعطيل الفاصل التلقائي',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      const data = db.get(message.guild.id);
      const feat = chatFeatures(data, message.channel.id);
      feat.autoLine = false;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed('تم تعطيل الفاصل التلقائي.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'setreact',
    usage: '[إيموجي]',
    description: 'رياكشن تلقائي بالشات',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message, args) {
      const emoji = args[0];
      if (!emoji) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      const feat = chatFeatures(data, message.channel.id);
      feat.autoReact = emoji;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم تفعيل الرياكشن التلقائي ${emoji}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'unreact',
    usage: '',
    description: 'تعطيل الرياكشن التلقائي',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      const data = db.get(message.guild.id);
      const feat = chatFeatures(data, message.channel.id);
      feat.autoReact = null;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed('تم تعطيل الرياكشن التلقائي.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'applay',
    usage: '',
    description: 'تفعيل المنشن والصور فقط',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      const data = db.get(message.guild.id);
      const feat = chatFeatures(data, message.channel.id);
      feat.applayOnly = true;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed('تم تفعيل وضع (منشن وصور فقط) في الشات ده.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'disapplay',
    usage: '',
    description: 'تعطيل المنشن والصور فقط',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      const data = db.get(message.guild.id);
      const feat = chatFeatures(data, message.channel.id);
      feat.applayOnly = false;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed('تم تعطيل وضع (منشن وصور فقط).')], flags: V2_FLAGS });
    }
  },
  {
    name: 'setpic',
    usage: '',
    description: 'شات الصور فقط',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      const data = db.get(message.guild.id);
      const feat = chatFeatures(data, message.channel.id);
      feat.picOnly = true;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed('تم تفعيل وضع (صور فقط) في الشات ده.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'unpic',
    usage: '',
    description: 'تعطيل شات الصور فقط',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message) {
      const data = db.get(message.guild.id);
      const feat = chatFeatures(data, message.channel.id);
      feat.picOnly = false;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed('تم تعطيل وضع (صور فقط).')], flags: V2_FLAGS });
    }
  }
];
