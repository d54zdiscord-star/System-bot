const {
  PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize,
  ChannelSelectMenuBuilder, ChannelType, RoleSelectMenuBuilder,
  ModalBuilder, TextInputBuilder, TextInputStyle
} = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, successEmbed, errorEmbed, V2_FLAGS } = require('../../utils/embed');
const config = require('../../config');

function divider() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

// ── Default config ──
function defaultAutomod() {
  return {
    enabled: false,
    logChannel: null,
    whitelistRoles: [],
    whitelistChannels: [],
    filters: {
      spam: {
        enabled: false,
        threshold: 5,
        interval: 5000,
        deleteMessage: true,
        punishmentEnabled: false,
        punishmentType: 'warn',
        punishmentDuration: 3600000
      },
      caps: {
        enabled: false,
        threshold: 70,
        deleteMessage: true,
        punishmentEnabled: false,
        punishmentType: 'warn',
        punishmentDuration: 3600000
      },
      invites: {
        enabled: false,
        deleteMessage: true,
        punishmentEnabled: false,
        punishmentType: 'warn',
        punishmentDuration: 3600000
      },
      links: {
        enabled: false,
        deleteMessage: true,
        punishmentEnabled: false,
        punishmentType: 'warn',
        punishmentDuration: 3600000
      },
      badwords: {
        enabled: false,
        words: [],
        deleteMessage: true,
        punishmentEnabled: false,
        punishmentType: 'warn',
        punishmentDuration: 3600000
      },
      mentions: {
        enabled: false,
        threshold: 5,
        deleteMessage: true,
        punishmentEnabled: false,
        punishmentType: 'warn',
        punishmentDuration: 3600000
      }
    }
  };
}

function getAutomod(guildId) {
  const data = db.get(guildId);
  if (!data.automod) data.automod = defaultAutomod();
  return data.automod;
}

const FILTER_INFO = {
  spam:    { emoji: '💬', name: 'سبام', desc: 'تكرار رسايل بسرعة' },
  caps:    { emoji: '🔤', name: 'كابيتال', desc: 'حروف كبيرة كتير' },
  invites: { emoji: '📨', name: 'دعوات', desc: 'روابط دعوة ديسكورد' },
  links:   { emoji: '🔗', name: 'روابط', desc: 'أي روابط خارجية' },
  badwords:{ emoji: '🚫', name: 'كلمات محظورة', desc: 'كلمات ممنوعة' },
  mentions:{ emoji: '📢', name: 'منشن سبام', desc: 'منشن كتير مرة واحدة' }
};

const PUNISHMENT_NAMES = {
  warn: 'تحذير',
  timeout: 'تايم أوت',
  kick: 'طرد',
  ban: 'بان'
};

// ── Build main panel ──
function buildPanel(am) {
  const container = new ContainerBuilder();
  container.setAccentColor(am.enabled ? 0x57f287 : 0xed4245);

  const status = am.enabled ? '🟢 شغال' : '🔴 متوقف';
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`### 🛡️ الإشراف التلقائي  ${status}`)
  );
  container.addSeparatorComponents(divider());

  const lines = Object.entries(am.filters).map(([key, f]) => {
    const info = FILTER_INFO[key];
    const on = f.enabled ? '🟢' : '⚪';
    return `${on} ${info.emoji} **${info.name}**  ${info.desc}`;
  });

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(lines.join('\n'))
  );
  container.addSeparatorComponents(divider());

  const logInfo = am.logChannel ? `<#${am.logChannel}>` : '❌ مش محدد';
  const wlInfo = am.whitelistRoles.length + am.whitelistChannels.length > 0 ? '✅ فيه' : '❌ مفيش';
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      `شات اللوج  ${logInfo}\nالاستثناءات  ${wlInfo}\n\n-# اضغط على أي Rule عشان تعدل إعداداته`
    )
  );
  container.addSeparatorComponents(divider());

  const rows = [];
  const filters = Object.keys(FILTER_INFO);
  for (let i = 0; i < filters.length; i += 2) {
    const row = new ActionRowBuilder();
    for (let j = i; j < Math.min(i + 2, filters.length); j++) {
      const key = filters[j];
      const f = am.filters[key];
      const info = FILTER_INFO[key];
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`am_filter_${key}`)
          .setLabel(info.name)
          .setStyle(f.enabled ? ButtonStyle.Success : ButtonStyle.Secondary)
          .setEmoji(info.emoji)
      );
    }
    rows.push(row);
  }

  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('am_toggle')
      .setLabel(am.enabled ? 'إيقاف الإشراف' : 'تشغيل الإشراف')
      .setStyle(am.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
      .setEmoji(am.enabled ? '⏹️' : '▶️'),
    new ButtonBuilder()
      .setCustomId('am_log')
      .setLabel('شات اللوج')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('📋'),
    new ButtonBuilder()
      .setCustomId('am_whitelist')
      .setLabel('الاستثناءات')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🛡️')
  ));

  return { components: [container, ...rows], flags: V2_FLAGS };
}

// ── Build filter settings panel ──
function buildFilterPanel(am, filterKey) {
  const f = am.filters[filterKey];
  const info = FILTER_INFO[filterKey];
  const container = new ContainerBuilder();
  container.setAccentColor(f.enabled ? 0x57f287 : 0xed4245);

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`### ${info.emoji} ${info.name}`)
  );
  container.addSeparatorComponents(divider());

  const status = f.enabled ? '🟢 مفعّلة' : '🔴 متوقفة';
  const delMsg = f.deleteMessage ? '🟢 مفعّل' : '🔴 متوقف';
  const punish = f.punishmentEnabled ? `🟢 ${PUNISHMENT_NAMES[f.punishmentType]}` : '🔴 متوقفة';

  let details = `الحالة  ${status}\nحذف الرسالة  ${delMsg}\nالعقوبة  ${punish}`;

  if (filterKey === 'spam') {
    details += `\nالحد  ${f.threshold} رسالة / ${f.interval / 1000} ثانية`;
  }
  if (filterKey === 'caps') {
    details += `\nالحد  ${f.threshold}% حروف كبيرة`;
  }
  if (filterKey === 'mentions') {
    details += `\nالحد  ${f.threshold} منشن`;
  }
  if (filterKey === 'badwords') {
    const words = f.words?.length ? f.words.join('  ') : 'مفيش كلمات محددة';
    details += `\nالكلمات  ${words}`;
  }

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(details)
  );
  container.addSeparatorComponents(divider());

  const rows = [];

  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`am_ftoggle_${filterKey}`)
      .setLabel(f.enabled ? 'إيقاف الـRule' : 'تشغيل الـRule')
      .setStyle(f.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
      .setEmoji(f.enabled ? '🔴' : '🟢'),
    new ButtonBuilder()
      .setCustomId(`am_fdel_${filterKey}`)
      .setLabel(f.deleteMessage ? 'إيقاف حذف الرسالة' : 'تفعيل حذف الرسالة')
      .setStyle(f.deleteMessage ? ButtonStyle.Danger : ButtonStyle.Success)
      .setEmoji(f.deleteMessage ? '🔴' : '🟢')
  ));

  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`am_fpunish_${filterKey}`)
      .setLabel(f.punishmentEnabled ? 'إيقاف العقوبة' : 'تفعيل العقوبة')
      .setStyle(f.punishmentEnabled ? ButtonStyle.Danger : ButtonStyle.Success)
      .setEmoji(f.punishmentEnabled ? '🔴' : '🟢'),
    new ButtonBuilder()
      .setCustomId(`am_fpunishtype_${filterKey}`)
      .setLabel('نوع العقوبة')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('⚙️')
      .setDisabled(!f.punishmentEnabled)
  ));

  if (filterKey === 'badwords') {
    rows.push(new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`am_fwords_${filterKey}`)
        .setLabel('تعديل الكلمات')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('✏️')
    ));
  }

  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('am_back')
      .setLabel('رجوع')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('◀️')
  ));

  return { components: [container, ...rows], flags: V2_FLAGS };
}

// ── Send log ──
async function sendAutomodLog(guild, logChannelId, { member, filter, content, punishment, channelId }) {
  if (!logChannelId) return;
  const channel = guild.channels.cache.get(logChannelId);
  if (!channel) return;

  const container = new ContainerBuilder();
  container.setAccentColor(0xed4245);

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`### ${config.emojis.warning} الإشراف التلقائي  ${filter}`)
  );
  container.addSeparatorComponents(divider());

  const punishText = punishment || 'لا توجد عقوبة';
  const channelText = channelId ? `<#${channelId}>` : 'غير معروف';

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      `👤 العضو  ${member}  ID  \`${member.id}\`\n\n` +
      `🔨 العقوبة  ${punishText}\n\n` +
      `💬 الرسالة\n\`\`\`${content.slice(0, 900)}\`\`\`\n\n` +
      `📍 القناة  ${channelText}\n\n` +
      `🕐 الوقت  <t:${Math.floor(Date.now() / 1000)}:F>`
    )
  );
  container.addSeparatorComponents(divider());

  await channel.send({ components: [container], flags: V2_FLAGS }).catch(() => {});
}

// ── Word boundary check for badwords (regex متكاشة عشان مانعملش compile كل رسالة) ──
const badwordsRegexCache = new WeakMap();
function getBadwordsRegexes(filterConfig) {
  const words = filterConfig.words || [];
  const cached = badwordsRegexCache.get(filterConfig);
  if (cached && cached.words === words) return cached.regexes;

  const regexes = words
    .map(w => w.toLowerCase().trim())
    .filter(Boolean)
    .map(w => {
      const escaped = w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return { word: w, regex: new RegExp(`(?:^|[\\s\\p{P}])${escaped}(?:$|[\\s\\p{P}])`, 'iu') };
    });

  badwordsRegexCache.set(filterConfig, { words, regexes });
  return regexes;
}

function checkBadword(text, filterConfig) {
  const regexes = getBadwordsRegexes(filterConfig);
  if (!regexes.length) return null;
  const lower = text.toLowerCase();
  for (const { word, regex } of regexes) {
    if (regex.test(lower)) return word;
  }
  return null;
}

// ── Main command ──
module.exports = [
  {
    name: 'automod',
    aliases: ['am', 'اوتومود'],
    usage: '',
    description: 'لوحة تحكم الإشراف التلقائي',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      try {
        const am = getAutomod(message.guild.id);
        const panel = buildPanel(am);
        await message.reply(panel);
      } catch (err) {
        console.error('[AutoMod] Panel error:', err);
        message.reply({ components: [errorEmbed('حصل خطأ في عرض لوحة AutoMod')], flags: V2_FLAGS }).catch(() => {});
      }
    }
  }
];

module.exports.checkAutomod = checkAutomod;
module.exports.sendAutomodLog = sendAutomodLog;
module.exports.getAutomod = getAutomod;
module.exports.defaultAutomod = defaultAutomod;
module.exports.buildPanel = buildPanel;
module.exports.buildFilterPanel = buildFilterPanel;
module.exports.FILTER_INFO = FILTER_INFO;
module.exports.PUNISHMENT_NAMES = PUNISHMENT_NAMES;

// ── Spam tracking (بيتنضف لوحده كل شوية عشان ميفضلش ياكل رام على المدى الطويل) ──
const spamCache = new Map();
setInterval(() => {
  const now = Date.now();
  for (const [key, timestamps] of spamCache) {
    const fresh = timestamps.filter(t => now - t < 60000);
    if (fresh.length) spamCache.set(key, fresh);
    else spamCache.delete(key);
  }
}, 5 * 60 * 1000).unref();

// لازم يمسك دعوات السيرفرات بس (discord.gg/... أو discord.com/invite/... إلخ)
// وميمسكش أي لينك ديسكورد تاني زي روابط الرومات (discord.com/channels/...)
// أو روابط الكولز (discord.com/channels/@me/...) - دي المشكلة اللي كانت موجودة
// قبل كده: discord\.com\/(invite\/)?[a-zA-Z0-9-]+ كان بيمسك أي حاجة بعد discord.com/
// حتى لو مكنتش /invite/، فكانت بتاكل روابط الرومات والكولز غلط.
const INVITE_REGEX = /(?:https?:\/\/)?(?:www\.)?(?:discord\.gg\/|discord(?:app)?\.com\/invite\/|discord\.me\/|discord\.io\/|discord\.li\/)[a-zA-Z0-9-]+/i;
const LINK_REGEX = /https?:\/\/[^\s]+/i;

// ── كاشف كل فلتر: بيرجع اسم مختصر لو اتفعّل، أو null لو لأ ──
const FILTER_CHECKS = {
  spam(message, f) {
    const key = `${message.guild.id}-${message.author.id}`;
    const now = Date.now();
    const timestamps = (spamCache.get(key) || []).filter(t => now - t < f.interval);
    timestamps.push(now);
    spamCache.set(key, timestamps);
    return timestamps.length >= f.threshold;
  },
  caps(message, f) {
    const letters = message.content.replace(/[^a-zA-Z]/g, '');
    if (letters.length < 5) return false;
    const caps = letters.replace(/[^A-Z]/g, '');
    return (caps.length / letters.length) * 100 >= f.threshold;
  },
  invites(message) {
    return INVITE_REGEX.test(message.content);
  },
  links(message) {
    return LINK_REGEX.test(message.content);
  },
  badwords(message, f) {
    return !!checkBadword(message.content, f);
  },
  mentions(message, f) {
    return (message.mentions.users.size + message.mentions.roles.size) >= f.threshold;
  }
};

async function checkAutomod(message) {
  if (!message.guild || message.author.bot) return false;

  const am = getAutomod(message.guild.id);
  if (!am.enabled) return false;

  if (am.whitelistChannels.includes(message.channel.id)) return false;
  if (message.member && am.whitelistRoles.some(r => message.member.roles.cache.has(r))) return false;
  if (message.member?.permissions.has(PermissionFlagsBits.ManageMessages)) return false;

  let filterKey = null;
  let filterConfig = null;

  for (const key of Object.keys(FILTER_CHECKS)) {
    const f = am.filters[key];
    if (!f?.enabled) continue;
    if (FILTER_CHECKS[key](message, f)) {
      filterKey = key;
      filterConfig = f;
      break;
    }
  }

  if (!filterKey) return false;

  let punishment = '';
  if (filterConfig.punishmentEnabled) {
    punishment = await applyPunishment(message.member, filterConfig);
  }

  if (filterConfig.deleteMessage) {
    await message.delete().catch(() => {});
  }

  await sendAutomodLog(message.guild, am.logChannel, {
    member: message.member,
    filter: FILTER_INFO[filterKey].name,
    content: message.content,
    punishment,
    channelId: message.channel.id
  });

  return true;
}

// ── Apply punishment ──
async function applyPunishment(member, filterConfig) {
  const type = filterConfig.punishmentType;
  const duration = filterConfig.punishmentDuration || 3600000;

  try {
    if (type === 'warn') {
      return 'تحذير';
    }
    if (type === 'timeout' && member.moderatable) {
      await member.timeout(duration, 'AutoMod');
      const mins = Math.floor(duration / 60000);
      return `تايم أوت ${mins} دقيقة`;
    }
    if (type === 'kick' && member.kickable) {
      await member.kick('AutoMod');
      return 'طرد';
    }
    if (type === 'ban' && member.bannable) {
      await member.ban({ reason: 'AutoMod', deleteMessageSeconds: 0 });
      return 'بان';
    }
    // If we reach here, punishment type is valid but couldn't be applied
    return `فشل تطبيق ${PUNISHMENT_NAMES[type] || type} (مش معاك صلاحية)`;
  } catch (e) {
    console.error('[AutoMod] Punishment error:', e);
    return `فشل تطبيق العقوبة: ${e.message}`;
  }
}
