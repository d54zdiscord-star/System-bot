const { PermissionFlagsBits, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, successEmbed, errorEmbed, usageEmbed, V2_FLAGS } = require('../../utils/embed');
const { getOwnedRoom } = require('../../utils/tempvoice');
const config = require('../../config');

function prefixOf(guildId) {
  return db.get(guildId).prefix || config.defaultPrefix;
}

module.exports = [
  {
    name: 'panel',
    usage: 'temp',
    description: 'إعداد نظام الفويس المؤقت',
    permissions: [PermissionFlagsBits.ManageChannels],
    async execute(message, args) {
      if (args[0] !== 'temp') return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      const tv = data.tempVoice;

      const embed = baseEmbed({
        title: 'إعدادات الفويس المؤقت',
        description: 'تحكم في إعدادات نظام الفويس المؤقت:',
        fields: [
          { name: 'قناة الانتظار', value: tv.waitingChannelId ? `<#${tv.waitingChannelId}>` : 'غير محدد', inline: true },
          { name: 'الكاتيقوري', value: tv.categoryId ? `تم التحديد <:true:1533733814105407619>` : 'غير محدد', inline: true },
          { name: 'رول الموثق', value: tv.trustedRoleId ? `<@&${tv.trustedRoleId}>` : 'غير محدد', inline: true },
          { name: 'رول غير الموثق', value: tv.untrustedRoleId ? `<@&${tv.untrustedRoleId}>` : 'غير محدد', inline: true },
          { name: 'رول السجن', value: tv.jailRoleId ? `<@&${tv.jailRoleId}>` : 'غير محدد', inline: true },
          { name: 'رول الساوند بورد', value: tv.soundboardRoleId ? `<@&${tv.soundboardRoleId}>` : 'غير محدد', inline: true },
          { name: 'رسالة Info', value: tv.infoMessage ? '<:true:1533733814105407619> محددة' : 'غير محددة', inline: true },
          { name: 'الرولات الإدارية', value: tv.adminRoleIds?.length ? tv.adminRoleIds.map(id => `<@&${id}>`).join(', ') : 'غير محدد', inline: false },
          { name: 'الصورة', value: tv.saveSettings ? '<:true:1533733814105407619> محفوظة' : '<:fals:1533733827900473366>', inline: true }
        ],
        boxed: true
      });

      const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('tvcfg_waiting').setLabel('قناة الانتظار').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('tvcfg_category').setLabel('الكاتيقوري').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('tvcfg_image').setLabel('الصورة').setStyle(ButtonStyle.Secondary)
      );
      const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('tvcfg_trusted').setLabel('رول الموثق').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('tvcfg_untrusted').setLabel('رول غير الموثق').setStyle(ButtonStyle.Danger)
      );
      const row3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('tvcfg_jail').setLabel('رول السجن').setEmoji('⛓️').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('tvcfg_soundboard').setLabel('رول الساوند بورد').setEmoji('🔊').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('tvcfg_adminroles').setLabel('الرولات الإدارية').setEmoji('🛡️').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('tvcfg_infomsg').setLabel('رسالة Info').setEmoji('ℹ️').setStyle(ButtonStyle.Secondary)
      );
      const row4 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('tvcfg_send').setLabel('إرسال رسالة التحكم').setStyle(ButtonStyle.Primary)
      );

      return message.reply({ components: [embed, row1, row2, row3, row4], flags: V2_FLAGS });
    }
  },
  {
    name: 'callow',
    usage: '[منشن العضو]',
    description: 'السماح لعضو بدخول الروم الصوتي',
    async execute(message, args) {
      const channel = message.member.voice.channel;
      const member = message.mentions.members.first();
      if (!channel) return message.reply({ components: [errorEmbed('لازم تكون جوه روم صوتي.')], flags: V2_FLAGS });
      const owned = getOwnedRoom(message.guild.id, message.author.id);
      if (!owned || owned.channelId !== channel.id) return message.reply({ components: [errorEmbed('لازم تكون أونر الروم عشان تستخدم الأمر ده.')], flags: V2_FLAGS });
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await channel.permissionOverwrites.edit(member.id, { Connect: true, ViewChannel: true });
      return message.reply({ components: [successEmbed(`تم السماح لـ ${member} بدخول الروم.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'cdeny',
    usage: '[منشن العضو]',
    description: 'منع عضو من دخول الروم الصوتي',
    async execute(message, args) {
      const channel = message.member.voice.channel;
      const member = message.mentions.members.first();
      if (!channel) return message.reply({ components: [errorEmbed('لازم تكون جوه روم صوتي.')], flags: V2_FLAGS });
      const owned = getOwnedRoom(message.guild.id, message.author.id);
      if (!owned || owned.channelId !== channel.id) return message.reply({ components: [errorEmbed('لازم تكون أونر الروم عشان تستخدم الأمر ده.')], flags: V2_FLAGS });
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      if (member.id === owned.room.ownerId) return message.reply({ components: [errorEmbed('متقدرش تعمل منع لنفسك، انت الأونر.')], flags: V2_FLAGS });
      await channel.permissionOverwrites.edit(member.id, { Connect: false });
      if (member.voice.channelId === channel.id) member.voice.disconnect().catch(() => {});
      return message.reply({ components: [successEmbed(`تم منع ${member} من دخول الروم.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'chide',
    usage: '[منشن العضو]',
    description: 'إخفاء الروم الصوتي عن عضو',
    async execute(message, args) {
      const channel = message.member.voice.channel;
      const member = message.mentions.members.first();
      if (!channel) return message.reply({ components: [errorEmbed('لازم تكون جوه روم صوتي.')], flags: V2_FLAGS });
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await channel.permissionOverwrites.edit(member.id, { ViewChannel: false });
      return message.reply({ components: [successEmbed(`تم إخفاء الروم عن ${member}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'cunhide',
    usage: '[منشن العضو]',
    description: 'إظهار الروم الصوتي لعضو',
    async execute(message, args) {
      const channel = message.member.voice.channel;
      const member = message.mentions.members.first();
      if (!channel) return message.reply({ components: [errorEmbed('لازم تكون جوه روم صوتي.')], flags: V2_FLAGS });
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await channel.permissionOverwrites.edit(member.id, { ViewChannel: true });
      return message.reply({ components: [successEmbed(`تم إظهار الروم لـ ${member}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'clist',
    usage: '',
    description: 'قائمة الممنوعين من الروم',
    async execute(message) {
      const channel = message.member.voice.channel;
      if (!channel) return message.reply({ components: [errorEmbed('لازم تكون جوه روم صوتي.')], flags: V2_FLAGS });
      const denied = channel.permissionOverwrites.cache.filter(ow => ow.deny.has(PermissionFlagsBits.Connect));
      if (!denied.size) return message.reply({ components: [errorEmbed('مفيش حد ممنوع من الروم ده.')], flags: V2_FLAGS });
      const list = denied.map(ow => `<@${ow.id}>`).join('\n');
      return message.reply({ components: [baseEmbed({ title: 'الممنوعين من الروم', description: list, boxed: true })], flags: V2_FLAGS });
    }
  }
];
