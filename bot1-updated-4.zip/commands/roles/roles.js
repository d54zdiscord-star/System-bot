const { PermissionFlagsBits, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, successEmbed, errorEmbed, usageEmbed, V2_FLAGS } = require('../../utils/embed');
const { canAssignRole } = require('../../utils/permissions');
const config = require('../../config');

// دايرة لون قريبة من لون الرول (عشان نوريه جمب الاسم في قوائم الاختيار)
function colorDotFor(role) {
  const hex = role.color || 0;
  if (hex === 0) return '⚪';
  const r = (hex >> 16) & 255, g = (hex >> 8) & 255, b = hex & 255;
  const palette = [
    { e: '🔴', c: [237, 66, 69] }, { e: '🟠', c: [235, 149, 50] }, { e: '🟡', c: [253, 216, 53] },
    { e: '🟢', c: [87, 242, 135] }, { e: '🔵', c: [59, 136, 240] }, { e: '🟣', c: [155, 89, 182] },
    { e: '🟤', c: [117, 79, 58] }, { e: '⚫', c: [30, 30, 30] }, { e: '⚪', c: [245, 245, 245] }
  ];
  let best = palette[0], bestDist = Infinity;
  for (const p of palette) {
    const d = (r - p.c[0]) ** 2 + (g - p.c[1]) ** 2 + (b - p.c[2]) ** 2;
    if (d < bestDist) { bestDist = d; best = p; }
  }
  return best.e;
}

function prefixOf(guildId) {
  return db.get(guildId).prefix || config.defaultPrefix;
}

module.exports = [
  {
    name: 'role',
    usage: '[منشن العضو] [اسم الرول 1,اسم الرول 2,...]',
    description: 'إضافة رتبة (أو أكتر) لعضو بالاسم',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      // Join remaining args and split by comma
      const rolesText = args.slice(1).join(' ');
      if (!rolesText) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const roleNames = rolesText.split(',').map(r => r.trim()).filter(r => r);
      if (!roleNames.length) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const added = [];
      const failed = [];
      const notAllowed = [];

      for (const roleName of roleNames) {
        // Find role by name (case-insensitive partial match)
        const role = message.guild.roles.cache.find(r => 
          r.name.toLowerCase().includes(roleName.toLowerCase()) || 
          roleName.toLowerCase().includes(r.name.toLowerCase())
        );

        if (!role) {
          failed.push(`❌ مالقيتش رول: **${roleName}**`);
          continue;
        }

        const check = canAssignRole(message.member, role);
        if (!check.allowed) {
          notAllowed.push(`🚫 ماعندكش صلاحية لـ **${role.name}**`);
          continue;
        }

        if (member.roles.cache.has(role.id)) {
          failed.push(`⚠️ **${role.name}** موجودة عند العضو`);
          continue;
        }

        try {
          await member.roles.add(role);
          added.push(`✅ **${role.name}**`);
        } catch {
          failed.push(`❌ فشل إضافة **${role.name}**`);
        }
      }

      const lines = [];
      if (added.length) lines.push(`📥 **تم الإضافة (${added.length}):**\n${added.join('\n')}`);
      if (notAllowed.length) lines.push(`\n🚫 **ماعندكش صلاحية (${notAllowed.length}):**\n${notAllowed.join('\n')}`);
      if (failed.length) lines.push(`\n❌ **فشل (${failed.length}):**\n${failed.join('\n')}`);

      return message.reply({ 
        components: [baseEmbed({ title: `🎭 نتيجة إضافة رولات لـ ${member.user.username}`, description: lines.join('\n\n') || 'مفيش نتيجة', boxed: true })], 
        flags: V2_FLAGS 
      });
    }
  },
  {
    name: 'addrole',
    usage: '[اسم الرول]',
    description: 'إنشاء رول جديد',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message, args) {
      const name = args.join(' ');
      if (!name) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const role = await message.guild.roles.create({ name }).catch(() => null);
      if (!role) return message.reply({ components: [errorEmbed('فشل إنشاء الرول.')], flags: V2_FLAGS });
      return message.reply({ components: [successEmbed(`تم إنشاء رول ${role}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'autorole',
    usage: '[منشن الرول]',
    description: 'رول تلقائي لكل عضو يدخل',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message, args) {
      const role = message.mentions.roles.first();
      if (!role) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.settings.autorole = role.id;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم تفعيل الرول التلقائي: ${role}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'daorole',
    usage: '',
    description: 'حذف الرول التلقائي',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message) {
      const data = db.get(message.guild.id);
      data.settings.autorole = null;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed('تم إلغاء الرول التلقائي.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'roleall',
    usage: '[منشن الرول]',
    description: 'إعطاء رول لجميع الأعضاء',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message, args) {
      const role = message.mentions.roles.first();
      if (!role) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const check = canAssignRole(message.member, role);
      if (!check.allowed) return message.reply({ components: [errorEmbed(check.reason)], flags: V2_FLAGS });
      const status = await message.reply({ components: [baseEmbed({ description: '⏳ جاري إعطاء الرول للجميع...' })], flags: V2_FLAGS });
      const members = await message.guild.members.fetch();
      let count = 0;
      for (const m of members.values()) {
        if (!m.user.bot && !m.roles.cache.has(role.id)) {
          await m.roles.add(role).catch(() => {});
          count++;
        }
      }
      return status.edit({ components: [successEmbed(`تم إعطاء ${role} لـ ${count} عضو.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'removrole',
    usage: '[منشن الرول]',
    description: 'إزالة رول من الجميع',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message, args) {
      const role = message.mentions.roles.first();
      if (!role) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const status = await message.reply({ components: [baseEmbed({ description: '⏳ جاري إزالة الرول من الجميع...' })], flags: V2_FLAGS });
      let count = 0;
      for (const m of role.members.values()) {
        await m.roles.remove(role).catch(() => {});
        count++;
      }
      return status.edit({ components: [successEmbed(`تم إزالة ${role} من ${count} عضو.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'here',
    usage: '[منشن الرول]',
    description: 'إضافة رول الهير (منشن @here البديل)',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message, args) {
      const role = message.mentions.roles.first();
      if (!role) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.settings.hereRole = role.id;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم تحديد ${role} كرول الهير.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'live',
    usage: '[منشن الرول]',
    description: 'رتبة تسمح بفتح كام',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message, args) {
      const role = message.mentions.roles.first();
      if (!role) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      for (const channel of message.guild.channels.cache.filter(c => c.isVoiceBased()).values()) {
        channel.permissionOverwrites.edit(message.guild.roles.everyone, { Stream: false }).catch(() => {});
        channel.permissionOverwrites.edit(role, { Stream: true }).catch(() => {});
      }
      return message.reply({ components: [successEmbed(`تم تحديد ${role} كرتبة السماح بفتح الكاميرا/البث.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'nick',
    usage: '[منشن الرول]',
    description: 'رتبة تغيير الاسم',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message, args) {
      const role = message.mentions.roles.first();
      if (!role) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.settings.nickRole = role.id;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم تحديد ${role} كرتبة تغيير الاسم.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'reactionrole',
    usage: '[آي دي الرسالة] [إيموجي] [منشن الرول]',
    description: 'رولات عن طريق الرياكشن',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message, args) {
      const messageId = args[0];
      const emoji = args[1];
      const role = message.mentions.roles.first();
      if (!messageId || !emoji || !role) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const target = await message.channel.messages.fetch(messageId).catch(() => null);
      if (!target) return message.reply({ components: [errorEmbed('مالقتش الرسالة دي في الشات ده.')], flags: V2_FLAGS });

      await target.react(emoji).catch(() => {});
      const data = db.get(message.guild.id);
      if (!data.reactionRoles[messageId]) data.reactionRoles[messageId] = {};
      const emojiKey = emoji.match(/<a?:\w+:(\d+)>/) ? emoji.match(/<a?:\w+:(\d+)>/)[1] : emoji;
      data.reactionRoles[messageId][emojiKey] = role.id;
      db.commit(message.guild.id);

      return message.reply({ components: [successEmbed(`تم ربط ${emoji} برول ${role} على الرسالة المحددة.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'setrolem',
    usage: '[منشن الرول] [النص/الإيمبد]',
    description: 'إعداد نظام الرتب الخاصة',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message, args) {
      const role = message.mentions.roles.first();
      const desc = args.slice(1).join(' ');
      if (!role || !desc) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.settings.specialRoles = data.settings.specialRoles || {};
      data.settings.specialRoles[role.id] = { description: desc, image: null };
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم إعداد الرتبة الخاصة ${role}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'rolemimage',
    usage: '[منشن الرول] (أرفق صورة)',
    description: 'رفع صورة نظام الرتب الخاصة',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message, args) {
      const role = message.mentions.roles.first();
      const attachment = message.attachments.first();
      if (!role || !attachment) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.settings.specialRoles = data.settings.specialRoles || {};
      if (!data.settings.specialRoles[role.id]) data.settings.specialRoles[role.id] = { description: '', image: null };
      data.settings.specialRoles[role.id].image = attachment.url;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم رفع صورة الرتبة الخاصة لـ ${role}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'delrole',
    usage: '[منشن العضو] [منشن الرول]',
    description: 'حذف رتبة عضو',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const role = message.mentions.roles.first();
      if (!member || !role) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await member.roles.remove(role).catch(() => {});
      return message.reply({ components: [successEmbed(`تم إزالة ${role} من ${member}`)], flags: V2_FLAGS });
    }
  },
  // ملاحظة: أوامر المتجر (متجر / setshop / resetpoints / givep / removep / shoptasks)
  // موجودة بالكامل في ملف commands/shop/shop.js
  {
    name: 'setcolors',
    usage: '[منشن رول] [منشن رول]...',
    description: 'إعداد نظام الألوان (رولات ألوان يقدر العضو يختار منها)',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message) {
      const roles = [...message.mentions.roles.values()];
      if (!roles.length) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.settings.colorRoles = roles.map(r => r.id);
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم تسجيل ${roles.length} رول لون. استخدم \`${prefixOf(message.guild.id)}لون\` عشان تختار.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'لون',
    usage: '',
    description: 'اختيار لون اسمك من قائمة الألوان',
    async execute(message) {
      const data = db.get(message.guild.id);
      const roleIds = data.settings.colorRoles || [];
      if (!roleIds.length) return message.reply({ components: [errorEmbed('نظام الألوان مش مفعل.')], flags: V2_FLAGS });

      const menu = new StringSelectMenuBuilder()
        .setCustomId('colorrole_select')
        .setPlaceholder('اختار لونك')
        .addOptions(
          roleIds.map(id => {
            const role = message.guild.roles.cache.get(id);
            return { label: role ? `${colorDotFor(role)} ${role.name}` : id, value: id };
          })
        );

      const sent = await message.reply({ components: [new ActionRowBuilder().addComponents(menu)] });
      const collector = sent.createMessageComponentCollector({ time: 60000, max: 1 });
      collector.on('collect', async i => {
        if (i.user.id !== message.author.id) return i.reply({ content: 'مش ليك.', ephemeral: true });
        const chosen = i.values[0];
        for (const id of roleIds) {
          if (message.member.roles.cache.has(id)) await message.member.roles.remove(id).catch(() => {});
        }
        await message.member.roles.add(chosen).catch(() => {});
        await i.update({ content: `<:true:1533733814105407619> تم تحديد لونك.`, components: [] });
      });
    }
  }
];
