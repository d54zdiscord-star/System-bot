const { V2_FLAGS, sectionedContainer } = require('../../utils/embed');
const { setAfk } = require('../../utils/afk');

module.exports = [
  {
    name: 'afk',
    usage: '[سبب]',
    description: 'تفعيل وضع الـ AFK - البوت يرد بدالك على أي منشن ويعلمك بيهم لما ترجع',
    async execute(message, args) {
      const reason = args.join(' ').trim();
      const entry = setAfk(message.guild.id, message.author.id, reason);

      return message.channel.send({
        components: [
          sectionedContainer(`**${message.author} دلوقتي في وضع الـ AFK**`, `السبب: ${entry.reason}`)
        ],
        flags: V2_FLAGS
      });
    }
  }
];
