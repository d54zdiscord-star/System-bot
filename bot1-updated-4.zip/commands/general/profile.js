// ─────────────────────────────────────────────────────────────────
//  commands/general/profile.js
//  أمر البروفايل (نظام بوستات + متابعين + لايكات) - منقول حرفيًا من بوت ١
// ─────────────────────────────────────────────────────────────────
const { AttachmentBuilder } = require('discord.js');
const { buildProfileCanvas, buildOwnerButtons, buildViewButtons } = require('../../utils/profileCard');
const { errorEmbed, V2_FLAGS } = require('../../utils/embed');

module.exports = [
  {
    name: 'profile',
    aliases: ['pf', 'بروفايل', 'بروف'],
    usage: '[منشن العضو]',
    description: 'عرض بروفايل العضو (بوستات + متابعين + لايكات)',
    async execute(message, args, client) {
      const targetUser = message.mentions.users.first();
      const isOwn = !targetUser;
      const targetId = targetUser ? targetUser.id : message.author.id;

      const buffer = await buildProfileCanvas(client, targetId, 0);
      if (!buffer) return message.reply({ components: [errorEmbed('معرفتش ألاقي العضو ده.')], flags: V2_FLAGS });

      const att = new AttachmentBuilder(buffer, { name: 'profile.png' });
      const rows = isOwn ? buildOwnerButtons(targetId, 0) : buildViewButtons(targetId, 0);
      return message.channel.send({ files: [att], components: rows });
    }
  }
];
