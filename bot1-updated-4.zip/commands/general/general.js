const {
  StringSelectMenuBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder,
  MediaGalleryBuilder, MediaGalleryItemBuilder
} = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, errorEmbed, usageEmbed, V2_FLAGS } = require('../../utils/embed');
const { getUserLevelData, progressBar, progressInLevel, getRank } = require('../../utils/leveling');
const { renderRankCard } = require('../../utils/cards');
const config = require('../../config');

function parseEmoji(str) {
  const m = /<(a)?:(\w+):(\d+)>/.exec(str || '');
  if (!m) return undefined;
  return { animated: !!m[1], name: m[2], id: m[3] };
}

const ARROW = config.emojis.arrow || config.emojis.commands;

// ترتيب عرض الفئات في السيلكت (أي فئة تانية غير موجودة هنا هتتضاف آخر القائمة أوتوماتيك)
const CATEGORY_ORDER = ['عامة', 'إعدادات', 'إدارة', 'شاتات', 'رولات', 'رومات صوتية', 'تكتات', 'اقتراحات', 'اللفلات', 'المتجر', 'السحوبات', 'الإشراف التلقائي', 'مالك البوت'];

module.exports = [
  {
    name: 'help',
    aliases: ['مساعدة'],
    usage: '',
    description: 'قائمة المساعدة',
    async execute(message, args, client) {
      const data = db.get(message.guild.id);
      const prefix = data.prefix || config.defaultPrefix;

      // ── الفئات الموجودة فعليًا (مرتبة حسب CATEGORY_ORDER) ──
      const existingCats = [...new Set([...client.commands.values()].map(c => c.category))];
      const categories = [
        ...CATEGORY_ORDER.filter(c => existingCats.includes(c)),
        ...existingCats.filter(c => !CATEGORY_ORDER.includes(c))
      ];

      // ── الأزرار: السيرفر + المطور ──
      const btnRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setLabel('السيرفر').setEmoji(parseEmoji(config.emojis.commands)).setStyle(ButtonStyle.Link).setURL(config.helpServerInvite),
        new ButtonBuilder().setCustomId('help_dev').setLabel('المطور').setStyle(ButtonStyle.Secondary)
      );

      const buildSelect = (disabled = false) => new StringSelectMenuBuilder()
        .setCustomId('help_category_select')
        .setPlaceholder('✦ اختر فئة الأوامر')
        .setDisabled(disabled)
        .addOptions(categories.map(cat => ({ label: `أوامر ${cat}`, value: cat, emoji: parseEmoji(ARROW) })));

      function buildContainer({ title, description, disabled = false } = {}) {
        const container = new ContainerBuilder();
        if (config.helpBannerImage) {
          container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(config.helpBannerImage)));
          container.addSeparatorComponents(new SeparatorBuilder());
        }
        container
          .addActionRowComponents(btnRow)
          .addSeparatorComponents(new SeparatorBuilder())
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(title || `## أوامر البوت`))
          .addSeparatorComponents(new SeparatorBuilder())
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(description))
          .addSeparatorComponents(new SeparatorBuilder())
          .addActionRowComponents(new ActionRowBuilder().addComponents(buildSelect(disabled)))
          .addSeparatorComponents(new SeparatorBuilder())
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ${message.author.username} • ${client.user.username}`));
        return container;
      }

      function buildMain(disabled = false) {
        return buildContainer({
          description:
            `${ARROW} اختر الفئة من القائمة أدناه\n` +
            `${ARROW} **عدد الأوامر** \`${client.commands.size} أمر\`\n` +
            `${ARROW} **البريفكس** \`${prefix}\`\n` +
            `${ARROW} استخدم \`${prefix}info [أمر]\` لفهم أمر معين`,
          disabled
        });
      }

      function buildPage(cat, disabled = false) {
        const cmds = [...client.commands.values()].filter(c => c.category === cat);
        const list = cmds.map(c => `${ARROW} \`${prefix}${c.name}\` ${c.description ? '— ' + c.description : ''}`).join('\n') || 'مفيش أوامر في الفئة دي.';
        return buildContainer({ title: `## ${ARROW} أوامر ${cat}`, description: list, disabled });
      }

      const sent = await message.reply({ components: [buildMain()], flags: V2_FLAGS });

      const collector = sent.createMessageComponentCollector({ time: 600000 });
      collector.on('collect', async i => {
        if (i.customId === 'help_dev') {
          return i.reply({ content: `<@${config.helpDeveloperId}>`, ephemeral: true }).catch(() => {});
        }
        if (i.user.id !== message.author.id) {
          return i.reply({ content: 'الأمر ده مش ليك.', ephemeral: true }).catch(() => {});
        }
        if (i.customId === 'help_category_select') {
          return i.update({ components: [buildPage(i.values[0])], flags: V2_FLAGS }).catch(() => {});
        }
      });

      collector.on('end', () => {
        sent.edit({ components: [buildMain(true)], flags: V2_FLAGS }).catch(() => {});
      });
    }
  },
  {
    name: 'info',
    usage: '[أمر]',
    description: 'شرح مفصل لأي أمر مع اختصاراته',
    async execute(message, args, client) {
      const data = db.get(message.guild.id);
      const prefix = data.prefix || config.defaultPrefix;
      if (!args[0]) return message.reply({ components: [usageEmbed(prefix, this)], flags: V2_FLAGS });

      const cmd = client.commands.get(args[0].toLowerCase()) || client.commands.get(client.aliases.get(args[0].toLowerCase()));
      if (!cmd) return message.reply({ components: [errorEmbed('الأمر ده مش موجود.')], flags: V2_FLAGS });

      return message.reply({
        components: [
          baseEmbed({
            title: `أمر ${cmd.name}`,
            fields: [
              { name: 'الاستخدام', value: `\`${prefix}${cmd.name} ${cmd.usage || ''}\`` },
              { name: 'الوصف', value: cmd.description || 'مفيش وصف' },
              { name: 'الاختصارات', value: cmd.aliases?.length ? cmd.aliases.map(a => `\`${a}\``).join(', ') : 'مفيش' },
              { name: 'الفئة', value: cmd.category }
            ],
            boxed: true
          })
        ], flags: V2_FLAGS
      });
    }
  },
  {
    name: 'avatar',
    aliases: ['avt', 'a', 'افتار'],
    usage: '[منشن العضو أو الـ ID]',
    description: 'عرض صورة شخص (حتى لو مش في السيرفر، لو بعتت الـ ID بتاعه)',
    async execute(message, args, client) {
      const mentioned = message.mentions.users.first();
      const rawId = !mentioned && args[0] && /^\d{15,25}$/.test(args[0]) ? args[0] : null;

      let target = mentioned;
      if (!target && rawId) {
        target = await client.users.fetch(rawId, { force: true }).catch(() => null);
        if (!target) return message.reply({ components: [errorEmbed('معرفتش ألاقي يوزر بالـ ID ده.')], flags: V2_FLAGS });
      }
      if (!target) target = await client.users.fetch(message.author.id, { force: true });

      const avatarURL = target.displayAvatarURL({ size: 2048, forceStatic: false });

      const container = new ContainerBuilder()
        .addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(avatarURL)))
        .addSeparatorComponents(new SeparatorBuilder())
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`> صورة <@${target.id}>`));

      return message.reply({ components: [container], flags: V2_FLAGS });
    }
  },
  {
    name: 'banner',
    aliases: ['بنر', 'b'],
    usage: '[منشن العضو أو الـ ID]',
    description: 'عرض بنر شخص (حتى لو مش في السيرفر، لو بعتت الـ ID بتاعه)',
    async execute(message, args, client) {
      const mentioned = message.mentions.users.first();
      const rawId = !mentioned && args[0] && /^\d{15,25}$/.test(args[0]) ? args[0] : null;
      const targetId = mentioned ? mentioned.id : (rawId || message.author.id);

      const fetched = await client.users.fetch(targetId, { force: true }).catch(() => null);
      if (!fetched) return message.reply({ components: [errorEmbed('معرفتش ألاقي يوزر بالـ ID ده.')], flags: V2_FLAGS });

      const bannerURL = fetched.bannerURL({ size: 1024 });
      if (!bannerURL) return message.reply({ components: [errorEmbed('الشخص ده معندوش بنر')], flags: V2_FLAGS });

      const container = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${fetched.username}`))
        .addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(bannerURL)))
        .addSeparatorComponents(new SeparatorBuilder())
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`> بنر <@${fetched.id}>`));

      return message.reply({ components: [container], flags: V2_FLAGS });
    }
  },
  {
    name: 'مخفي',
    aliases: ['secret'],
    usage: '[منشن العضو] (أو رد على رسالته واكتب مخفي)',
    description: 'إرسال رسالة سرية لعضو، بتتسجل في شات الزاجل (لو محدد)',
    async execute(message, args) {
      const prefix = (db.get(message.guild.id).prefix) || config.defaultPrefix;
      let target = message.mentions.members.first();

      if (!target && message.reference) {
        const replied = await message.channel.messages.fetch(message.reference.messageId).catch(() => null);
        if (replied) target = await message.guild.members.fetch(replied.author.id).catch(() => null);
      }

      if (!target) return message.reply({ components: [usageEmbed(prefix, this)], flags: V2_FLAGS });
      if (target.user.bot) return message.reply({ components: [errorEmbed('متقدرش تبعت رسالة سرية لبوت')], flags: V2_FLAGS });
      if (target.id === message.author.id) return message.reply({ components: [errorEmbed('متقدرش تبعتلك نفسك رسالة سرية')], flags: V2_FLAGS });

      message.delete().catch(() => {});

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`secret_write_${message.author.id}_${target.id}`)
          .setLabel('اكتب رسالتك')
          .setEmoji('💬')
          .setStyle(ButtonStyle.Primary)
      );

      return message.channel.send({
        components: [baseEmbed({ description: `👁️ اضغط الزر لكتابة رسالتك السرية لـ ${target}` }), row],
        flags: V2_FLAGS
      });
    }
  },
  {
    name: 'myinv',
    usage: '',
    description: 'عدد دعواتك',
    async execute(message) {
      const data = db.get(message.guild.id);
      const count = (data.settings.invites || {})[message.author.id] || 0;
      return message.reply({ components: [baseEmbed({ description: `عندك **${count}** دعوة في السيرفر.` })], flags: V2_FLAGS });
    }
  },
  {
    name: 'topinv',
    usage: '',
    description: 'أعلى عدد دعوات',
    async execute(message) {
      const data = db.get(message.guild.id);
      const invites = data.settings.invites || {};
      const sorted = Object.entries(invites).sort((a, b) => b[1] - a[1]).slice(0, 10);
      if (!sorted.length) return message.reply({ components: [errorEmbed('مفيش بيانات دعوات لسه.')], flags: V2_FLAGS });
      const list = sorted.map(([id, count], i) => `**${i + 1}.** <@${id}> - ${count} دعوة`).join('\n');
      return message.reply({ components: [baseEmbed({ title: 'أعلى الداعيين', description: list, boxed: true })], flags: V2_FLAGS });
    }
  },
  {
    name: 'aremove',
    usage: '(أرفق صورة)',
    description: 'إزالة خلفية الصورة (يحتاج ضبط مفتاح remove.bg في .env)',
    async execute(message) {
      const prefix = (db.get(message.guild.id).prefix) || config.defaultPrefix;
      const attachment = message.attachments.first();
      if (!attachment) return message.reply({ components: [usageEmbed(prefix, this)], flags: V2_FLAGS });

      if (!process.env.REMOVE_BG_API_KEY) {
        return message.reply({
          components: [errorEmbed('الأمر ده محتاج مفتاح REMOVE_BG_API_KEY في ملف .env (من موقع remove.bg) عشان يشتغل.')], flags: V2_FLAGS
        });
      }

      const loading = await message.reply({ components: [baseEmbed({ description: '⏳ جاري إزالة الخلفية...' })], flags: V2_FLAGS });

      try {
        const form = new FormData();
        const imgRes = await fetch(attachment.url);
        const blob = await imgRes.blob();
        form.append('image_file', blob, 'image.png');
        form.append('size', 'auto');

        const res = await fetch('https://api.remove.bg/v1.0/removebg', {
          method: 'POST',
          headers: { 'X-Api-Key': process.env.REMOVE_BG_API_KEY },
          body: form
        });

        if (!res.ok) throw new Error('فشل الاتصال بـ remove.bg');
        const buffer = Buffer.from(await res.arrayBuffer());
        await loading.edit({
          components: [baseEmbed({ description: '<:true:1533733814105407619> تمام!' })], flags: V2_FLAGS,
          files: [{ attachment: buffer, name: 'no-bg.png' }]
        });
      } catch (e) {
        await loading.edit({ components: [errorEmbed('حصل خطأ أثناء إزالة الخلفية.')], flags: V2_FLAGS });
      }
    }
  },
  {
    name: 'semoji',
    usage: '[إيموجي]',
    description: 'إرسال صورة الإيموجي',
    async execute(message, args) {
      const prefix = (db.get(message.guild.id).prefix) || config.defaultPrefix;
      const match = (args[0] || '').match(/<a?:\w+:(\d+)>/);
      if (!match) return message.reply({ components: [usageEmbed(prefix, this)], flags: V2_FLAGS });
      const animated = args[0].startsWith('<a:');
      const url = `https://cdn.discordapp.com/emojis/${match[1]}.${animated ? 'gif' : 'png'}`;
      return message.reply({ components: [baseEmbed({ image: url })], flags: V2_FLAGS });
    }
  },
  {
    name: 'rank',
    usage: '[منشن العضو]',
    description: 'عرض لفل ورانك العضو (شات + فويس) كصورة',
    category: 'اللفلات',
    async execute(message, args) {
      const member = message.mentions.members.first() || message.member;
      const level = getUserLevelData(message.guild.id, member.id);

      const chatProgress = progressInLevel(level.chatXp, level.chatLevel);
      const voiceProgress = progressInLevel(level.voiceXp, level.voiceLevel);

      try {
        const buffer = await renderRankCard({
          username: member.displayName,
          avatarURL: member.displayAvatarURL({ dynamic: true, size: 256, extension: 'png' }),
          chatLevel: level.chatLevel,
          chatXp: chatProgress.into,
          chatNeeded: chatProgress.needed,
          chatRank: getRank(message.guild.id, member.id, 'chat'),
          voiceLevel: level.voiceLevel,
          voiceXp: voiceProgress.into,
          voiceNeeded: voiceProgress.needed,
          voiceTotalMinutes: level.voiceXp,
          voiceRank: getRank(message.guild.id, member.id, 'voice')
        });
        return message.reply({ files: [{ attachment: buffer, name: 'rank.png' }] });
      } catch (e) {
        console.error('فشل رسم كارت الرانك:', e);
        return message.reply({
          components: [
            baseEmbed({
              title: member.user.username,
              thumbnail: member.displayAvatarURL({ dynamic: true }),
              fields: [
                {
                  name: '💬 الشات',
                  value: `لفل **${level.chatLevel}**\n${progressBar(chatProgress.into, chatProgress.needed)}\n${chatProgress.into} / ${chatProgress.needed} XP`
                },
                {
                  name: '🎙️ الصوت',
                  value: `لفل **${level.voiceLevel}**\n${progressBar(voiceProgress.into, voiceProgress.needed)}\n${voiceProgress.into} / ${voiceProgress.needed} XP`
                }
              ]
            })
          ],
          flags: V2_FLAGS
        });
      }
    }
  }
];
