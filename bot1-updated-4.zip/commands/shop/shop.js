// ─────────────────────────────────────────────────────────────────
//  commands/shop/shop.js
//  نظام المتجر الكامل (رتب بالنقاط + مهام يومية/أسبوعية + بروفايل)
//  منقول حرفيًا من بوت ١ ومتكيف مع أسلوب بوت ٢
// ─────────────────────────────────────────────────────────────────
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, ContainerBuilder, TextDisplayBuilder,
  SeparatorBuilder, PermissionFlagsBits
} = require('discord.js');
const db = require('../../utils/db');
const { errorEmbed, successEmbed, usageEmbed, V2_FLAGS } = require('../../utils/embed');
const { DAILY_POOL, WEEKLY_POOL } = require('../../utils/tasks');
const { buildShopPanel, parseEmoji } = require('../../utils/shopUI');
const config = require('../../config');

function prefixOf(guildId) {
  return db.get(guildId).prefix || config.defaultPrefix;
}

module.exports = [
  // ═══════════════════════════════ متجر (عضو) ═══════════════════════════════
  {
    name: 'متجر',
    aliases: ['shop'],
    usage: '',
    category: 'المتجر',
    description: 'إرسال لوحة المتجر في الشات (رتب بالنقاط + مهام + بروفايل)',
    ownerOnly: true,
    async execute(message) {
      const data = db.get(message.guild.id);
      if (!data.shop.ranks.length && !data.tasks.enabled) {
        return message.reply({ components: [errorEmbed('نظام المتجر مش مفعّل لسه، استخدم أمر setshop عشان تجهزه.')], flags: V2_FLAGS });
      }
      return message.reply({ components: [buildShopPanel(message.guild.id)], flags: V2_FLAGS });
    }
  },

  // ═══════════════════════════════ setshop (أدمن) ═══════════════════════════════
  {
    name: 'setshop',
    aliases: ['ضبط-متجر', 'اعداد-متجر'],
    usage: '',
    category: 'المتجر',
    description: 'إدارة نظام النقاط والرتب (رتب المتجر + تخصيص اللوحة)',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message) {
      const container = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent('## ⚙️ إعدادات نظام النقاط\n-# اختر العملية التي تريدها'))
        .addSeparatorComponents(new SeparatorBuilder())
        .addActionRowComponents(
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('setshop_add').setLabel('إضافة رتبة').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('setshop_list').setLabel('عرض الرتب').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('setshop_del').setLabel('حذف رتبة').setStyle(ButtonStyle.Danger)
          )
        )
        .addActionRowComponents(
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('setshop_setinfo').setLabel('نص Info').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('setshop_setembed').setLabel('تخصيص الـ Embed').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('setshop_setgeneral').setLabel('شات الإشعارات').setStyle(ButtonStyle.Secondary)
          )
        )
        .addActionRowComponents(
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('setshop_sendembed').setLabel('إرسال اللوحة').setStyle(ButtonStyle.Primary).setEmoji(parseEmoji(config.emojis.shopRanks))
          )
        );
      return message.reply({ components: [container], flags: V2_FLAGS });
    }
  },

  // ═══════════════════════════════ resetpoints (أدمن) ═══════════════════════════════
  {
    name: 'resetpoints',
    aliases: ['تصفيرنقاط', 'resetpts'],
    usage: '[منشن العضو / all]',
    category: 'المتجر',
    description: 'تصفير نقاط عضو معين أو كل الأعضاء',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message, args) {
      if (args[0] === 'all') {
        const container = new ContainerBuilder()
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `## ⚠️ تصفير النقاط\n> متأكد إنك عايز تصفّر نقاط **كل الأعضاء** في السيرفر؟\n> **الخطوة دي مفيش رجوع فيها.**`
          ))
          .addSeparatorComponents(new SeparatorBuilder())
          .addActionRowComponents(
            new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('resetpoints_confirm').setLabel('تأكيد التصفير').setStyle(ButtonStyle.Danger),
              new ButtonBuilder().setCustomId('resetpoints_cancel').setLabel('إلغاء').setStyle(ButtonStyle.Secondary)
            )
          );
        return message.reply({ components: [container], flags: V2_FLAGS });
      }

      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.points[member.id] = 0;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم تصفير نقاط ${member}`)], flags: V2_FLAGS });
    }
  },

  // ═══════════════════════════════ givep (أدمن) ═══════════════════════════════
  {
    name: 'givep',
    aliases: ['منح-نقاط', 'اعطاء-نقاط'],
    usage: '[منشن العضو] [عدد النقاط]',
    category: 'المتجر',
    description: 'إعطاء نقاط لعضو معين',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const amount = parseInt(args.find(a => !a.startsWith('<')));
      if (!member || isNaN(amount) || amount === 0) {
        return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      }
      const data = db.get(message.guild.id);
      const cur = data.points[member.id] || 0;
      data.points[member.id] = Math.max(0, cur + amount);
      db.commit(message.guild.id);
      return message.reply({
        components: [successEmbed(
          amount > 0
            ? `تم منح ${member} **${amount}** نقطة\nرصيده الآن: ${data.points[member.id]}`
            : `تم خصم ${member} **${Math.abs(amount)}** نقطة\nرصيده الآن: ${data.points[member.id]}`
        )],
        flags: V2_FLAGS
      });
    }
  },

  // ═══════════════════════════════ removep (أدمن) ═══════════════════════════════
  {
    name: 'removep',
    aliases: ['خصم-نقاط'],
    usage: '[منشن العضو] [عدد النقاط]',
    category: 'المتجر',
    description: 'خصم نقاط من عضو معين',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const amount = Math.abs(parseInt(args.find(a => !a.startsWith('<'))));
      if (!member || isNaN(amount) || amount === 0) {
        return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      }
      const data = db.get(message.guild.id);
      const cur = data.points[member.id] || 0;
      data.points[member.id] = Math.max(0, cur - amount);
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم خصم ${member} **${amount}** نقطة\nرصيده الآن: ${data.points[member.id]}`)], flags: V2_FLAGS });
    }
  },

  // ═══════════════════════════════ managetasks (أدمن) ═══════════════════════════════
  {
    name: 'shoptasks',
    aliases: ['إدارة-مهام-المتجر', 'مهام-المتجر'],
    usage: '',
    category: 'المتجر',
    description: 'تفعيل/تعطيل/تعديل/حذف نظام المهام اليومية والأسبوعية',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message) {
      const guildId = message.guild.id;
      const TRUE = config.emojis.trueTick;
      const FALSE = config.emojis.falseTick;

      function buildPanel() {
        const data = db.get(guildId);
        const enabled = data.tasks.enabled === true;
        const deletedDaily = data.tasks.deletedDaily || [];
        const deletedWeekly = data.tasks.deletedWeekly || [];
        const customDaily = data.tasks.customDaily || {};
        const customWeekly = data.tasks.customWeekly || {};
        const activeDaily = DAILY_POOL.filter(t => !deletedDaily.includes(t.id));
        const activeWeekly = WEEKLY_POOL.filter(t => !deletedWeekly.includes(t.id));

        const toggle = new ButtonBuilder()
          .setCustomId('shoptasks_toggle')
          .setLabel(enabled ? '⏸ تعطيل المهمات' : '▶ تفعيل المهمات')
          .setStyle(enabled ? ButtonStyle.Danger : ButtonStyle.Success);

        const statusLine = enabled ? `${TRUE} **نظام المهمات: مفعّل**` : `${FALSE} **نظام المهمات: معطّل**`;

        const dailyLines = activeDaily.map(t => {
          const c = customDaily[t.id];
          const pts = c?.points ?? t.points;
          const target = c?.target ?? t.target;
          return `\`${t.id}\` ${t.text.replace(/\*\*/g, '').slice(0, 40)} — **${pts} نقطة** / هدف: **${target}**`;
        }).join('\n') || 'مفيش مهمات يومية دلوقتي';

        const weeklyLines = activeWeekly.map(t => {
          const c = customWeekly[t.id];
          const pts = c?.points ?? t.points;
          const target = c?.target ?? t.target;
          return `\`${t.id}\` ${t.text.replace(/\*\*/g, '').slice(0, 40)} — **${pts} نقطة** / هدف: **${target}**`;
        }).join('\n') || 'مفيش مهمات أسبوعية دلوقتي';

        return new ContainerBuilder()
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `## إدارة نظام المهمات\n${statusLine}\n\n` +
            `**— المهمات اليومية (${activeDaily.length}) —**\n${dailyLines}\n\n` +
            `**— المهمات الأسبوعية (${activeWeekly.length}) —**\n${weeklyLines}`
          ))
          .addSeparatorComponents(new SeparatorBuilder())
          .addActionRowComponents(new ActionRowBuilder().addComponents(
            toggle,
            new ButtonBuilder().setCustomId('shoptasks_edit_daily').setLabel('✏️ تعديل يومية').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('shoptasks_edit_weekly').setLabel('✏️ تعديل أسبوعية').setStyle(ButtonStyle.Secondary)
          ))
          .addActionRowComponents(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('shoptasks_del_daily').setLabel('🗑 حذف يومية').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('shoptasks_del_weekly').setLabel('🗑 حذف أسبوعية').setStyle(ButtonStyle.Secondary)
          ));
      }

      const panelMsg = await message.reply({ components: [buildPanel()], flags: V2_FLAGS }).catch(() => null);
      if (!panelMsg) return;

      const collector = panelMsg.createMessageComponentCollector({ filter: i => i.user.id === message.author.id, time: 120000 });

      collector.on('collect', async interaction => {
        await interaction.deferUpdate().catch(() => {});
        const { customId } = interaction;
        const data = db.get(guildId);

        if (customId === 'shoptasks_toggle') {
          data.tasks.enabled = !(data.tasks.enabled === true);
          db.commit(guildId);
          return panelMsg.edit({ components: [buildPanel()], flags: V2_FLAGS }).catch(() => {});
        }

        const isDaily = customId === 'shoptasks_edit_daily' || customId === 'shoptasks_del_daily';
        const isEdit = customId === 'shoptasks_edit_daily' || customId === 'shoptasks_edit_weekly';
        const deletedDaily = data.tasks.deletedDaily || [];
        const deletedWeekly = data.tasks.deletedWeekly || [];
        const pool = isDaily ? DAILY_POOL.filter(t => !deletedDaily.includes(t.id)) : WEEKLY_POOL.filter(t => !deletedWeekly.includes(t.id));
        if (!pool.length) return;

        const opts = pool.slice(0, 25).map(t => ({
          label: `[${t.id}] ${t.text.replace(/\*\*/g, '').slice(0, 80)}`,
          value: t.id,
          description: `${t.points} نقطة — هدف: ${t.target}`
        }));

        const sel = new StringSelectMenuBuilder().setCustomId('shoptasks_pick').setPlaceholder('اختر المهمة').addOptions(opts);

        await panelMsg.edit({
          components: [
            new ContainerBuilder()
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(`اختر المهمة اللي تبي ${isEdit ? 'تعدلها' : 'تحذفها'}:`))
              .addActionRowComponents(new ActionRowBuilder().addComponents(sel))
          ],
          flags: V2_FLAGS
        }).catch(() => {});

        const pickInt = await panelMsg.awaitMessageComponent({ filter: i => i.user.id === message.author.id, time: 30000 }).catch(() => null);
        if (!pickInt) return panelMsg.edit({ components: [buildPanel()], flags: V2_FLAGS }).catch(() => {});
        await pickInt.deferUpdate().catch(() => {});
        const pickedId = pickInt.values[0];
        const task = pool.find(t => t.id === pickedId);

        if (!isEdit) {
          const key = isDaily ? 'deletedDaily' : 'deletedWeekly';
          data.tasks[key] = [...(data.tasks[key] || []), pickedId];
          db.commit(guildId);
          return panelMsg.edit({ components: [buildPanel()], flags: V2_FLAGS }).catch(() => {});
        }

        await panelMsg.edit({
          components: [
            new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent(
              `**تعديل المهمة:** \`${task.text.replace(/\*\*/g, '').slice(0, 60)}\`\n\n` +
              `النقاط الحالية: **${task.points}** | الهدف الحالي: **${task.target}**\n\n` +
              `**أرسل الآن:** \`النقاط الجديدة الهدف_الجديد\`\nمثال: \`50 30\``
            ))
          ],
          flags: V2_FLAGS
        }).catch(() => {});

        const collected = await message.channel.awaitMessages({ filter: m => m.author.id === message.author.id, max: 1, time: 30000 }).catch(() => null);
        const reply = collected?.first();
        await reply?.delete().catch(() => {});
        if (!reply) return panelMsg.edit({ components: [buildPanel()], flags: V2_FLAGS }).catch(() => {});

        const parts = reply.content.trim().split(/\s+/);
        const newPts = parseInt(parts[0]);
        const newTgt = parseInt(parts[1]);
        if (isNaN(newPts) || isNaN(newTgt)) return panelMsg.edit({ components: [buildPanel()], flags: V2_FLAGS }).catch(() => {});

        const key = isDaily ? 'customDaily' : 'customWeekly';
        data.tasks[key] = { ...(data.tasks[key] || {}), [pickedId]: { points: newPts, target: newTgt } };
        db.commit(guildId);
        return panelMsg.edit({ components: [buildPanel()], flags: V2_FLAGS }).catch(() => {});
      });

      collector.on('end', () => {
        panelMsg.edit({ components: [buildPanel()], flags: V2_FLAGS }).catch(() => {});
      });
    }
  }
];
