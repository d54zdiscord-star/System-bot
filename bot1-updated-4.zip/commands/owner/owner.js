const db = require('../../utils/db');
const { baseEmbed, successEmbed, errorEmbed, usageEmbed, V2_FLAGS } = require('../../utils/embed');
const permissions = require('../../utils/permissions');
const config = require('../../config');
const { reasonSuffix } = require('../../utils/moderation');

function prefixOf(guildId) {
  return db.get(guildId).prefix || config.defaultPrefix;
}

module.exports = [
  {
    name: 'vip',
    usage: '',
    description: 'أوامر الأونر',
    ownerOnly: true,
    async execute(message, args, client) {
      const ownerCmds = [...client.commands.values()].filter(c => c.ownerOnly);
      const list = ownerCmds.map(c => `\`${prefixOf(message.guild.id)}${c.name}\` - ${c.description || ''}`).join('\n');
      return message.reply({ components: [baseEmbed({ title: `${config.emojis.commands} أوامر مالك البوت`, description: list, boxed: true })], flags: V2_FLAGS });
    }
  },
  {
    name: 'cmd',
    usage: '[أمر]',
    description: 'إعدادات مفصلة لأي أمر',
    ownerOnly: true,
    async execute(message, args, client) {
      const prefix = prefixOf(message.guild.id);
      if (!args[0]) return message.reply({ components: [usageEmbed(prefix, this)], flags: V2_FLAGS });
      const cmd = client.commands.get(args[0]) || client.commands.get(client.aliases.get(args[0]));
      if (!cmd) return message.reply({ components: [errorEmbed('الأمر مش موجود.')], flags: V2_FLAGS });

      const data = db.get(message.guild.id);
      const disabled = data.settings.disabledCommands.includes(cmd.name);
      const allow = data.settings.allow[cmd.name] || [];
      const deny = data.settings.deny[cmd.name] || [];

      return message.reply({
        components: [
          baseEmbed({
            title: `إعدادات أمر ${cmd.name}`,
            fields: [
              { name: 'الحالة', value: disabled ? '<:fals:1533733827900473366> معطل' : '<:true:1533733814105407619> مفعل', inline: true },
              { name: 'الفئة', value: cmd.category, inline: true },
              { name: 'مسموح لـ', value: allow.map(i => `<@&${i}> <@${i}>`).join(', ') || 'مفيش' },
              { name: 'ممنوع عن', value: deny.map(i => `<@&${i}> <@${i}>`).join(', ') || 'مفيش' }
            ]
          })
        ], flags: V2_FLAGS
      });
    }
  },
  {
    name: 'acomnd',
    usage: '[اختصار] [أمر]',
    description: 'إضافة اختصار لأمر',
    ownerOnly: true,
    async execute(message, args) {
      const [shortcut, cmdName] = args;
      if (!shortcut || !cmdName) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.settings.customAliases = data.settings.customAliases || {};
      data.settings.customAliases[shortcut] = cmdName;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم إضافة اختصار \`${shortcut}\` لأمر \`${cmdName}\``)], flags: V2_FLAGS });
    }
  },
  {
    name: 'نوبريفكس',
    usage: '[أمر]',
    description: 'السماح لأمر معين يشتغل من غير بريفكس خالص',
    ownerOnly: true,
    async execute(message, args) {
      const cmdName = args[0];
      if (!cmdName) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.settings.noPrefixCommands = data.settings.noPrefixCommands || [];
      const idx = data.settings.noPrefixCommands.indexOf(cmdName);
      if (idx === -1) {
        data.settings.noPrefixCommands.push(cmdName);
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed(`دلوقتي أمر \`${cmdName}\` يشتغل من غير بريفكس.`)], flags: V2_FLAGS });
      } else {
        data.settings.noPrefixCommands.splice(idx, 1);
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed(`رجّعنا أمر \`${cmdName}\` يحتاج بريفكس تاني.`)], flags: V2_FLAGS });
      }
    }
  },
  {
    name: 'showaliases',
    usage: '',
    description: 'عرض كل الاختصارات',
    ownerOnly: true,
    async execute(message, args, client) {
      const builtIn = [...client.aliases.entries()].map(([a, c]) => `\`${a}\` → \`${c}\``).join('\n') || 'مفيش';
      const data = db.get(message.guild.id);
      const custom = Object.entries(data.settings.customAliases || {}).map(([a, c]) => `\`${a}\` → \`${c}\``).join('\n') || 'مفيش';
      return message.reply({
        components: [baseEmbed({ title: 'كل الاختصارات', fields: [{ name: 'الأساسية', value: builtIn }, { name: 'المخصصة', value: custom }] })], flags: V2_FLAGS
      });
    }
  },
  {
    name: 'listlcomnd',
    usage: '',
    description: 'قائمة الاختصارات المخصصة',
    ownerOnly: true,
    async execute(message) {
      const data = db.get(message.guild.id);
      const custom = Object.entries(data.settings.customAliases || {}).map(([a, c]) => `\`${a}\` → \`${c}\``).join('\n') || 'مفيش اختصارات مخصصة.';
      return message.reply({ components: [baseEmbed({ title: 'الاختصارات المخصصة', description: custom })], flags: V2_FLAGS });
    }
  },
  {
    name: 'removeShortcut',
    usage: '[اختصار]',
    description: 'حذف اختصار',
    ownerOnly: true,
    async execute(message, args) {
      const shortcut = args[0];
      if (!shortcut) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      if (data.settings.customAliases && data.settings.customAliases[shortcut]) {
        delete data.settings.customAliases[shortcut];
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed(`تم حذف الاختصار \`${shortcut}\``)], flags: V2_FLAGS });
      }
      return message.reply({ components: [errorEmbed('الاختصار ده مش موجود.')], flags: V2_FLAGS });
    }
  },
  {
    name: 'canvasset',
    usage: '[لون هيكس]',
    description: 'تغيير ألوان صور Canvas',
    ownerOnly: true,
    async execute(message, args) {
      const color = args[0];
      if (!color) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.settings.canvasColor = color;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم حفظ لون الكانفاس: **${color}**`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'say',
    usage: '[منشن شات (اختياري)] [النص]',
    description: 'إرسال رسالة عن طريق البوت',
    ownerOnly: true,
    async execute(message, args) {
      const channel = message.mentions.channels.first() || message.channel;
      const text = message.mentions.channels.first() ? args.slice(1).join(' ') : args.join(' ');
      if (!text) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      message.delete().catch(() => {});
      return channel.send(text);
    }
  },
  {
    name: 'setprefix',
    usage: '[البريفكس الجديد]',
    description: 'تغيير بادئة البوت',
    ownerOnly: true,
    async execute(message, args) {
      const newPrefix = args[0];
      if (!newPrefix || newPrefix.length > 5) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.prefix = newPrefix;
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم تغيير البريفكس لـ \`${newPrefix}\``)], flags: V2_FLAGS });
    }
  },
  {
    name: 'cmunprefix',
    usage: '[on/off]',
    description: 'تشغيل الأوامر الإدارية بدون بريفكس',
    ownerOnly: true,
    async execute(message, args) {
      if (!args[0]) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.settings.adminNoPrefix = args[0].toLowerCase() === 'on';
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم ${data.settings.adminNoPrefix ? 'تفعيل' : 'تعطيل'} تشغيل أوامر الإدارة بدون بريفكس.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'owners',
    usage: '',
    description: 'قائمة الأونرات',
    ownerOnly: true,
    async execute(message) {
      const data = db.get(message.guild.id);
      const list = [message.guild.ownerId, ...data.owners].map(id => `<@${id}>`).join('\n');
      return message.reply({ components: [baseEmbed({ title: 'أونرات البوت في السيرفر', description: list })], flags: V2_FLAGS });
    }
  },
  {
    name: 'setowner',
    usage: '[منشن العضو]',
    description: 'إضافة أونر',
    ownerOnly: true,
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      if (!data.owners.includes(member.id)) data.owners.push(member.id);
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم إضافة ${member} كأونر للبوت.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'removeowner',
    usage: '[منشن العضو]',
    description: 'إزالة أونر',
    ownerOnly: true,
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      data.owners = data.owners.filter(id => id !== member.id);
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم إزالة ${member} من الأونرات.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'staffwarn',
    usage: '[منشن العضو] [السبب]',
    description: 'تحذير إداري للستاف (للأونر بس)',
    ownerOnly: true,
    async execute(message, args) {
      const member = message.mentions.members.first();
      const reason = args.slice(1).join(' ') || null;
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const data = db.get(message.guild.id);
      if (!data.staffWarnings) data.staffWarnings = {};
      if (!data.staffWarnings[member.id]) data.staffWarnings[member.id] = [];

      const warnEntry = {
        reason,
        mod: message.author.id,
        modTag: message.author.tag,
        date: Date.now(),
        id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
      };

      data.staffWarnings[member.id].push(warnEntry);
      const count = data.staffWarnings[member.id].length;
      db.commit(message.guild.id);

      const { sendDetailedLog } = require('../../utils/logs');
      sendDetailedLog(message.guild, 'logstaffwarns', {
        title: '⚠️ ستاف وارن',
        iconKey: 'staffwarn',
        executor: message.author,
        target: member.user,
        reason,
        count,
        extraFields: [
          { name: '🔢 الرقم', value: `\`${count}\``, inline: true },
          { name: '🆔 ID', value: `\`${warnEntry.id}\``, inline: true }
        ]
      });

      try {
        await member.send({
          components: [baseEmbed({
            title: '⚠️ تحذير إداري',
            description: `تم إعطائك تحذير إداري في سيرفر **${message.guild.name}**`,
            fields: [
              ...(reason ? [{ name: 'السبب', value: reason }] : []),
              { name: 'بواسطة', value: `<@${message.author.id}>` },
              { name: 'عدد التحذيرات', value: `\`${count}\`` }
            ]
          })],
          flags: V2_FLAGS
        });
      } catch {}

      return message.reply({ 
        components: [successEmbed(`تم إعطاء ${member} تحذير إداري (#${count})${reasonSuffix(reason)}`)], 
        flags: V2_FLAGS 
      });
    }
  },
  {
    name: 'staffwarns',
    usage: '[منشن العضو]',
    description: 'عرض التحذيرات الإدارية لعضو',
    ownerOnly: true,
    async execute(message, args) {
      const member = message.mentions.members.first() || message.member;
      const data = db.get(message.guild.id);
      const list = data.staffWarnings?.[member.id] || [];
      if (!list.length) return message.reply({ components: [errorEmbed('العضو ده معندوش تحذيرات إدارية.')], flags: V2_FLAGS });

      const text = list.map((w, i) => 
        `**${i + 1}.**${w.reason ? ` ${w.reason}` : ''}
بواسطة: <@${w.mod}> | \`${w.modTag}\`
<t:${Math.floor(w.date / 1000)}:R> | ID: \`${w.id}\``
      ).join('\n\n');

      return message.reply({ 
        components: [baseEmbed({ title: `⚠️ تحذيرات إدارية ${member.user.username} (${list.length})`, description: text, boxed: true })], 
        flags: V2_FLAGS 
      });
    }
  },
  {
    name: 'remove-staffwarn',
    usage: '[منشن العضو] [رقم التحذير]',
    description: 'إزالة تحذير إداري',
    ownerOnly: true,
    async execute(message, args) {
      const member = message.mentions.members.first();
      const idx = parseInt(args[1], 10) - 1;
      if (!member || isNaN(idx)) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const data = db.get(message.guild.id);
      const list = data.staffWarnings?.[member.id] || [];
      if (!list[idx]) return message.reply({ components: [errorEmbed('رقم التحذير مش موجود.')], flags: V2_FLAGS });

      const removed = list.splice(idx, 1)[0];
      db.commit(message.guild.id);

      const { sendDetailedLog } = require('../../utils/logs');
      sendDetailedLog(message.guild, 'logstaffwarns', {
        title: '✅ إزالة ستاف وارن',
        iconKey: 'staffwarn_remove',
        executor: message.author,
        target: member.user,
        extraFields: [
          { name: '🔢 رقم الوارن', value: `\`${idx + 1}\``, inline: true },
          ...(removed.reason ? [{ name: '📝 السبب كان', value: `\`${removed.reason}\``, inline: true }] : [])
        ]
      });

      return message.reply({ components: [successEmbed(`تم إزالة التحذير الإداري رقم (${idx + 1}) من ${member}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'stealemoji',
    usage: ':emoji1: :emoji2: ...',
    description: 'سرقة إيموجي من سيرفر تاني وإضافته عندنا (اكتب الإيموجي جنب الأمر)',
    ownerOnly: true,
    async execute(message, args, client) {
      const fullText = message.content;
      const emojiRegex = /<a?:(\w{2,32}):(\d{17,20})>/g;
      const emojis = [];
      let match;

      while ((match = emojiRegex.exec(fullText)) !== null) {
        emojis.push({ 
          name: match[1], 
          id: match[2], 
          animated: fullText.includes(`<a:${match[1]}:${match[2]}>`) 
        });
      }

      if (!emojis.length) {
        return message.reply({ 
          components: [errorEmbed('مفيش إيموجي في رسالتك. اكتب الإيموجي جنب الأمر مباشرة. مثال: `$stealemoji :emoji1: :emoji2:`')], 
          flags: V2_FLAGS 
        });
      }

      const results = [];
      const failed = [];

      for (const emoji of emojis) {
        try {
          const url = `https://cdn.discordapp.com/emojis/${emoji.id}.${emoji.animated ? 'gif' : 'png'}?size=128&quality=lossless`;
          const created = await message.guild.emojis.create({ attachment: url, name: emoji.name });
          results.push(`${created} | \`:${created.name}:\``);
        } catch (err) {
          failed.push(`\`:${emoji.name}:\` - ${err.message || 'فشل'}`);
        }
      }

      if (results.length) {
        const { sendDetailedLog } = require('../../utils/logs');
        sendDetailedLog(message.guild, 'logemoji', {
          title: '😀 سرقة إيموجي',
          iconKey: 'steal_emoji',
          executor: message.author,
          extraFields: [
            { name: '✅ نجح', value: results.join('\n') || 'مفيش', inline: false },
            { name: '🔢 العدد', value: `\`${results.length}/${emojis.length}\``, inline: true }
          ]
        });
      }

      let replyText = '';
      if (results.length) replyText += `✅ **تم سرقة ${results.length} إيموجي:**\n${results.join('\n')}\n\n`;
      if (failed.length) replyText += `❌ **فشل (${failed.length}):**\n${failed.join('\n')}`;

      return message.reply({ 
        components: [baseEmbed({ title: '😀 نتيجة', description: replyText || 'مفيش نتيجة' })], 
        flags: V2_FLAGS 
      });
    }
  },
  {
    name: 'stealstickers',
    usage: '(رد على رسالة فيها الستيكر)',
    description: 'سرقة ستيكر من سيرفر تاني وإضافته عندنا',
    ownerOnly: true,
    async execute(message, args, client) {
      let targetMessage = message.reference ? await message.channel.messages.fetch(message.reference.messageId).catch(() => null) : null;

      if (!targetMessage) {
        return message.reply({ 
          components: [errorEmbed('لازم ترد على رسالة فيها الستيكر اللي عايز تسرقه.')], 
          flags: V2_FLAGS 
        });
      }

      if (!targetMessage.stickers.size) {
        return message.reply({ 
          components: [errorEmbed('مفيش ستيكر في الرسالة دي.')], 
          flags: V2_FLAGS 
        });
      }

      const results = [];
      const failed = [];

      for (const sticker of targetMessage.stickers.values()) {
        try {
          const stickerData = await sticker.fetch();
          const response = await fetch(stickerData.url);
          const buffer = Buffer.from(await response.arrayBuffer());

          const created = await message.guild.stickers.create({
            file: buffer,
            name: stickerData.name,
            tags: stickerData.tags || 'sticker'
          });
          results.push(`**${created.name}**`);
        } catch (err) {
          failed.push(`**${sticker.name}** - ${err.message || 'فشل'}`);
        }
      }

      if (results.length) {
        const { sendDetailedLog } = require('../../utils/logs');
        sendDetailedLog(message.guild, 'logemoji', {
          title: '🎨 سرقة ستيكر',
          iconKey: 'steal_emoji',
          executor: message.author,
          extraFields: [
            { name: '✅ نجح', value: results.join('\n') || 'مفيش', inline: false },
            { name: '🔢 العدد', value: `\`${results.length}/${targetMessage.stickers.size}\``, inline: true },
            { name: '🔗 المصدر', value: `[رسالة المصدر](${targetMessage.url})`, inline: true }
          ]
        });
      }

      let replyText = '';
      if (results.length) replyText += `✅ **تم سرقة ${results.length} ستيكر:**\n${results.join('\n')}\n\n`;
      if (failed.length) replyText += `❌ **فشل (${failed.length}):**\n${failed.join('\n')}`;

      return message.reply({ 
        components: [baseEmbed({ title: '🎨 نتيجة', description: replyText || 'مفيش نتيجة' })], 
        flags: V2_FLAGS 
      });
    }
  }
];