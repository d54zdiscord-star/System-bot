const {
  PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize,
  MessageFlags
} = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, successEmbed, errorEmbed, usageEmbed, V2_FLAGS } = require('../../utils/embed');
const config = require('../../config');

function ms(str) {
  const units = { s: 1000, m: 60000, h: 3600000, d: 86400000, w: 604800000 };
  const m = str.toLowerCase().match(/^(\d+)([smhdw])$/);
  return m ? parseInt(m[1]) * units[m[2]] : null;
}

function formatDuration(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  if (d > 0) return `${d} يوم ${h % 24} ساعة`;
  if (h > 0) return `${h} ساعة ${m % 60} دقيقة`;
  if (m > 0) return `${m} دقيقة ${s % 60} ثانية`;
  return `${s} ثانية`;
}

function divider() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

// ── Build giveaway message (ACTIVE) ──
async function buildGiveawayActive(giveaway) {
  const container = new ContainerBuilder();
  container.setAccentColor(0x5865f2);

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`## 🎁 بدأ الجيفاوي 🎁`)
  );
  container.addSeparatorComponents(divider());

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`**${giveaway.prize}**`)
  );
  container.addSeparatorComponents(divider());

  const infoLines = [
    `اضغط على 🎁 للمشاركة`,
    `المنظم  <@${giveaway.hostId}>`,
    `الفائزين  ${giveaway.winners}`,
    `ينتهي في  <t:${Math.floor(giveaway.endTime / 1000)}:F>`,
  ];

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(infoLines.join('\n'))
  );
  container.addSeparatorComponents(divider());

  const btn = new ButtonBuilder()
    .setCustomId(`giveaway_join_${giveaway.messageId}`)
    .setLabel(`${giveaway.entries.length}`)
    .setStyle(ButtonStyle.Primary)
    .setEmoji('🎁');

  const row = new ActionRowBuilder().addComponents(btn);

  return { components: [container, row], flags: V2_FLAGS };
}

// ── Build giveaway message (ENDED) ──
async function buildGiveawayEnded(giveaway) {
  const container = new ContainerBuilder();
  container.setAccentColor(0x2f3136);

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`## 🎉 انتهى الجيفاوي 🎉`)
  );
  container.addSeparatorComponents(divider());

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`**${giveaway.prize}**`)
  );
  container.addSeparatorComponents(divider());

  const winnersText = giveaway.winnerIds?.length
    ? giveaway.winnerIds.map(id => `<@${id}>`).join(', ')
    : 'مفيش فائزين';

  const infoLines = [
    `المنظم  <@${giveaway.hostId}>`,
    `الفائز  ${winnersText}`,
    `انتهى في  <t:${Math.floor(giveaway.endTime / 1000)}:F>`,
  ];

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(infoLines.join('\n'))
  );
  container.addSeparatorComponents(divider());

  const btn = new ButtonBuilder()
    .setCustomId(`giveaway_join_${giveaway.messageId}`)
    .setLabel(`${giveaway.entries.length}`)
    .setStyle(ButtonStyle.Secondary)
    .setEmoji('🎁')
    .setDisabled(true);

  const row = new ActionRowBuilder().addComponents(btn);

  return { components: [container, row], flags: V2_FLAGS };
}

// ── Pick winners ──
function pickWinners(entries, count) {
  if (!entries.length) return [];
  const shuffled = [...entries].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

// ── End giveaway ──
async function endGiveaway(client, guildId, messageId) {
  const data = db.get(guildId);
  const g = data.giveaways?.[messageId];
  if (!g || g.ended) return;

  g.ended = true;
  g.winnerIds = pickWinners(g.entries, g.winners);
  db.commit(guildId);

  const guild = client.guilds.cache.get(guildId);
  if (!guild) return;
  const channel = guild.channels.cache.get(g.channelId);
  if (!channel) return;

  try {
    const msg = await channel.messages.fetch(messageId).catch(() => null);
    if (msg) {
      const built = await buildGiveawayEnded(g);
      await msg.edit(built);
    }
  } catch (e) { console.error('[Giveaway] Edit error:', e); }

  if (g.winnerIds?.length) {
    const winnerMentions = g.winnerIds.map(id => `<@${id}>`).join(' ');
    await channel.send({
      content: `🎉 مبروك ${winnerMentions}! لقد فزت بالجيفاوي 🎉`,
      allowedMentions: { users: g.winnerIds }
    }).catch(() => {});
  }
}

// ── Get giveaway from reply ──
async function getGiveawayFromReply(message) {
  if (!message.reference) return null;
  try {
    const repliedMsg = await message.channel.messages.fetch(message.reference.messageId);
    if (!repliedMsg) return null;
    const data = db.get(message.guild.id);
    const g = data.giveaways?.[repliedMsg.id];
    if (g) return { msgId: repliedMsg.id, giveaway: g };
    return null;
  } catch { return null; }
}

module.exports = [
  {
    name: 'gstart',
    aliases: ['giveaway', 'سحب'],
    usage: '[مدة] [عدد فائزين] [الجايزة]',
    description: 'بدء سحب جديد',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message, args) {
      const prefix = db.get(message.guild.id).prefix || config.defaultPrefix;
      if (args.length < 3) {
        return message.reply({
          components: [usageEmbed(prefix, { name: 'gstart', usage: '[مدة مثلا 1h/30m/1d] [عدد فائزين] [الجايزة]', description: 'بدء سحب جديد' })],
          flags: V2_FLAGS
        });
      }

      const durationMs = ms(args[0]);
      if (!durationMs || durationMs < 10000) {
        return message.reply({
          components: [errorEmbed('المدة غلط. استخدم 10s / 5m / 1h / 1d / 1w (أقل حاجة 10 ثواني)')],
          flags: V2_FLAGS
        });
      }
      if (durationMs > 604800000) {
        return message.reply({
          components: [errorEmbed('المدة القصوى أسبوع واحد')],
          flags: V2_FLAGS
        });
      }

      const winners = parseInt(args[1]);
      if (isNaN(winners) || winners < 1 || winners > 25) {
        return message.reply({
          components: [errorEmbed('عدد الفائزين لازم يكون بين 1 و 25')],
          flags: V2_FLAGS
        });
      }

      const prize = args.slice(2).join(' ');
      if (prize.length > 256) {
        return message.reply({
          components: [errorEmbed('الجايزة طويلة أوي (أقصى حاجة 256 حرف)')],
          flags: V2_FLAGS
        });
      }

      const data = db.get(message.guild.id);
      if (!data.giveaways) data.giveaways = {};

      const endTime = Date.now() + durationMs;

      const giveaway = {
        messageId: null,
        channelId: message.channel.id,
        prize,
        winners,
        endTime,
        entries: [],
        ended: false,
        hostId: message.author.id,
        guildId: message.guild.id,
        winnerIds: []
      };

      // نبعت الرسالة الأول (الزر مؤقت ومعطل) عشان نعرف الـ message ID الحقيقي،
      // لأن لو حطينا ID مؤقت في الزر من البداية، الضغط عليه بعد كده هيفشل
      // (ده كان سبب مشكلة "الجيفاوي ده مش موجود أو اتمسح")
      const placeholderBtn = new ButtonBuilder()
        .setCustomId('giveaway_pending')
        .setLabel('0')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('🎁')
        .setDisabled(true);
      const placeholderContainer = (await buildGiveawayActive({ ...giveaway, messageId: 'pending', entries: [] })).components[0];
      const msg = await message.channel.send({
        components: [placeholderContainer, new ActionRowBuilder().addComponents(placeholderBtn)],
        flags: V2_FLAGS
      });

      giveaway.messageId = msg.id;
      data.giveaways[msg.id] = giveaway;
      db.commit(message.guild.id);

      // دلوقتي نعدل الرسالة بالزر الصحيح اللي فيه الـ message ID الحقيقي
      const built = await buildGiveawayActive(giveaway);
      await msg.edit(built).catch(() => {});

      setTimeout(() => {
        endGiveaway(message.client, message.guild.id, msg.id).catch(() => {});
      }, durationMs);

      message.delete().catch(() => {});
    }
  },

  {
    name: 'gend',
    aliases: ['giveawayend', 'انهاء'],
    usage: '',
    description: 'إنهاء سحب (اعمل ريبلاي على رسالة الجيفاوي)',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message, args) {
      let msgId = args[0];
      let g = null;

      if (!msgId && message.reference) {
        const fromReply = await getGiveawayFromReply(message);
        if (fromReply) {
          msgId = fromReply.msgId;
          g = fromReply.giveaway;
        }
      }

      if (!g && msgId) {
        const data = db.get(message.guild.id);
        g = data.giveaways?.[msgId];
      }

      if (!g) {
        return message.reply({
          components: [errorEmbed('اعمل ريبلاي على رسالة الجيفاوي أو حط الـ ID')],
          flags: V2_FLAGS
        });
      }
      if (g.ended) {
        return message.reply({
          components: [errorEmbed('الجيفاوي ده خلاص انتهى')],
          flags: V2_FLAGS
        });
      }

      await endGiveaway(message.client, message.guild.id, msgId || g.messageId);
      message.reply({
        components: [successEmbed('تم إنهاء الجيفاوي')],
        flags: V2_FLAGS
      });
    }
  },

  {
    name: 'greroll',
    aliases: ['giveawayreroll', 'اعادة'],
    usage: '',
    description: 'إعادة سحب الفائزين (اعمل ريبلاي على رسالة الجيفاوي)',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message, args) {
      let msgId = args[0];
      let g = null;

      if (!msgId && message.reference) {
        const fromReply = await getGiveawayFromReply(message);
        if (fromReply) {
          msgId = fromReply.msgId;
          g = fromReply.giveaway;
        }
      }

      if (!g && msgId) {
        const data = db.get(message.guild.id);
        g = data.giveaways?.[msgId];
      }

      if (!g) {
        return message.reply({
          components: [errorEmbed('اعمل ريبلاي على رسالة الجيفاوي أو حط الـ ID')],
          flags: V2_FLAGS
        });
      }
      if (!g.ended) {
        return message.reply({
          components: [errorEmbed('الجيفاوي لسه شغال. استخدم gend الأول')],
          flags: V2_FLAGS
        });
      }

      const newWinners = pickWinners(g.entries, g.winners);
      g.winnerIds = newWinners;
      db.commit(message.guild.id);

      try {
        const channel = message.guild.channels.cache.get(g.channelId);
        if (channel) {
          const msg = await channel.messages.fetch(msgId || g.messageId).catch(() => null);
          if (msg) {
            const built = await buildGiveawayEnded(g);
            await msg.edit(built);
          }
        }
      } catch (e) { console.error('[Giveaway] Reroll edit error:', e); }

      if (newWinners.length) {
        const winnerMentions = newWinners.map(id => `<@${id}>`).join(' ');
        await message.channel.send({
          content: `🎉 مبروك ${winnerMentions}! لقد فزت بالجيفاوي 🎉`,
          allowedMentions: { users: newWinners }
        }).catch(() => {});
      }

      message.reply({
        components: [successEmbed('تم إعادة السحب')],
        flags: V2_FLAGS
      });
    }
  },

  {
    name: 'gdelete',
    aliases: ['giveawaydelete', 'حذف-سحب'],
    usage: '[message id]',
    description: 'حذف سحب من الداتا',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message, args) {
      let msgId = args[0];
      let g = null;

      if (!msgId && message.reference) {
        const fromReply = await getGiveawayFromReply(message);
        if (fromReply) {
          msgId = fromReply.msgId;
          g = fromReply.giveaway;
        }
      }

      if (!g && msgId) {
        const data = db.get(message.guild.id);
        g = data.giveaways?.[msgId];
      }

      if (!g) {
        return message.reply({
          components: [errorEmbed('مفيش جيفاوي بالـ ID ده')],
          flags: V2_FLAGS
        });
      }

      try {
        const channel = message.guild.channels.cache.get(g.channelId);
        if (channel) {
          const msg = await channel.messages.fetch(msgId || g.messageId).catch(() => null);
          if (msg) await msg.delete();
        }
      } catch {}

      const data = db.get(message.guild.id);
      delete data.giveaways[msgId || g.messageId];
      db.commit(message.guild.id);

      message.reply({
        components: [successEmbed('تم حذف الجيفاوي')],
        flags: V2_FLAGS
      });
    }
  },

  {
    name: 'glist',
    aliases: ['giveaways', 'سحوبات'],
    usage: '',
    description: 'قائمة السحوبات النشطة',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const data = db.get(message.guild.id);
      const giveaways = Object.entries(data.giveaways || {})
        .filter(([, g]) => !g.ended)
        .map(([id, g]) => ({ id, ...g }));

      if (!giveaways.length) {
        return message.reply({
          components: [baseEmbed({ description: 'مفيش سحوبات نشطة حاليًا' })],
          flags: V2_FLAGS
        });
      }

      const lines = giveaways.map((g, i) =>
        `**#${i + 1}** <#${g.channelId}> — **${g.prize}** — ينتهي <t:${Math.floor(g.endTime / 1000)}:R> — \`${g.entries.length}\` مشارك`
      );

      message.reply({
        components: [baseEmbed({
          title: `${config.emojis.info} السحوبات النشطة (${giveaways.length})`,
          description: lines.join('\n'),
          boxed: true
        })],
        flags: V2_FLAGS
      });
    }
  }
];

module.exports.endGiveaway = endGiveaway;
module.exports.buildGiveawayActive = buildGiveawayActive;
module.exports.buildGiveawayEnded = buildGiveawayEnded;
