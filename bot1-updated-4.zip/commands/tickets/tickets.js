const {
  PermissionFlagsBits, ChannelSelectMenuBuilder, ChannelType, ActionRowBuilder,
  RoleSelectMenuBuilder, ButtonBuilder, ButtonStyle
} = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, successEmbed, errorEmbed, V2_FLAGS } = require('../../utils/embed');
const { buildPanelSelectMenu, buildPanelButtons } = require('../../utils/tickets');

const MAX_TYPES = 25; // أقصى عدد أنواع تكت (بدل الـ 5 القديمة) - محكوم بحد ديسكورد الحقيقي للأزرار/السيلكت

async function ask(message, question) {
  const questionMsg = await message.channel.send({ components: [baseEmbed({ description: question })], flags: V2_FLAGS });
  const collected = await message.channel
    .awaitMessages({ filter: m => m.author.id === message.author.id, max: 1, time: 120000 })
    .catch(() => null);
  questionMsg.delete().catch(() => {});
  if (!collected || !collected.size) return null;
  const msg = collected.first();
  msg.delete().catch(() => {});
  return msg;
}

// ─── سؤال باختيار من زرارين (زي شكل الرسالة / شكل القائمة في بوت ١) ───
async function askChoice(message, question, choices) {
  const rowBtns = new ActionRowBuilder().addComponents(
    choices.map(c => new ButtonBuilder().setCustomId(`stc_choice_${c.id}`).setLabel(c.label).setStyle(ButtonStyle.Secondary))
  );
  const msg = await message.channel.send({ components: [baseEmbed({ description: question }), rowBtns], flags: V2_FLAGS });
  const picked = await msg.awaitMessageComponent({ filter: i => i.user.id === message.author.id, time: 60000 }).catch(() => null);
  await msg.delete().catch(() => {});
  if (!picked) return null;
  await picked.deferUpdate().catch(() => {});
  return picked.customId.replace('stc_choice_', '');
}

// ─── سؤال باختيار شات (شريط اختيار حقيقي - بدل المنشن) مع إمكانية التخطي ───
async function askChannelSelect(message, question, channelType, skippable = true) {
  const menu = new ChannelSelectMenuBuilder().setCustomId('stc_pick').setChannelTypes(channelType).setPlaceholder('اختر...');
  const rows = [new ActionRowBuilder().addComponents(menu)];
  if (skippable) rows.push(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('stc_skip').setLabel('بدون / تخطي').setStyle(ButtonStyle.Secondary)));

  const msg = await message.channel.send({ components: [baseEmbed({ description: question }), ...rows], flags: V2_FLAGS });
  const picked = await msg.awaitMessageComponent({ filter: i => i.user.id === message.author.id, time: 120000 }).catch(() => null);
  await msg.delete().catch(() => {});
  if (!picked) return undefined; // انتهى الوقت
  await picked.deferUpdate().catch(() => {});
  if (picked.customId === 'stc_skip') return null;
  return picked.values[0];
}

// ─── سؤال باختيار رولات إدارية متعددة (بدل ID/منشن رول واحد) ───
async function askRolesSelect(message, question) {
  const menu = new RoleSelectMenuBuilder().setCustomId('stc_roles').setMinValues(0).setMaxValues(10).setPlaceholder('اختر رول واحد أو أكتر (اختياري)...');
  const skipBtn = new ButtonBuilder().setCustomId('stc_skip').setLabel('بدون رولات').setStyle(ButtonStyle.Secondary);
  const msg = await message.channel.send({
    components: [baseEmbed({ description: question }), new ActionRowBuilder().addComponents(menu), new ActionRowBuilder().addComponents(skipBtn)],
    flags: V2_FLAGS
  });
  const picked = await msg.awaitMessageComponent({ filter: i => i.user.id === message.author.id, time: 120000 }).catch(() => null);
  await msg.delete().catch(() => {});
  if (!picked) return [];
  await picked.deferUpdate().catch(() => {});
  if (picked.customId === 'stc_skip') return [];
  return picked.values;
}

module.exports = [
  {
    name: 'setticket',
    usage: '',
    category: 'تكتات',
    description: 'إعداد نظام التكتات بالكامل (أنواع، رولات إدارية، تصنيف، شات لوج، شكل القائمة)',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const data = db.get(message.guild.id);

      // ── ١. عدد الأنواع ──
      const countMsg = await ask(message, `**١. كم نوع تكت تريد إضافته؟ (1-${MAX_TYPES})**`);
      if (!countMsg) return message.channel.send({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS });
      const count = Math.min(Math.max(parseInt(countMsg.content, 10) || 0, 1), MAX_TYPES);

      // ── ٢. بيانات كل نوع ──
      const types = [];
      for (let i = 1; i <= count; i++) {
        const nameMsg = await ask(message, `**اسم النوع ${i}:**`);
        if (!nameMsg) return message.channel.send({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS });

        const descMsg = await ask(message, `**وصف النوع ${i} (أو \`skip\`):**`);
        const desc = descMsg && descMsg.content.toLowerCase() !== 'skip' ? descMsg.content : '';

        const emojiMsg = await ask(message, `**إيموجي النوع ${i} (أو \`skip\`):**`);
        const emoji = emojiMsg && emojiMsg.content.toLowerCase() !== 'skip' ? emojiMsg.content.trim() : '';

        const insideMsg = await ask(message, `**نص الرسالة داخل التكت لنوع "${nameMsg.content}" (أو \`skip\`) - ممكن تستخدم {user}:**`);
        const insideMessage = insideMsg && insideMsg.content.toLowerCase() !== 'skip' ? insideMsg.content : '';

        const adminRoleIds = await askRolesSelect(message, `**رولات الإدارة الخاصة بنوع "${nameMsg.content}"** (ممكن تختار أكتر من رول، أو تتخطى وهيتفعل بس الرولات العامة من \`ticketadmins\`):`);

        types.push({
          id: `type_${Date.now()}_${i}`,
          name: nameMsg.content,
          description: desc,
          emoji,
          message: insideMessage,
          adminRoleIds
        });
      }

      // ── ٣. شكل قائمة التكت ──
      const menuStyle = await askChoice(message, '**اختر شكل قائمة التكت:**', [
        { id: 'select', label: 'قائمة منسدلة' },
        { id: 'buttons', label: 'أزرار' }
      ]) || 'select';

      // ── ٤. وصف اللوحة (اختياري) ──
      const panelDescMsg = await ask(message, '**أرسل وصف لوحة التكت (أو `skip`):**');
      const embedDescription = panelDescMsg && panelDescMsg.content.toLowerCase() !== 'skip' ? panelDescMsg.content : '';

      // ── ٥. التصنيف (اختياري) ──
      const categoryId = await askChannelSelect(message, '**اختر الكاتيجوري اللي هتتفتح فيها التكتات (أو تخطى):**', ChannelType.GuildCategory);
      if (categoryId === undefined) return message.channel.send({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS });

      // ── ٦. شات اللوج (اختياري - نفس شات "setlog ticket") ──
      const logChannelId = await askChannelSelect(message, '**اختر شات لوج التكتات (فتح/قفل مع ترانسكريبت/حذف) - أو تخطى:**', ChannelType.GuildText);
      if (logChannelId === undefined) return message.channel.send({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS });

      // ── ٧. شات إرسال اللوحة (إجباري) ──
      const panelChannelId = await askChannelSelect(message, '**اختر الشات اللي هتتبعت فيه لوحة التكت:**', ChannelType.GuildText, false);
      if (!panelChannelId) return message.channel.send({ components: [errorEmbed('لازم تختار شات صحيح.')], flags: V2_FLAGS });
      const targetChannel = message.guild.channels.cache.get(panelChannelId);
      if (!targetChannel) return message.channel.send({ components: [errorEmbed('الشات مش موجود.')], flags: V2_FLAGS });

      // ── الحفظ ──
      data.tickets.types = types;
      data.tickets.menuStyle = menuStyle;
      data.tickets.embedDescription = embedDescription || null;
      data.tickets.categoryId = categoryId || null;
      data.settings.logChannels.ticket = logChannelId || null;
      data.tickets.panelChannelId = targetChannel.id;
      db.commit(message.guild.id);

      // ── إرسال اللوحة ──
      const embed = baseEmbed({
        title: 'لوحة التكتات',
        description: embedDescription || undefined,
        image: data.tickets.imageUrl || undefined
      });

      const panelComponents = menuStyle === 'buttons' ? buildPanelButtons(types) : [buildPanelSelectMenu(types)];
      const panelMsg = await targetChannel.send({ components: [embed, ...panelComponents], flags: V2_FLAGS });

      data.tickets.panelMessageId = panelMsg.id;
      db.commit(message.guild.id);

      return message.channel.send({ components: [successEmbed(`تم إعداد نظام التكتات في ${targetChannel} بـ ${types.length} نوع.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'ticketadmins',
    usage: '',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const { RoleSelectMenuBuilder } = require('discord.js');
      const menu = new RoleSelectMenuBuilder()
        .setCustomId('ticketadmins_roleselect')
        .setPlaceholder('اختار الرولات الإدارية للتكتات...')
        .setMinValues(0)
        .setMaxValues(10);
      return message.reply({ components: [new ActionRowBuilder().addComponents(menu)] });
    }
  },
  {
    name: 'ticketimage',
    usage: '(أرفق صورة)',
    description: 'رفع صورة التكت',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      let attachment = message.attachments.first();
      if (!attachment) {
        await message.channel.send({ components: [baseEmbed({ description: 'أرسل الصورة مع الأمر.' })], flags: V2_FLAGS });
        const collected = await message.channel
          .awaitMessages({ filter: m => m.author.id === message.author.id && m.attachments.size > 0, max: 1, time: 60000 })
          .catch(() => null);
        if (!collected || !collected.size) return message.channel.send({ components: [errorEmbed('انتهى الوقت / مفيش صورة.')], flags: V2_FLAGS });
        attachment = collected.first().attachments.first();
      }

      const data = db.get(message.guild.id);
      data.tickets.imageUrl = attachment.url;
      db.commit(message.guild.id);
      return message.channel.send({ components: [successEmbed('تم حفظ صورة التكت.')], flags: V2_FLAGS });
    }
  }
];
