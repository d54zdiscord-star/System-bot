const { PermissionFlagsBits, ChannelType, ChannelSelectMenuBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, successEmbed, errorEmbed, usageEmbed, V2_FLAGS } = require('../../utils/embed');
const config = require('../../config');
const { LOG_TYPES } = require('../../utils/logs');

function prefixOf(guildId) {
  return db.get(guildId).prefix || config.defaultPrefix;
}

// بيتأكد إن اسم الأمر المكتوب موجود فعلاً في البوت (أو alias ليه)
// وبيرجع الاسم الحقيقي للأمر، عشان منسجلش صلاحيات على اسم غلط بالغلط زي "tiemout" بدل "timeout"
function resolveCommandName(client, cmdName) {
  const lower = cmdName.toLowerCase();
  if (client.commands.has(cmdName)) return cmdName;
  if (client.commands.has(lower)) return lower;
  if (client.aliases.has(cmdName)) return client.aliases.get(cmdName);
  if (client.aliases.has(lower)) return client.aliases.get(lower);
  return null;
}

module.exports = [
  {
    name: 'allow',
    usage: '[منشن رول/عضو] [اسم الأمر]',
    description: 'السماح لعضو أو رول باستعمال أمر',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message, args) {
      const target = message.mentions.roles.first() || message.mentions.members.first();
      const cmdNameRaw = args[args.length - 1];
      if (!target || !cmdNameRaw) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const cmdName = resolveCommandName(message.client, cmdNameRaw);
      if (!cmdName) return message.reply({ components: [errorEmbed(`مفيش أمر اسمه \`${cmdNameRaw}\`. تأكد من كتابة اسم الأمر صح.`)], flags: V2_FLAGS });

      const data = db.get(message.guild.id);
      if (!data.settings.allow[cmdName]) data.settings.allow[cmdName] = [];
      if (!data.settings.allow[cmdName].includes(target.id)) data.settings.allow[cmdName].push(target.id);

      // شيله من قائمة الممنوعين لنفس الأمر لو كان موجود - مينفعش يبقى مسموح وممنوع في نفس الوقت
      if (data.settings.deny[cmdName]) {
        data.settings.deny[cmdName] = data.settings.deny[cmdName].filter(id => id !== target.id);
      }

      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم السماح لـ ${target} باستخدام \`${cmdName}\``)], flags: V2_FLAGS });
    }
  },
  {
    name: 'deny',
    usage: '[منشن رول/عضو] [اسم الأمر]',
    description: 'منع عضو أو رول من أمر',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message, args) {
      const target = message.mentions.roles.first() || message.mentions.members.first();
      const cmdNameRaw = args[args.length - 1];
      if (!target || !cmdNameRaw) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const cmdName = resolveCommandName(message.client, cmdNameRaw);
      if (!cmdName) return message.reply({ components: [errorEmbed(`مفيش أمر اسمه \`${cmdNameRaw}\`. تأكد من كتابة اسم الأمر صح.`)], flags: V2_FLAGS });

      const data = db.get(message.guild.id);
      if (!data.settings.deny[cmdName]) data.settings.deny[cmdName] = [];
      if (!data.settings.deny[cmdName].includes(target.id)) data.settings.deny[cmdName].push(target.id);

      // شيله من قائمة المسموحين لنفس الأمر لو كان موجود - مينفعش يبقى مسموح وممنوع في نفس الوقت
      if (data.settings.allow[cmdName]) {
        data.settings.allow[cmdName] = data.settings.allow[cmdName].filter(id => id !== target.id);
      }

      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم منع ${target} من استخدام \`${cmdName}\``)], flags: V2_FLAGS });
    }
  },
  {
    name: 'list',
    usage: '',
    description: 'قائمة المسموحين والممنوعين',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const data = db.get(message.guild.id);
      const mentionFor = id => (message.guild.roles.cache.has(id) ? `<@&${id}>` : `<@${id}>`);
      const allowText = Object.entries(data.settings.allow).map(([c, ids]) => `**${c}**: ${ids.map(mentionFor).join(', ')}`).join('\n') || 'مفيش';
      const denyText = Object.entries(data.settings.deny).map(([c, ids]) => `**${c}**: ${ids.map(mentionFor).join(', ')}`).join('\n') || 'مفيش';
      return message.reply({
        components: [baseEmbed({ title: 'المسموحين والممنوعين', fields: [{ name: '<:true:1533733814105407619> مسموح', value: allowText }, { name: '<:fals:1533733827900473366> ممنوع', value: denyText }], boxed: true })], flags: V2_FLAGS
      });
    }
  },
  {
    name: 'setlog',
    aliases: [],
    usage: '',
    description: 'إنشاء كاتيجوري "لوقز السيرفر" بكل شاتات اللوقز الـ 18 (منقول حرفيًا من بوت ١) - أونرات البوت بس',
    ownerOnly: true,
    async execute(message) {
      try {
        const category = await message.guild.channels.create({
          name: 'لوقز السيرفر',
          type: ChannelType.GuildCategory,
          permissionOverwrites: [
            { id: message.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] }
          ]
        });

        const data = db.get(message.guild.id);

        for (const { name, key } of LOG_TYPES) {
          const ch = await message.guild.channels.create({
            name,
            type: ChannelType.GuildText,
            parent: category.id,
            permissionOverwrites: [
              { id: message.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] }
            ]
          });
          data.settings.logChannels[key] = ch.id;
        }

        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed('تم إنشاء كل شاتات اللوقز (18 لوق) واللوقز شغالة فعليًا دلوقتي.')], flags: V2_FLAGS });
      } catch (e) {
        console.error('[setlog]', e.message);
        return message.reply({ components: [errorEmbed('حصل خطأ وأنا بعمل شاتات اللوقز - تأكد إن البوت عنده صلاحية Manage Channels.')], flags: V2_FLAGS });
      }
    }
  },
  {
    name: 'detlog',
    aliases: [],
    usage: '',
    description: 'حذف كل شاتات اللوقز الـ 18 (منقول حرفيًا من بوت ١) - أونرات البوت بس',
    ownerOnly: true,
    async execute(message) {
      try {
        const data = db.get(message.guild.id);

        for (const { key } of LOG_TYPES) {
          const id = data.settings.logChannels[key];
          if (!id) continue;
          const ch = message.guild.channels.cache.get(id);
          if (ch) await ch.delete().catch(() => {});
          delete data.settings.logChannels[key];
        }

        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed('تم حذف كل شاتات اللوقز.')], flags: V2_FLAGS });
      } catch (e) {
        console.error('[detlog]', e.message);
        return message.reply({ components: [errorEmbed('حصل خطأ وأنا بحذف شاتات اللوقز.')], flags: V2_FLAGS });
      }
    }
  },
  {
    name: 'zajil',
    usage: '',
    description: 'اختيار شات اللوق الخاص برسايل أمر "مخفي" (يشوفه الأونرز بس)',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const menu = new ChannelSelectMenuBuilder()
        .setCustomId('zajil_channelselect')
        .setChannelTypes(ChannelType.GuildText)
        .setPlaceholder('اختار شات اللوق لأمر مخفي...');
      return message.reply({ components: [new ActionRowBuilder().addComponents(menu)] });
    }
  },
  {
    name: 'setonli',
    usage: '',
    description: 'اختيار الفويس الأونلاين (البوت يدخله فعليًا)',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const menu = new ChannelSelectMenuBuilder()
        .setCustomId('setonli_channelselect')
        .setChannelTypes(ChannelType.GuildVoice)
        .setPlaceholder('اختار الفويس الأونلاين...');
      return message.reply({ components: [new ActionRowBuilder().addComponents(menu)] });
    }
  },
  {
    name: 'editwlc',
    aliases: ['edit-wlc'],
    usage: '',
    description: 'تعديل الويلكم: رسالة + صورة + شات + شكل الرسالة + تشغيل/تعطيل + رسالة الخاص (اختيارية)',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const data = db.get(message.guild.id);
      const wlc = data.settings.welcome;
      const status = wlc.enabled ? '🟢 شغال' : '🔴 متعطل';
      const modeLabel = wlc.mode === 'text' ? 'رسالة عادية + صورة بس' : 'رسالة إمبد';

      const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('editwlc_message').setLabel('رسالة الويلكم').setEmoji('📝').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('editwlc_image').setLabel('صورة الويلكم').setEmoji('🌄').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('editwlc_channel').setLabel('شات الويلكم').setEmoji('💬').setStyle(ButtonStyle.Primary)
      );
      const row2 = new ActionRowBuilder().addComponents(
        wlc.enabled
          ? new ButtonBuilder().setCustomId('editwlc_toggle').setLabel('تعطيل الويلكم').setEmoji('⛔').setStyle(ButtonStyle.Danger)
          : new ButtonBuilder().setCustomId('editwlc_toggle').setLabel('تشغيل الويلكم').setEmoji('<:true:1533733814105407619>').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('editwlc_mode').setLabel('شكل الرسالة').setEmoji('🎛️').setStyle(ButtonStyle.Secondary)
      );
      const row3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('editwlc_dm').setLabel('رسالة الخاص (اختياري)').setEmoji('📩').setStyle(ButtonStyle.Secondary)
      );

      return message.reply({
        components: [
          baseEmbed({ title: 'إعدادات الويلكم', description: `الحالة: ${status}\nشكل الرسالة: ${modeLabel}\n\nاختار إيه اللي عايز تعدله من الأزرار تحت` }),
          row1, row2, row3
        ],
        flags: V2_FLAGS
      });
    }
  },
  {
    name: 'locomnd',
    usage: '[اسم الأمر]',
    description: 'تفعيل أو تعطيل أمر',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message, args) {
      const cmdName = args[0];
      if (!cmdName) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const data = db.get(message.guild.id);
      const idx = data.settings.disabledCommands.indexOf(cmdName);
      if (idx === -1) {
        data.settings.disabledCommands.push(cmdName);
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed(`تم تعطيل أمر \`${cmdName}\``)], flags: V2_FLAGS });
      } else {
        data.settings.disabledCommands.splice(idx, 1);
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed(`تم تفعيل أمر \`${cmdName}\``)], flags: V2_FLAGS });
      }
    }
  },
  {
    name: 'managetasks',
    usage: '[add/remove/list/toggle] [نص/رقم]',
    description: 'إدارة نظام المهام',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message, args) {
      const data = db.get(message.guild.id);
      data.settings.tasks = data.settings.tasks || [];
      const sub = args[0];

      if (sub === 'add') {
        const text = args.slice(1).join(' ');
        if (!text) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
        data.settings.tasks.push({ id: data.settings.tasks.length + 1, text, enabled: true });
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed('تم إضافة المهمة.')], flags: V2_FLAGS });
      }
      if (sub === 'remove') {
        const id = parseInt(args[1], 10);
        data.settings.tasks = data.settings.tasks.filter(t => t.id !== id);
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed('تم حذف المهمة.')], flags: V2_FLAGS });
      }
      if (sub === 'toggle') {
        const id = parseInt(args[1], 10);
        const task = data.settings.tasks.find(t => t.id === id);
        if (!task) return message.reply({ components: [errorEmbed('المهمة مش موجودة.')], flags: V2_FLAGS });
        task.enabled = !task.enabled;
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed(`المهمة دلوقتي ${task.enabled ? 'مفعلة' : 'معطلة'}.`)], flags: V2_FLAGS });
      }
      // list (default)
      const list = data.settings.tasks.map(t => `**${t.id}.** ${t.enabled ? '<:true:1533733814105407619>' : '<:fals:1533733827900473366>'} ${t.text}`).join('\n') || 'مفيش مهام.';
      return message.reply({ components: [baseEmbed({ title: 'المهام', description: list, boxed: true })], flags: V2_FLAGS });
    }
  },
  {
    name: 'block',
    usage: '[منشن العضو]',
    description: 'إعطاء بلوك',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      let role = message.guild.roles.cache.find(r => r.name === '🚫│بلوك');
      if (!role) {
        role = await message.guild.roles.create({ name: '🚫│بلوك', color: 'DarkGrey', reason: 'نظام البلوك' });
        for (const channel of message.guild.channels.cache.values()) {
          if (channel.isTextBased()) {
            channel.permissionOverwrites.edit(role, { SendMessages: false }).catch(() => {});
          }
        }
      }
      await member.roles.add(role);
      return message.reply({ components: [successEmbed(`تم إعطاء ${member} بلوك.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'unblock',
    usage: '[منشن العضو]',
    description: 'إزالة البلوك عن العضو',
    permissions: [PermissionFlagsBits.ManageRoles],
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const role = message.guild.roles.cache.find(r => r.name === '🚫│بلوك');
      if (!role || !member.roles.cache.has(role.id)) {
        return message.reply({ components: [errorEmbed('العضو ده مش متحط عليه بلوك أصلاً.')], flags: V2_FLAGS });
      }

      await member.roles.remove(role);
      return message.reply({ components: [successEmbed(`تم إزالة البلوك عن ${member}.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'blacklist',
    usage: 'on/off',
    description: 'تفعيل أو تعطيل البلاك ليست في الشات ده (تعطيل الأوامر فيه)',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message, args) {
      const sub = (args[0] || '').toLowerCase();
      if (!['on', 'off'].includes(sub)) {
        return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      }

      const data = db.get(message.guild.id);
      data.settings.blacklistChannels = data.settings.blacklistChannels || [];
      const idx = data.settings.blacklistChannels.indexOf(message.channel.id);

      if (sub === 'on') {
        if (idx === -1) data.settings.blacklistChannels.push(message.channel.id);
        db.commit(message.guild.id);
        return message.reply({ components: [successEmbed(`تم تفعيل البلاك ليست في ${message.channel} - الأوامر مش هتشتغل فيه.`)], flags: V2_FLAGS });
      }

      if (idx !== -1) data.settings.blacklistChannels.splice(idx, 1);
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`تم تعطيل البلاك ليست في ${message.channel} - الأوامر هتشتغل فيه عادي.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'dinfractions',
    usage: '[عدد] [mute/kick/ban] [مدة بالدقايق (اختياري)]',
    description: 'تعديل عقوبات العضو حسب عدد التحذيرات',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message, args) {
      const count = parseInt(args[0], 10);
      const action = args[1];
      if (!count || !['mute', 'kick', 'ban'].includes(action)) {
        return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      }
      const data = db.get(message.guild.id);
      data.settings.infractionsPunishments[count] = { action, duration: args[2] ? parseInt(args[2], 10) : null };
      db.commit(message.guild.id);
      return message.reply({ components: [successEmbed(`عند وصول العضو لـ ${count} تحذيرات هيتاخد له إجراء **${action}**.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'setsug',
    usage: '',
    category: 'اقتراحات',
    description: 'إعدادات نظام الاقتراحات',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const menu = new ChannelSelectMenuBuilder()
        .setCustomId('setsug_channelselect')
        .setChannelTypes(ChannelType.GuildText)
        .setPlaceholder('اختار شات الاقتراحات...');
      return message.reply({ components: [new ActionRowBuilder().addComponents(menu)] });
    }
  },
  {
    name: 'اقتراح',
    aliases: ['suggest'],
    usage: '[الاقتراح]',
    category: 'اقتراحات',
    description: 'إرسال اقتراح للسيرفر',
    async execute(message, args) {
      const data = db.get(message.guild.id);
      if (!data.settings.suggestions.channelId) return message.reply({ components: [errorEmbed('نظام الاقتراحات مش مفعل.')], flags: V2_FLAGS });
      const channel = message.guild.channels.cache.get(data.settings.suggestions.channelId);
      const text = args.join(' ');
      if (!channel || !text) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const sent = await channel.send({
        components: [baseEmbed({ title: `${config.emojis.suggestion} اقتراح من ${message.author.username}`, description: `-# ${text}` })], flags: V2_FLAGS
      });
      sent.react('👍').then(() => sent.react('👎'));
      return message.reply({ components: [successEmbed('تم إرسال اقتراحك.')], flags: V2_FLAGS });
    }
  }
];
