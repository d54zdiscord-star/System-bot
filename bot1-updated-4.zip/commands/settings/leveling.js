const { PermissionFlagsBits, ButtonBuilder, ButtonStyle, ActionRowBuilder, ChannelSelectMenuBuilder, ChannelType, RoleSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, successEmbed, usageEmbed, V2_FLAGS } = require('../../utils/embed');
const config = require('../../config');

function prefixOf(guildId) {
  return db.get(guildId).prefix || config.defaultPrefix;
}

module.exports = [
  {
    name: 'editlvl',
    usage: '',
    description: 'إعدادات نظام اللفلات',
    category: 'اللفلات',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const data = db.get(message.guild.id);
      const lvl = data.leveling;

      const embed = baseEmbed({
        title: 'إعدادات نظام اللفلات',
        description: 'تحكم في إعدادات نظام اللفلات:',
        fields: [
          { name: 'الحالة', value: lvl.enabled ? '<:true:1533733814105407619> مفعل' : '<:fals:1533733827900473366> معطل', inline: true },
          { name: 'روم الإشعارات', value: lvl.channelId ? `<#${lvl.channelId}>` : 'نفس الشات', inline: true },
          { name: 'رتب الشات', value: `${Object.keys(lvl.chatRoles).length}`, inline: true },
          { name: 'رتب الفويس', value: `${Object.keys(lvl.voiceRoles).length}`, inline: true }
        ],
        boxed: true
      });

      const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('lvl_toggle').setLabel(lvl.enabled ? 'إيقاف النظام' : 'تشغيل النظام').setStyle(lvl.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
        new ButtonBuilder().setCustomId('lvl_setchannel').setLabel('تحديد روم الإشعارات').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('lvl_message').setLabel('رسالة اللفل أب').setStyle(ButtonStyle.Secondary)
      );
      const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('lvl_addchatrole').setLabel('إضافة رتبة شات').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('lvl_addvoicerole').setLabel('إضافة رتبة فويس').setStyle(ButtonStyle.Primary)
      );
      const row3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('lvl_manage_xp').setLabel('تعديل XP/لفل عضو').setStyle(ButtonStyle.Secondary)
      );

      return message.reply({ components: [embed, row1, row2, row3], flags: V2_FLAGS });
    }
  }
];
