const {
  PermissionFlagsBits, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle,
  ContainerBuilder, TextDisplayBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder,
  SeparatorBuilder, SeparatorSpacingSize, ChannelSelectMenuBuilder, ChannelType
} = require('discord.js');
const db = require('../../utils/db');
const { baseEmbed, successEmbed, errorEmbed, usageEmbed, V2_FLAGS } = require('../../utils/embed');
const config = require('../../config');
const { sendDetailedLog, sendLog, mentionWithId } = require('../../utils/logs');
const { reasonSuffix, sendModDM } = require('../../utils/moderation');

async function askMsg(message, question) {
  await message.channel.send({ components: [baseEmbed({ description: question })], flags: V2_FLAGS });
  const collected = await message.channel
    .awaitMessages({ filter: m => m.author.id === message.author.id, max: 1, time: 120000 })
    .catch(() => null);
  if (!collected || !collected.size) return null;
  return collected.first();
}

async function ask(message, question) {
  const msg = await askMsg(message, question);
  return msg ? msg.content.trim() : null;
}

async function askSelect(message, question, options) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId('ann_pick')
    .setPlaceholder(question)
    .addOptions(options.slice(0, 25));
  const sent = await message.channel.send({
    components: [baseEmbed({ description: question }), new ActionRowBuilder().addComponents(menu)],
    flags: V2_FLAGS
  });
  try {
    const i = await sent.awaitMessageComponent({ filter: x => x.user.id === message.author.id, time: 60000 });
    await i.deferUpdate();
    return i.values[0];
  } catch {
    sent.edit({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS }).catch(() => {});
    return null;
  }
}

async function askChannel(message, question) {
  const menu = new ChannelSelectMenuBuilder()
    .setCustomId('ann_channel_pick')
    .setPlaceholder(question)
    .setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement);
  const sent = await message.channel.send({
    components: [baseEmbed({ description: question }), new ActionRowBuilder().addComponents(menu)],
    flags: V2_FLAGS
  });
  try {
    const i = await sent.awaitMessageComponent({ filter: x => x.user.id === message.author.id, time: 60000 });
    await i.deferUpdate();
    const picked = i.channels.first();
    if (!picked) return null;
    return message.guild.channels.fetch(picked.id).catch(() => picked);
  } catch {
    sent.edit({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS }).catch(() => {});
    return null;
  }
}

function randomId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

// بيتأكد إن الإيموجي إما إيموجي ديسكورد كستم صح <a:name:id> أو إيموجي يونيكود حقيقي واحد
function isValidEmoji(str) {
  if (!str) return false;
  if (/^<a?:\w{2,32}:\d{17,20}>$/.test(str)) return true;
  try {
    return /^\p{Extended_Pictographic}(\u200d\p{Extended_Pictographic})*$/u.test(str.trim());
  } catch {
    return false;
  }
}

function divider() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

// كونتينر V2 بدون خط جانبي ملون خالص - فاصل فوق الصورة بس، والأزرار فوق الفاصل الختامي في آخر الرسالة
function buildAnnounceEmbed(entry) {
  const container = new ContainerBuilder();

  if (entry.author) {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(entry.author));
  }
  if (entry.title) {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(entry.title));
  }
  if (entry.description) {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(entry.description));
  }
  if (entry.image) {
    container.addSeparatorComponents(divider());
    container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(entry.image)));
  }
  if (entry.footer) {
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(entry.footer));
  }

  if (entry.buttons && entry.buttons.length) {
    container.addActionRowComponents(
      new ActionRowBuilder().addComponents(entry.buttons.slice(0, 5).map(b => {
        const btn = new ButtonBuilder().setCustomId(`annbtn_${b.id}`).setLabel(b.label).setStyle(ButtonStyle.Secondary);
        if (b.emoji && isValidEmoji(b.emoji)) { try { btn.setEmoji(b.emoji); } catch {} }
        return btn;
      }))
    );
  }

  return container;
}

async function addButtonFlow(message, data, name) {
  const label = await ask(message, `ارسل اسم الزر اللي عايز تضيفه على "${name}":`);
  if (!label) return message.channel.send({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS });

  const emojiInput = await ask(message, 'ابعت إيموجي الزر (اختياري)، اكتب "تخطي" لو مفيش:');
  let emoji = (!emojiInput || emojiInput === 'تخطي' || emojiInput.toLowerCase() === 'skip') ? null : emojiInput.trim();
  if (emoji && !isValidEmoji(emoji)) {
    await message.channel.send({ components: [errorEmbed('الإيموجي ده مش صيغته صح، هيتضاف الزر من غيره.')], flags: V2_FLAGS });
    emoji = null;
  }

  const btnMessage = await ask(message, 'ارسل رسالة الزر (اللي البوت هيردها لما حد يدوس الزر):');
  if (!btnMessage) return message.channel.send({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS });

  if (!data.announceEmbeds[name]) return message.channel.send({ components: [errorEmbed('الإمبد ده اتحذف.')], flags: V2_FLAGS });
  data.announceEmbeds[name].buttons.push({ id: randomId(), label, emoji, message: btnMessage });
  db.commit(message.guild.id);
  return message.channel.send({ components: [successEmbed(`تم <:true:1533733814105407619> اتضاف زر "${label}" على "${name}"`)], flags: V2_FLAGS });
}

async function editEmbedFlow(message, data, name) {
  const fieldOptions = [
    { label: 'العنوان (Title)', value: 'title' },
    { label: 'الوصف (Description)', value: 'description' },
    { label: 'الصورة - ملف مرفق', value: 'image_file' },
    { label: 'الفوتر (Footer)', value: 'footer' },
    { label: 'المؤلف (Author)', value: 'author' }
  ];
  const fieldLabels = { title: 'العنوان الجديد', description: 'الوصف الجديد', image: 'رابط الصورة الجديد', footer: 'نص الفوتر الجديد', author: 'اسم المؤلف الجديد' };

  while (data.announceEmbeds[name]) {
    const menu = new StringSelectMenuBuilder().setCustomId('ann_editfield').setPlaceholder('اختر ما تريد تعديله').addOptions(fieldOptions);
    const btnRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ann_addbtn_inline').setLabel('إضافة زر').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('ann_delbtn_inline').setLabel('حذف زر').setStyle(ButtonStyle.Danger)
    );
    const sent = await message.channel.send({
      components: [baseEmbed({ title: `تعديل الإمبد: "${name}"` }), new ActionRowBuilder().addComponents(menu), btnRow],
      flags: V2_FLAGS
    });

    let interaction;
    try {
      interaction = await sent.awaitMessageComponent({ filter: x => x.user.id === message.author.id, time: 90000 });
    } catch {
      sent.edit({ components: [errorEmbed('انتهى وقت التعديل.')], flags: V2_FLAGS }).catch(() => {});
      return;
    }
    await interaction.deferUpdate();

    if (interaction.customId === 'ann_addbtn_inline') {
      await addButtonFlow(message, data, name);
      continue;
    }

    if (interaction.customId === 'ann_delbtn_inline') {
      const btns = data.announceEmbeds[name].buttons;
      if (!btns.length) { await message.channel.send({ components: [errorEmbed('مفيش أزرار على الإمبد ده.')], flags: V2_FLAGS }); continue; }
      const pickedId = await askSelect(message, 'اختر الزر اللي عايز تمسحه', btns.map(b => ({ label: b.label, value: b.id })));
      if (pickedId) {
        data.announceEmbeds[name].buttons = data.announceEmbeds[name].buttons.filter(b => b.id !== pickedId);
        db.commit(message.guild.id);
        await message.channel.send({ components: [successEmbed('تم حذف الزر.')], flags: V2_FLAGS });
      }
      continue;
    }

    // اختيار حقل للتعديل
    const field = interaction.values[0];

    if (field === 'image_file') {
      const msg = await askMsg(message, 'ابعت الصورة (كملف مرفق مش لينك):');
      const attachment = msg && msg.attachments.first();
      if (!attachment) { await message.channel.send({ components: [errorEmbed('محتاج ترفق صورة فعلاً.')], flags: V2_FLAGS }); continue; }
      data.announceEmbeds[name].image = attachment.url;
      db.commit(message.guild.id);
      await message.channel.send({ components: [successEmbed('تم حفظ الصورة <:true:1533733814105407619>')], flags: V2_FLAGS });
      continue;
    }

    const value = await ask(message, `ابعت ${fieldLabels[field]}:`);
    if (value === null) { await message.channel.send({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS }); continue; }
    data.announceEmbeds[name][field] = value;
    db.commit(message.guild.id);
    await message.channel.send({ components: [successEmbed('تم التعديل <:true:1533733814105407619>')], flags: V2_FLAGS });
  }
}

function prefixOf(guildId) {
  return db.get(guildId).prefix || config.defaultPrefix;
}

function parseDuration(str) {
  if (!str) return null;
  const match = str.match(/^(\d+)([smhd])$/i);
  if (!match) return null;
  const n = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  const mult = { s: 1000, m: 60000, h: 3600000, d: 86400000 }[unit];
  return n * mult;
}

module.exports = [
  {
    name: 'stickers',
    usage: '[اسم الستيكر] (أرفق صورة)',
    description: 'إضافة ستيكرز للسيرفر',
    permissions: [PermissionFlagsBits.ManageGuildExpressions],
    async execute(message, args) {
      const attachment = message.attachments.first();
      const name = args.join(' ');
      if (!attachment || !name) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      try {
        await message.guild.stickers.create({ file: attachment.url, name, tags: 'sticker' });
        return message.reply({ components: [successEmbed(`تم إضافة الستيكر **${name}**`)], flags: V2_FLAGS });
      } catch {
        return message.reply({ components: [errorEmbed('فشل إضافة الستيكر (تأكد إن الصورة PNG وأقل من 512kb).')], flags: V2_FLAGS });
      }
    }
  },
  {
    name: 'aemoji',
    usage: '[اسم الإيموجي] (أرفق صورة)',
    description: 'إضافة إيموجي للسيرفر',
    permissions: [PermissionFlagsBits.ManageGuildExpressions],
    async execute(message, args) {
      const attachment = message.attachments.first();
      const name = args.join(' ');
      if (!attachment || !name) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      try {
        const emoji = await message.guild.emojis.create({ attachment: attachment.url, name });
        return message.reply({ components: [successEmbed(`تم إضافة الإيموجي ${emoji}`)], flags: V2_FLAGS });
      } catch {
        return message.reply({ components: [errorEmbed('فشل إضافة الإيموجي.')], flags: V2_FLAGS });
      }
    }
  },
  {
    name: 'timeout',
    aliases: ['mute'],
    usage: '[منشن العضو] [المدة مثل 10m] [السبب]',
    description: 'إسكات كتابي (Timeout)',
    permissions: [PermissionFlagsBits.ModerateMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const duration = parseDuration(args[1]);
      const reason = args.slice(2).join(' ') || null;
      if (!member || !duration) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      await member.timeout(duration, reason || undefined).catch(() => {});
      const data = db.get(message.guild.id);
      data.infractions[member.id] = data.infractions[member.id] || { mutes: [], bans: [], prisons: [] };
      data.infractions[member.id].mutes.push({ reason, mod: message.author.id, date: Date.now(), duration });
      db.commit(message.guild.id);

      sendDetailedLog(message.guild, 'logmute', {
        title: '🔇 تايم',
        iconKey: 'timeout',
        executor: message.author,
        target: member.user,
        reason,
        duration: args[1],
        extraFields: [
          { name: '🔢 عدد الإسكاتات السابقة', value: `\`${(data.infractions[member.id]?.mutes || []).length}\``, inline: true }
        ]
      });

      return message.reply({ components: [successEmbed(`تم إسكات ${member} لمدة ${args[1]}${reasonSuffix(reason)}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'untimeout',
    aliases: ['unmute'],
    usage: '[منشن العضو]',
    description: 'إلغاء الإسكات الكتابي',
    permissions: [PermissionFlagsBits.ModerateMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await member.timeout(null).catch(() => {});
      sendDetailedLog(message.guild, 'logmute', {
        title: '🔊 فك تايم',
        iconKey: 'untimeout',
        executor: message.author,
        target: member.user
      });
      return message.reply({ components: [successEmbed(`تم إلغاء إسكات ${member}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'prison',
    usage: '[منشن العضو] [السبب]',
    description: 'سجن عضو (بيشيل كل رولاته ويحفظها + يمنعه يشوف الرومات، ولو خرج ودخل تاني برضو هيتسجن أوتوماتيك)',
    permissions: [PermissionFlagsBits.ModerateMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const reason = args.slice(1).join(' ') || null;
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      let role = message.guild.roles.cache.find(r => r.name === '⛓️│مسجون');
      if (!role) {
        role = await message.guild.roles.create({ name: '⛓️│مسجون', color: 'DarkerGrey' });
        for (const channel of message.guild.channels.cache.values()) {
          if (channel.isTextBased() || channel.isVoiceBased()) {
            channel.permissionOverwrites.edit(role, { ViewChannel: false }).catch(() => {});
          }
        }
      }

      const data = db.get(message.guild.id);
      // نحفظ كل الرولات اللي معاه دلوقتي (غير @everyone) عشان نرجعهاله لما يتفك سجنه
      const savedRoleIds = member.roles.cache.filter(r => r.id !== message.guild.id).map(r => r.id);
      data.prisoners[member.id] = { savedRoleIds, reason, mod: message.author.id, date: Date.now(), jailed: true };

      data.infractions[member.id] = data.infractions[member.id] || { mutes: [], bans: [], prisons: [] };
      data.infractions[member.id].prisons.push({ reason, mod: message.author.id, date: Date.now() });
      db.commit(message.guild.id);

      // نشيل كل رولاته ونحطله رول السجن بس (الرولات المدارة زي البوست بتاعت الديسكورد بترجع لوحدها من ديسكورد)
      await member.roles.set([role.id]).catch(() => {});

      sendDetailedLog(message.guild, 'logprisonunprison', {
        title: '⛓️ سجن',
        iconKey: 'prison',
        executor: message.author,
        target: member.user,
        reason,
        extraFields: [
          { name: '📋 رولات محفوظة', value: `\`${savedRoleIds.length}\` رول`, inline: true }
        ]
      });

      return message.reply({ components: [successEmbed(`تم سجن ${member} وشيل كل رولاته (محفوظة وهترجعله لما يتفك سجنه)${reasonSuffix(reason)}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'unprison',
    usage: '[منشن العضو]',
    description: 'فك سجن عضو وإرجاع رولاته اللي كانت معاه قبل السجن',
    permissions: [PermissionFlagsBits.ModerateMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const data = db.get(message.guild.id);
      const prisoner = data.prisoners[member.id];
      const role = message.guild.roles.cache.find(r => r.name === '⛓️│مسجون');

      if (role) await member.roles.remove(role).catch(() => {});

      const rolesToRestore = (prisoner?.savedRoleIds || []).filter(id => message.guild.roles.cache.has(id));
      if (rolesToRestore.length) await member.roles.add(rolesToRestore).catch(() => {});

      delete data.prisoners[member.id];
      db.commit(message.guild.id);

      sendDetailedLog(message.guild, 'logprisonunprison', {
        title: '🔓 فك سجن',
        iconKey: 'unprison',
        executor: message.author,
        target: member.user,
        extraFields: [
          { name: '📋 رولات مسترجعة', value: `\`${rolesToRestore.length}\` رول`, inline: true }
        ]
      });

      return message.reply({ components: [successEmbed(`تم فك سجن ${member} ورجعله رولاته اللي كانت معاه قبل السجن.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'vmute',
    usage: '[منشن العضو]',
    description: 'إسكات عضو من الفويس',
    permissions: [PermissionFlagsBits.MuteMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await member.voice.setMute(true).catch(() => {});
      sendDetailedLog(message.guild, 'logvoiceadmin', {
        title: '🔇 ميوت صوتي',
        iconKey: 'voice_mute',
        executor: message.author,
        target: member.user
      });
      return message.reply({ components: [successEmbed(`تم كتم ${member} صوتيًا`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'unvmute',
    usage: '[منشن العضو]',
    description: 'فك كتم صوتي',
    permissions: [PermissionFlagsBits.MuteMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await member.voice.setMute(false).catch(() => {});
      sendDetailedLog(message.guild, 'logvoiceadmin', {
        title: '🔊 فك الميوت الصوتي',
        executor: message.author,
        target: member.user
      });
      return message.reply({ components: [successEmbed(`تم فك الكتم الصوتي عن ${member}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'ban',
    usage: '[منشن العضو] [رسالة/سبب]',
    description: 'حظر العضو - أي نص بعد المنشن بيتبعت كسبب الحظر وكمان كرسالة خاصة للعضو قبل الحظر',
    permissions: [PermissionFlagsBits.BanMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const reason = args.slice(1).join(' ') || null;
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      // لو فيه رسالة/سبب مكتوب، نحاول نبعتها في الخاص للعضو قبل الحظر - ولو الخاص
      // مقفول أو فشل الإرسال لأي سبب، العملية بتكمل عادي من غير ما تتعطل
      await sendModDM(member, message.guild, reason);

      await member.ban({ reason: reason || undefined }).catch(() => {});
      const data = db.get(message.guild.id);
      data.infractions[member.id] = data.infractions[member.id] || { mutes: [], bans: [], prisons: [] };
      data.infractions[member.id].bans.push({ reason, mod: message.author.id, date: Date.now() });
      db.commit(message.guild.id);
      sendDetailedLog(message.guild, 'logbanunban', {
        title: '🔨 حظر',
        iconKey: 'ban',
        executor: message.author,
        target: member.user,
        reason,
        extraFields: [
          { name: '🔢 باندات سابقة', value: `\`${(data.infractions[member.id]?.bans || []).length}\``, inline: true }
        ],
        thumbnail: member.user.displayAvatarURL({ extension: 'png', forceStatic: true, size: 1024 })
      });
      return message.reply({ components: [successEmbed(`تم حظر ${member.user.tag}${reasonSuffix(reason)}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'unban',
    usage: '[آي دي العضو]',
    description: 'إلغاء حظر عضو',
    permissions: [PermissionFlagsBits.BanMembers],
    async execute(message, args) {
      const id = args[0];
      if (!id) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      try {
        await message.guild.members.unban(id);
        sendLog(message.guild, 'logbanunban', {
          title: '🔓 فك حظر',
          fields: [
            { name: 'العضو', value: mentionWithId(id), inline: true },
            { name: 'بواسطة', value: `<@${message.author.id}>`, inline: true }
          ]
        });
        return message.reply({ components: [successEmbed(`تم إلغاء حظر <@${id}>`)], flags: V2_FLAGS });
      } catch {
        return message.reply({ components: [errorEmbed('الآي دي غلط أو مش محظور.')], flags: V2_FLAGS });
      }
    }
  },
  {
    name: 'unbanal',
    usage: '',
    description: 'إلغاء حظر الجميع',
    permissions: [PermissionFlagsBits.Administrator],
    async execute(message) {
      const bans = await message.guild.bans.fetch();
      for (const ban of bans.values()) {
        await message.guild.members.unban(ban.user.id).catch(() => {});
      }
      sendDetailedLog(message.guild, 'logbanunban', {
        title: '🔓 فك حظر الكل',
        iconKey: 'unban_all',
        executor: message.author,
        extraFields: [
          { name: '👥 المفكوكين', value: `\`${bans.size}\``, inline: true }
        ]
      });
      return message.reply({ components: [successEmbed(`تم إلغاء حظر ${bans.size} عضو.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'allbans',
    usage: '',
    description: 'قائمة المحظورين',
    permissions: [PermissionFlagsBits.BanMembers],
    async execute(message) {
      const bans = await message.guild.bans.fetch();
      if (!bans.size) return message.reply({ components: [errorEmbed('مفيش محظورين.')], flags: V2_FLAGS });
      const list = [...bans.values()].slice(0, 30).map(b => `**${b.user.tag}**${b.reason ? ` - ${b.reason}` : ''}`).join('\n');
      return message.reply({ components: [baseEmbed({ title: `المحظورين (${bans.size})`, description: list, boxed: true })], flags: V2_FLAGS });
    }
  },
  {
    name: 'kick',
    usage: '[منشن العضو] [السبب]',
    description: 'طرد عضو',
    permissions: [PermissionFlagsBits.KickMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const reason = args.slice(1).join(' ') || null;
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      await member.kick(reason || undefined).catch(() => {});
      sendDetailedLog(message.guild, 'logkick', {
        title: '👢 طرد',
        iconKey: 'kick',
        executor: message.author,
        target: member.user,
        reason
      });
      return message.reply({ components: [successEmbed(`تم طرد ${member.user.tag}${reasonSuffix(reason)}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'setnick',
    usage: '[منشن العضو] [الاسم الجديد]',
    description: 'تغيير اسم عضو',
    permissions: [PermissionFlagsBits.ManageNicknames],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const nick = args.slice(1).join(' ');
      if (!member || !nick) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const oldName = member.nickname || member.user.username;
      await member.setNickname(nick).catch(() => {});
      sendDetailedLog(message.guild, 'lognickname', {
        title: '✏️ تغيير كنية',
        iconKey: 'nickname',
        executor: message.author,
        target: member.user,
        extraFields: [
          { name: '⬅️ القديم', value: `\`${oldName}\``, inline: true },
          { name: '➡️ الجديد', value: `\`${nick}\``, inline: true }
        ]
      });
      return message.reply({ components: [successEmbed(`تم تغيير اسم ${member} لـ **${nick}**`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'clear',
    usage: '[عدد]',
    description: 'مسح رسائل الشات',
    permissions: [PermissionFlagsBits.ManageMessages],
    async execute(message, args) {
      const count = parseInt(args[0], 10);
      if (!count || count < 1 || count > 100) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const toDelete = await message.channel.messages.fetch({ limit: count + 1 }).catch(() => null);
      await message.channel.bulkDelete(count + 1, true).catch(() => {});
      const confirm = await message.channel.send({ components: [successEmbed(`تم مسح ${count} رسالة.`)], flags: V2_FLAGS });
      setTimeout(() => confirm.delete().catch(() => {}), 4000);

      if (toDelete) {
        const logText = [...toDelete.values()]
          .reverse()
          .map(m => `[${m.createdAt.toISOString()}] ${m.author?.tag || 'unknown'}: ${m.content || '(بدون نص/مرفق)'}`)
          .join('\n');
        sendDetailedLog(message.guild, 'channelmessage', {
          title: '🧹 مسح رسائل',
          iconKey: 'bulk_delete',
          executor: message.author,
          channel: message.channel,
          extraFields: [
            { name: '📊 رسائل محذوفة', value: `\`${toDelete.size}\``, inline: true }
          ]
        }, {
          files: [{ attachment: Buffer.from(logText || 'مفيش رسائل'), name: 'deleted_messages.txt' }]
        });
      }
    }
  },
  {
    name: 'move',
    usage: '[منشن العضو] [منشن الروم الصوتي]',
    description: 'سحب عضو لروم آخر',
    permissions: [PermissionFlagsBits.MoveMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const channel = message.mentions.channels.first();
      if (!member || !channel) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });
      const fromChannel = member.voice.channel;
      await member.voice.setChannel(channel).catch(() => {});
      sendDetailedLog(message.guild, 'logvoiceadmin', {
        title: '🔄 نقل عضو',
        iconKey: 'voice_move',
        executor: message.author,
        target: member.user,
        extraFields: [
          { name: '⬅️ من', value: fromChannel ? `<#${fromChannel.id}> | \`${fromChannel.id}\`` : 'غير معروف', inline: true },
          { name: '➡️ إلى', value: `<#${channel.id}> | \`${channel.id}\``, inline: true }
        ]
      });
      return message.reply({ components: [successEmbed(`تم نقل ${member} لـ ${channel}`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'warn',
    usage: '[منشن العضو] [السبب]',
    description: 'إعطاء تحذير',
    permissions: [PermissionFlagsBits.ModerateMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const reason = args.slice(1).join(' ') || null;
      if (!member) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const data = db.get(message.guild.id);
      if (!data.warnings[member.id]) data.warnings[member.id] = [];
      data.warnings[member.id].push({ reason, mod: message.author.id, date: Date.now() });
      const count = data.warnings[member.id].length;

      const punishment = data.settings.infractionsPunishments[count];
      db.commit(message.guild.id);

      const punishmentLabels = { mute: 'تايم', kick: 'طرد', ban: 'حظر' };
      sendDetailedLog(message.guild, 'logwarns', {
        title: '⚠️ تحذير',
        iconKey: 'warn',
        executor: message.author,
        target: member.user,
        reason,
        count,
        extraFields: [
          { name: '⚡ عقوبة تلقائية', value: punishment ? `\`${punishmentLabels[punishment.action] || punishment.action}\` (${punishment.duration ? punishment.duration + ' دقيقة' : 'مفيش مدة محددة'})` : 'مفيش', inline: true }
        ]
      });

      await message.reply({ components: [successEmbed(`تم إعطاء ${member} تحذير (${count})${reasonSuffix(reason)}`)], flags: V2_FLAGS });

      if (punishment) {
        const actionLabels = { mute: 'عمل تايم لـ', kick: 'طرد', ban: 'حظر' };
        if (punishment.action === 'kick') member.kick('وصل للحد الأقصى من التحذيرات').catch(() => {});
        if (punishment.action === 'ban') member.ban({ reason: 'وصل للحد الأقصى من التحذيرات' }).catch(() => {});
        if (punishment.action === 'mute') member.timeout((punishment.duration || 10) * 60000, 'وصل للحد الأقصى من التحذيرات').catch(() => {});
        const label = actionLabels[punishment.action] || punishment.action;
        message.channel.send({ components: [successEmbed(`تم ${label} ${member} بنجاح`)], flags: V2_FLAGS });
      }
    }
  },
  {
    name: 'warnings',
    usage: '[منشن العضو]',
    description: 'قائمة تحذيرات عضو',
    permissions: [PermissionFlagsBits.ModerateMembers],
    async execute(message, args) {
      const member = message.mentions.members.first() || message.member;
      const data = db.get(message.guild.id);
      const list = data.warnings[member.id] || [];
      if (!list.length) return message.reply({ components: [errorEmbed('العضو ده معندوش تحذيرات.')], flags: V2_FLAGS });
      const text = list.map((w, i) => `**${i + 1}.**${w.reason ? ` ${w.reason} -` : ''} بواسطة <@${w.mod}> <t:${Math.floor(w.date / 1000)}:R>`).join('\n');
      return message.reply({ components: [baseEmbed({ title: `تحذيرات ${member.user.username}`, description: text, boxed: true })], flags: V2_FLAGS });
    }
  },
  {
    name: 'remove-warn',
    aliases: ['unwarn'],
    usage: '[منشن العضو] [رقم التحذير]',
    description: 'إزالة تحذير واحد بالرقم من غير ما تمس باقي التحذيرات',
    permissions: [PermissionFlagsBits.ModerateMembers],
    async execute(message, args) {
      const member = message.mentions.members.first();
      const idx = parseInt(args[1], 10) - 1;
      if (!member || isNaN(idx)) return message.reply({ components: [usageEmbed(prefixOf(message.guild.id), this)], flags: V2_FLAGS });

      const data = db.get(message.guild.id);
      const list = data.warnings[member.id] || [];
      if (!list[idx]) return message.reply({ components: [errorEmbed('رقم التحذير مش موجود.')], flags: V2_FLAGS });

      if (data.settings.onlyIssuerCanRemove && list[idx].mod !== message.author.id) {
        return message.reply({ components: [errorEmbed('بس اللي أعطى التحذير يقدر يشيله.')], flags: V2_FLAGS });
      }
      const removed = list.splice(idx, 1)[0];
      db.commit(message.guild.id);
      sendDetailedLog(message.guild, 'logwarns', {
        title: '✅ إزالة وارن',
        iconKey: 'unwarn',
        executor: message.author,
        target: member.user,
        extraFields: [
          { name: '🔢 رقم الوارن', value: `\`${idx + 1}\``, inline: true },
          ...(removed.reason ? [{ name: '📋 السبب', value: `\`${removed.reason}\``, inline: true }] : [])
        ]
      });
      return message.reply({ components: [successEmbed(`تم إزالة التحذير رقم (${idx + 1}) من ${member}، والباقي اتزحلق مكانه وترتب.`)], flags: V2_FLAGS });
    }
  },
  {
    name: 'announce-panel',
    usage: '',
    description: 'لوحة تحكم لعمل وتعديل وحفظ وإرسال إعلانات (إمبدات) جاهزة',
    permissions: [PermissionFlagsBits.ManageGuild],
    async execute(message) {
      const data = db.get(message.guild.id);
      data.announceEmbeds = data.announceEmbeds || {};

      const renderPanel = () => {
        const count = Object.keys(data.announceEmbeds).length;
        return {
          components: [
            baseEmbed({ title: 'لوحة تحكم الإعلانات', description: `عدد الإمبدات المحفوظة: ${count}` }),
            new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('ann_create').setLabel('إنشاء إمبد').setStyle(ButtonStyle.Secondary),
              new ButtonBuilder().setCustomId('ann_delete').setLabel('حذف إمبد').setStyle(ButtonStyle.Danger)
            ),
            new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('ann_edit').setLabel('تعديل إمبد').setStyle(ButtonStyle.Secondary),
              new ButtonBuilder().setCustomId('ann_addbtn').setLabel('إضافة زر').setStyle(ButtonStyle.Secondary),
              new ButtonBuilder().setCustomId('ann_send').setLabel('إرسال').setStyle(ButtonStyle.Secondary)
            )
          ],
          flags: V2_FLAGS
        };
      };

      const panelMsg = await message.channel.send(renderPanel());
      const refreshPanel = () => panelMsg.edit(renderPanel()).catch(() => {});

      const collector = panelMsg.createMessageComponentCollector({ time: 600000, idle: 300000 });
      collector.on('collect', async i => {
        if (i.user.id !== message.author.id) return i.reply({ content: 'الأمر ده مش ليك.', ephemeral: true });
        const names = Object.keys(data.announceEmbeds);

        if (i.customId === 'ann_create') {
          await i.deferUpdate();
          const name = await ask(message, 'ارسل اسم للإمبد:');
          if (!name) return message.channel.send({ components: [errorEmbed('انتهى الوقت.')], flags: V2_FLAGS });
          data.announceEmbeds[name] = { title: null, description: null, image: null, footer: null, author: null, buttons: [] };
          db.commit(message.guild.id);
          await message.channel.send({ components: [successEmbed('تم إنشاء الإيمبد')], flags: V2_FLAGS });
          return refreshPanel();
        }

        if (i.customId === 'ann_delete') {
          await i.deferUpdate();
          if (!names.length) return message.channel.send({ components: [errorEmbed('مفيش إمبدات محفوظة.')], flags: V2_FLAGS });
          const picked = await askSelect(message, 'اختر الإمبد للحذف', names.map(n => ({ label: n, value: n })));
          if (!picked) return;
          delete data.announceEmbeds[picked];
          db.commit(message.guild.id);
          await message.channel.send({ components: [successEmbed(`تم حذف الإمبد "${picked}"`)], flags: V2_FLAGS });
          return refreshPanel();
        }

        if (i.customId === 'ann_edit') {
          await i.deferUpdate();
          if (!names.length) return message.channel.send({ components: [errorEmbed('مفيش إمبدات محفوظة.')], flags: V2_FLAGS });
          const picked = await askSelect(message, 'اختر الإمبد للتعديل', names.map(n => ({ label: n, value: n })));
          if (!picked) return;
          return editEmbedFlow(message, data, picked);
        }

        if (i.customId === 'ann_addbtn') {
          await i.deferUpdate();
          if (!names.length) return message.channel.send({ components: [errorEmbed('مفيش إمبدات محفوظة.')], flags: V2_FLAGS });
          const picked = await askSelect(message, 'اختر الإمبد اللي عايز تضيفله زر', names.map(n => ({ label: n, value: n })));
          if (!picked) return;
          return addButtonFlow(message, data, picked);
        }

        if (i.customId === 'ann_send') {
          await i.deferUpdate();
          if (!names.length) return message.channel.send({ components: [errorEmbed('مفيش إمبدات محفوظة.')], flags: V2_FLAGS });
          const picked = await askSelect(message, 'اختر الإمبد للإرسال', names.map(n => ({ label: n, value: n })));
          if (!picked) return;

          const entry = data.announceEmbeds[picked];
          if (!entry.title && !entry.description && !entry.image && !entry.footer && !entry.author) {
            return message.channel.send({
              components: [errorEmbed(`الإمبد "${picked}" لسه فاضي - عدل عليه وحط عنوان أو وصف أو صورة الأول قبل ما تبعته`)],
              flags: V2_FLAGS
            });
          }

          const channel = await askChannel(message, 'اختر الشات اللي هيتبعت فيه الإمبد:');
          if (!channel) return;

          const botMember = channel.guild.members.me;
          const perms = botMember ? channel.permissionsFor(botMember) : null;
          if (perms && (!perms.has(PermissionFlagsBits.ViewChannel) || !perms.has(PermissionFlagsBits.SendMessages))) {
            return message.channel.send({
              components: [errorEmbed(`مش شايف/معنديش صلاحية إرسال في ${channel} - ضيف للبوت صلاحية "Send Messages" في الشات ده`)],
              flags: V2_FLAGS
            });
          }

          const embed = buildAnnounceEmbed(entry);

          try {
            await channel.send({ components: [embed], flags: V2_FLAGS });
          } catch (err) {
            console.error('announce-panel send error:', err);
            return message.channel.send({
              components: [errorEmbed(`مقدرتش أبعت في ${channel} - الخطأ: \`${err.message || err}\``)],
              flags: V2_FLAGS
            });
          }
          return message.channel.send({ components: [successEmbed(`تم إرسال الإمبد "${picked}" في ${channel}`)], flags: V2_FLAGS });
        }
      });
    }
  }
];
