// ─────────────────────────────────────────────────────────────────
//  utils/shopUI.js
//  دوال بناء واجهات نظام المتجر - مشتركة بين أمر shop وهاندلر التفاعلات
// ─────────────────────────────────────────────────────────────────
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder,
  MediaGalleryBuilder, MediaGalleryItemBuilder
} = require('discord.js');
const db = require('./db');
const config = require('../config');

function parseEmoji(str) {
  const m = /<(a)?:(\w+):(\d+)>/.exec(str || '');
  if (!m) return undefined;
  return { animated: !!m[1], name: m[2], id: m[3] };
}

// ─── لوحة المتجر الرئيسية (4 أزرار) ───
function buildShopPanel(guildId) {
  const data = db.get(guildId);
  const text = data.shop.embedText || '## نظام النقاط\n-# اختر من الأزرار أدناه';
  const image = data.shop.embedImage;

  const container = new ContainerBuilder();
  if (image) {
    container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(image)));
    container.addSeparatorComponents(new SeparatorBuilder());
  }
  container
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(text))
    .addSeparatorComponents(new SeparatorBuilder())
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('shop_ranks').setLabel('المتجر').setStyle(ButtonStyle.Secondary).setEmoji(parseEmoji(config.emojis.shopRanks)),
        new ButtonBuilder().setCustomId('shop_info').setLabel('معلومات').setStyle(ButtonStyle.Secondary).setEmoji(parseEmoji(config.emojis.shopInfo)),
        new ButtonBuilder().setCustomId('shop_profile').setLabel('بروفايلي').setStyle(ButtonStyle.Secondary).setEmoji(parseEmoji(config.emojis.shopProfile)),
        new ButtonBuilder().setCustomId('shop_tasks').setLabel('مهامي').setStyle(ButtonStyle.Secondary).setEmoji(parseEmoji(config.emojis.shopTasks))
      )
    );
  return container;
}

module.exports = { buildShopPanel, parseEmoji };
