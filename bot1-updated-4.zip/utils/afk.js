const db = require('./db');

/**
 * نظام الـ AFK - بيتخزن لكل سيرفر لوحده في data.afk[userId]
 * { reason, since (timestamp ms), mentions: [{ authorTag, timestamp, url }] }
 */

function setAfk(guildId, userId, reason) {
  const data = db.get(guildId);
  data.afk[userId] = { reason: reason && reason.trim() ? reason.trim() : 'AFK', since: Date.now(), mentions: [] };
  db.commit(guildId);
  return data.afk[userId];
}

function getAfk(guildId, userId) {
  const data = db.get(guildId);
  return data.afk[userId] || null;
}

function removeAfk(guildId, userId) {
  const data = db.get(guildId);
  const entry = data.afk[userId];
  if (entry) {
    delete data.afk[userId];
    db.commit(guildId);
  }
  return entry || null;
}

function addMention(guildId, targetUserId, mention) {
  const data = db.get(guildId);
  const entry = data.afk[targetUserId];
  if (!entry) return;
  entry.mentions.push(mention);
  // حد أقصى 10 مينشن عشان الرسالة ماتطولش أوي
  if (entry.mentions.length > 10) entry.mentions.shift();
  db.commit(guildId);
}

function formatDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  if (seconds < 60) return `${seconds} ثانية`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} دقيقة`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} ساعة`;
  const days = Math.floor(hours / 24);
  return `${days} يوم`;
}

module.exports = { setAfk, getAfk, removeAfk, addMention, formatDuration };
