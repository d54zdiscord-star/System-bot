// ─────────────────────────────────────────────────────────────────
//  utils/tasks.js
//  نظام المهام اليومية/الأسبوعية بتاع المتجر - منقول حرفيًا من بوت ١
//  (handler/tasksTracker.js) ومتكيف مع قاعدة بيانات بوت ٢ (ملف لكل سيرفر)
// ─────────────────────────────────────────────────────────────────
const db = require('./db');
const { baseEmbed } = require('./embed');

// ─── مفاتيح التواريخ ───
function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function weekStr() {
  const d = new Date();
  const yr = d.getFullYear();
  const wk = Math.ceil(((d - new Date(yr, 0, 1)) / 86400000 + new Date(yr, 0, 1).getDay() + 1) / 7);
  return `${yr}_W${wk}`;
}

// ─── pool المهام (نفس بوت ١ بالظبط) ───
const DAILY_POOL = [
  { id: 'd0',  text: 'أرسل **10** رسائل في أي روم',          type: 'messages',   target: 10,  points: 10,  diff: 'سهلة'   },
  { id: 'd1',  text: 'أرسل **50** رسالة في أي روم',          type: 'messages',   target: 50,  points: 25,  diff: 'متوسطة' },
  { id: 'd2',  text: 'أرسل **100** رسالة في أي روم',         type: 'messages',   target: 100, points: 50,  diff: 'صعبة'   },
  { id: 'd3',  text: 'أرسل **200** رسالة في يوم واحد',       type: 'messages',   target: 200, points: 100, diff: 'أسطورية' },
  { id: 'd4e', text: 'كن في الفويس **15** دقيقة متواصلة',    type: 'voice_mins', target: 15,  points: 10,  diff: 'سهلة'   },
  { id: 'd4',  text: 'كن في الفويس **45** دقيقة متواصلة',    type: 'voice_mins', target: 45,  points: 35,  diff: 'متوسطة' },
  { id: 'd5',  text: 'كن في الفويس **90** دقيقة متواصلة',    type: 'voice_mins', target: 90,  points: 65,  diff: 'صعبة'   },
  { id: 'd6',  text: 'كن في الفويس **3** ساعات في يوم واحد', type: 'voice_mins', target: 180, points: 120, diff: 'أسطورية' },
  { id: 'd7',  text: 'أرسل **10** صور في أي روم',            type: 'images',     target: 10,  points: 40,  diff: 'متوسطة' },
  { id: 'd8',  text: 'أرسل **20** صورة في يوم واحد',         type: 'images',     target: 20,  points: 80,  diff: 'صعبة'   },
  { id: 'd9e', text: 'ضع **5** تفاعلات على رسائل الأعضاء',   type: 'reactions',  target: 5,   points: 8,   diff: 'سهلة'   },
  { id: 'd9',  text: 'ضع **20** تفاعلاً على رسائل الأعضاء',  type: 'reactions',  target: 20,  points: 30,  diff: 'متوسطة' },
  { id: 'd10', text: 'ضع **40** تفاعلاً على رسائل الأعضاء',  type: 'reactions',  target: 40,  points: 60,  diff: 'صعبة'   },
  { id: 'd11', text: 'اكتب `/bump` في شات الأوامر مرتين',    type: 'bump',       target: 2,   points: 50,  diff: 'صعبة'   }
];

const WEEKLY_POOL = [
  { id: 'w1', text: 'أرسل **500** رسالة هذا الأسبوع',        type: 'messages',   target: 500,  points: 200, diff: 'صعبة'    },
  { id: 'w2', text: 'أرسل **1000** رسالة هذا الأسبوع',       type: 'messages',   target: 1000, points: 400, diff: 'أسطورية' },
  { id: 'w3', text: 'أرسل **2000** رسالة هذا الأسبوع',       type: 'messages',   target: 2000, points: 750, diff: 'أسطورية' },
  { id: 'w4', text: 'كن في الفويس **10** ساعات هذا الأسبوع', type: 'voice_mins', target: 600,  points: 350, diff: 'صعبة'    },
  { id: 'w5', text: 'كن في الفويس **20** ساعة هذا الأسبوع',  type: 'voice_mins', target: 1200, points: 650, diff: 'أسطورية' },
  { id: 'w6', text: 'أرسل **50** صورة هذا الأسبوع',          type: 'images',     target: 50,   points: 250, diff: 'صعبة'    },
  { id: 'w7', text: 'أرسل **100** صورة هذا الأسبوع',         type: 'images',     target: 100,  points: 500, diff: 'أسطورية' },
  { id: 'w8', text: 'ضع **100** تفاعل هذا الأسبوع',          type: 'reactions',  target: 100,  points: 150, diff: 'صعبة'    },
  { id: 'w9', text: 'ضع **200** تفاعل هذا الأسبوع',          type: 'reactions',  target: 200,  points: 300, diff: 'أسطورية' },
  { id: 'w10',text: 'اكتب `/bump` **10** مرات هذا الأسبوع',   type: 'bump',       target: 10,   points: 200, diff: 'أسطورية' }
];

const POOL_VERSION = 1;

function getDailyResetTimestamp() {
  const now = new Date();
  const reset = new Date(now);
  reset.setUTCHours(21, 0, 0, 0); // 00:00 بتوقيت UTC+3
  if (now >= reset) reset.setUTCDate(reset.getUTCDate() + 1);
  return Math.floor(reset.getTime() / 1000);
}

function getWeeklyResetTimestamp() {
  const now = new Date();
  const reset = new Date(now);
  const daysUntilSunday = (7 - now.getUTCDay()) % 7 || 7;
  reset.setUTCDate(reset.getUTCDate() + daysUntilSunday);
  reset.setUTCHours(21, 0, 0, 0);
  return Math.floor(reset.getTime() / 1000);
}

function userSlot(data, userId) {
  if (!data.tasks.users[userId]) data.tasks.users[userId] = { daily: null, weekly: null };
  return data.tasks.users[userId];
}

function generateDailyTasks(guildId, userId) {
  const data = db.get(guildId);
  if (data.tasks.enabled !== true) return [];

  const deleted = data.tasks.deletedDaily || [];
  const custom = data.tasks.customDaily || {};
  const pool2 = DAILY_POOL.filter(t => !deleted.includes(t.id)).map(t => (custom[t.id] ? { ...t, ...custom[t.id] } : t));

  const slot = userSlot(data, userId);
  const today = todayStr();

  if (slot.daily && slot.daily.date === today && slot.daily.ver === POOL_VERSION) {
    return slot.daily.tasks;
  }

  if (!pool2.length) return [];
  const pool = [...pool2].sort(() => Math.random() - 0.5).slice(0, 5);
  const tasks = pool.map(t => ({ ...t, progress: 0, done: false }));
  slot.daily = { date: today, ver: POOL_VERSION, tasks };
  db.commit(guildId);
  return tasks;
}

function generateWeeklyTasks(guildId, userId) {
  const data = db.get(guildId);
  if (data.tasks.enabled !== true) return [];

  const deleted = data.tasks.deletedWeekly || [];
  const custom = data.tasks.customWeekly || {};
  const poolW = WEEKLY_POOL.filter(t => !deleted.includes(t.id)).map(t => (custom[t.id] ? { ...t, ...custom[t.id] } : t));

  const slot = userSlot(data, userId);
  const wk = weekStr();

  if (slot.weekly && slot.weekly.week === wk && slot.weekly.ver === POOL_VERSION) {
    return slot.weekly.tasks;
  }

  if (!poolW.length) return [];
  const pool = [...poolW].sort(() => Math.random() - 0.5).slice(0, 3);
  const tasks = pool.map(t => ({ ...t, progress: 0, done: false }));
  slot.weekly = { week: wk, ver: POOL_VERSION, tasks };
  db.commit(guildId);
  return tasks;
}

async function sendTaskDM(client, guildId, userId, task, newPoints, isWeekly) {
  try {
    const user = await client.users.fetch(userId).catch(() => null);
    if (!user) return;

    const type = isWeekly ? 'الأسبوعية' : 'اليومية';
    const description =
      `**+${task.points}** نقطة\n` +
      `-# رصيدك الجديد: **${newPoints}** نقطة`;

    const container = baseEmbed({
      title: `أنجزت مهمة ${type}!`,
      description: `> ${task.text}\n\n${description}`
    });

    const { V2_FLAGS } = require('./embed');
    const sent = await user.send({ components: [container], flags: V2_FLAGS }).catch(() => null);

    if (!sent) {
      const data = db.get(guildId);
      const generalId = data.shop.generalChannelId;
      if (!generalId) return;
      const guild = client.guilds.cache.get(guildId);
      const channel = guild?.channels?.cache?.get(generalId);
      if (channel) channel.send({ content: `<@${userId}>`, components: [container], flags: V2_FLAGS }).catch(() => {});
    }
  } catch {}
}

async function updateProgress(client, guildId, userId, type, amount = 1) {
  const data = db.get(guildId);
  if (data.tasks.enabled !== true) return;

  let daily = generateDailyTasks(guildId, userId);
  let weekly = generateWeeklyTasks(guildId, userId);
  if (!daily.length && !weekly.length) return;

  let changed = false;
  for (const arr of [daily, weekly]) {
    for (const task of arr) {
      if (task.done || task.type !== type) continue;
      task.progress = Math.min((task.progress || 0) + amount, task.target);
      if (task.progress >= task.target) {
        task.done = true;
        const cur = data.points[userId] || 0;
        data.points[userId] = cur + task.points;
        sendTaskDM(client, guildId, userId, task, cur + task.points, arr === weekly);
      }
      changed = true;
    }
  }

  if (changed) db.commit(guildId);
}

module.exports = {
  DAILY_POOL,
  WEEKLY_POOL,
  POOL_VERSION,
  generateDailyTasks,
  generateWeeklyTasks,
  updateProgress,
  getDailyResetTimestamp,
  getWeeklyResetTimestamp
};
