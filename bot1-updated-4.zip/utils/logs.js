// نظام اللوقز الكامل - مطوّر بمعلومات إضافية (وقت، ID، تفاصيل)
const db = require('./db');
const { baseEmbed, V2_FLAGS } = require('./embed');

// الأنواع + لوق الإيموجي/ستيكرز الموحّد + لوق التحذيرات الإدارية
const LOG_TYPES = [
  { name: 'log-messages', key: 'channelmessage' },
  { name: 'log-pic', key: 'logpic' },
  { name: 'log-channels', key: 'logchannels' },
  { name: 'log-nickname', key: 'lognickname' },
  { name: 'join-leave', key: 'logjoinleave' },
  { name: 'log-links', key: 'loglinks' },
  { name: 'log-bots', key: 'logbots' },
  { name: 'log-roles', key: 'logroles' },
  { name: 'log-ban-unban', key: 'logbanunban' },
  { name: 'log-kick', key: 'logkick' },
  { name: 'stickers-emojis', key: 'logemoji' },
  { name: 'log-prison-unprison', key: 'logprisonunprison' },
  { name: 'log-warns', key: 'logwarns' },
  { name: 'log-staffwarns', key: 'logstaffwarns' },
  { name: 'log-tmute-untmute', key: 'logmute' },
  { name: 'log-voice', key: 'logvoice' },
  { name: 'log-voice-admin', key: 'logvoiceadmin' },
  { name: 'log-tempvoice', key: 'logtempvoice' }
];

function getLogChannel(guild, key) {
  const data = db.get(guild.id);
  const id = data.settings.logChannels[key];
  if (!id) return null;
  return guild.channels.cache.get(id) || null;
}

async function sendLog(guild, key, payload = {}, extra = {}) {
  const channel = getLogChannel(guild, key);
  if (!channel) return null;
  try {
    const { components: extraComponents, ...rest } = extra;
    const components = [baseEmbed(payload), ...(extraComponents || [])];
    return await channel.send({
      components,
      flags: V2_FLAGS,
      allowedMentions: { parse: [] },
      ...rest
    });
  } catch {
    return null;
  }
}

function buildLogFields(options = {}) {
  const fields = [];
  const now = Math.floor(Date.now() / 1000);

  fields.push({ name: '⏰ الوقت', value: `<t:${now}:F> (<t:${now}:R>)`, inline: true });

  if (options.executor) {
    fields.push({ 
      name: '🛡️ المنفذ', 
      value: `<@${options.executor.id}> | \`${options.executor.id}\`
${options.executor.tag || ''}`, 
      inline: true 
    });
  }

  if (options.target) {
    const t = options.target;
    fields.push({ 
      name: '👤 الهدف', 
      value: `<@${t.id}> | \`${t.id}\`
${t.tag || t.username || ''}`, 
      inline: true 
    });
  }

  if (options.channel) {
    fields.push({ 
      name: '📢 الروم', 
      value: `<#${options.channel.id}> | \`${options.channel.id}\``, 
      inline: true 
    });
  }

  if (options.reason) {
    fields.push({ name: '📋 السبب', value: `\`${options.reason}\``, inline: true });
  }

  if (options.duration) {
    fields.push({ name: '⏳ المدة', value: `\`${options.duration}\``, inline: true });
  }

  if (options.count !== undefined) {
    fields.push({ name: '🔢 الرقم', value: `\`${options.count}\``, inline: true });
  }

  if (options.content) {
    fields.push({ 
      name: '📝 المحتوى', 
      value: '```' + (options.content.slice(0, 900)) + '```' 
    });
  }

  if (options.oldValue || options.newValue) {
    if (options.oldValue) {
      fields.push({ name: '📤 القديم', value: '```' + options.oldValue.slice(0, 400) + '```' });
    }
    if (options.newValue) {
      fields.push({ name: '📥 الجديد', value: '```' + options.newValue.slice(0, 400) + '```' });
    }
  }

  if (options.extraFields && Array.isArray(options.extraFields)) {
    fields.push(...options.extraFields);
  }

  return fields;
}

async function sendDetailedLog(guild, key, options = {}) {
  const payload = {
    title: options.title,
    description: options.description,
    thumbnail: options.thumbnail,
    image: options.image,
    color: options.color,
    fields: buildLogFields(options)
  };

  let extra = options.extra || {};
  return sendLog(guild, key, payload, extra);
}

async function getAuditExecutor(guild, auditType, targetId) {
  try {
    const logs = await guild.fetchAuditLogs({ limit: 5, type: auditType });
    const entry = targetId
      ? logs.entries.find(e => e.target?.id === targetId)
      : logs.entries.first();
    return entry?.executor || null;
  } catch {
    return null;
  }
}

function markJoinAndCheckRejoin(guild, userId) {
  const data = db.get(guild.id);
  data.settings.everJoined = data.settings.everJoined || [];
  const rejoined = data.settings.everJoined.includes(userId);
  if (!rejoined) data.settings.everJoined.push(userId);
  db.commit(guild.id);
  return rejoined;
}

function saveInviter(guild, userId, inviterId, inviteCode) {
  const data = db.get(guild.id);
  data.settings.memberInviters = data.settings.memberInviters || {};
  data.settings.memberInviters[userId] = inviterId ? { inviterId, inviteCode: inviteCode || null } : null;
  db.commit(guild.id);
}

function getInviter(guild, userId) {
  const data = db.get(guild.id);
  return data.settings.memberInviters?.[userId] || null;
}

function mentionWithId(idOrEntity) {
  const id = typeof idOrEntity === 'string' ? idOrEntity : idOrEntity.id;
  return `<@${id}> | \`${id}\``;
}

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

function buildJoinButtons(userId, isJailed = false, isTimedOut = false) {
  const row = new ActionRowBuilder();
  row.addComponents(
    new ButtonBuilder().setCustomId(`joinlog_id_${userId}`).setLabel('آيدي العضو').setEmoji('🆔').setStyle(ButtonStyle.Secondary)
  );
  if (isJailed) {
    row.addComponents(new ButtonBuilder().setCustomId(`joinlog_unprison_${userId}`).setLabel('فك سجن').setEmoji('🔓').setStyle(ButtonStyle.Primary));
  } else {
    row.addComponents(new ButtonBuilder().setCustomId(`joinlog_prison_${userId}`).setLabel('سجن').setEmoji('⛓️').setStyle(ButtonStyle.Primary));
  }
  if (isTimedOut) {
    row.addComponents(new ButtonBuilder().setCustomId(`joinlog_untimeout_${userId}`).setLabel('فك تايم').setEmoji('🔊').setStyle(ButtonStyle.Secondary));
  } else {
    row.addComponents(new ButtonBuilder().setCustomId(`joinlog_timeout_${userId}`).setLabel('تايم').setEmoji('🔇').setStyle(ButtonStyle.Secondary));
  }
  row.addComponents(
    new ButtonBuilder().setCustomId(`joinlog_kick_${userId}`).setLabel('طرد').setEmoji('👢').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`joinlog_ban_${userId}`).setLabel('حظر').setEmoji('🔨').setStyle(ButtonStyle.Danger)
  );
  return row;
}

function buildLeaveButtons(userId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`joinlog_id_${userId}`).setLabel('آيدي العضو').setEmoji('🆔').setStyle(ButtonStyle.Secondary)
  );
}

module.exports = {
  LOG_TYPES,
  getLogChannel,
  sendLog,
  sendDetailedLog,
  buildLogFields,
  getAuditExecutor,
  markJoinAndCheckRejoin,
  saveInviter,
  getInviter,
  buildJoinButtons,
  buildLeaveButtons,
  mentionWithId
};
