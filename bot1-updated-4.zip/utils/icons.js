const { createCanvas, loadImage } = require('@napi-rs/canvas');
const fs = require('fs');
const path = require('path');

const ICONS_DIR = path.join(__dirname, '..', 'assets', 'icons');

const ICON_MAP = {
  message_delete: 'trash-2',
  attachment_delete: 'trash-2',
  message_edit: 'pencil',
  bulk_delete: 'eraser',
  channel_create: 'folder-plus',
  channel_delete: 'folder-minus',
  channel_update: 'folder-cog',
  emoji_create: 'smile-plus',
  emoji_delete: 'smile-minus',
  sticker_create: 'sticker',
  sticker_delete: 'sticker',
  steal_emoji: 'download',
  role_create: 'shield-plus',
  role_delete: 'shield-minus',
  role_update: 'shield-cog',
  role_add: 'user-plus',
  role_remove: 'user-minus',
  ban: 'rocket',
  unban: 'circle-check',
  kick: 'rocket',
  unban_all: 'users',
  prison: 'lock',
  unprison: 'unlock',
  timeout: 'timer-off',
  untimeout: 'timer',
  join: 'user-check',
  leave: 'user-minus',
  voice_join: 'mic',
  voice_leave: 'mic-off',
  voice_move: 'arrow-left-right',
  voice_disconnect: 'phone-off',
  voice_mute: 'volume-x',
  voice_unmute: 'volume-2',
  voice_deafen: 'headphones-off',
  voice_undeafen: 'headphones',
  screen_share: 'monitor',
  camera: 'video',
  warn: 'alert-triangle',
  unwarn: 'check-circle',
  bot_add: 'bot',
  bot_leave: 'bot-off',
  nickname: 'tag',
  staffwarn: 'shield-alert',
  staffwarn_remove: 'shield-check',
};

const cache = new Map();

async function renderIcon(iconKey, size = 64, color = '#ffffff') {
  const svgName = ICON_MAP[iconKey];
  if (!svgName) return null;

  const cacheKey = `${iconKey}_${size}_${color}`;
  if (cache.has(cacheKey)) return cache.get(cacheKey);

  const svgPath = path.join(ICONS_DIR, `${svgName}.svg`);
  if (!fs.existsSync(svgPath)) return null;

  try {
    let svgContent = fs.readFileSync(svgPath, 'utf-8');
    // Replace stroke color
    svgContent = svgContent.replace(/stroke="currentColor"/g, `stroke="${color}"`);
    svgContent = svgContent.replace(/stroke="[^"]*"/g, `stroke="${color}"`);

    const dataUrl = `data:image/svg+xml;base64,${Buffer.from(svgContent).toString('base64')}`;
    const image = await loadImage(dataUrl);

    const canvas = createCanvas(size, size);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(image, 0, 0, size, size);

    const buffer = canvas.toBuffer('image/png');
    cache.set(cacheKey, buffer);
    return buffer;
  } catch (e) {
    console.error(`[Icon] Failed to render ${iconKey}:`, e.message);
    return null;
  }
}

async function getIconAttachment(iconKey, size = 64, color = '#ffffff') {
  const buffer = await renderIcon(iconKey, size, color);
  if (!buffer) return null;
  const { AttachmentBuilder } = require('discord.js');
  return new AttachmentBuilder(buffer, { name: `${iconKey}.png` });
}

function getIconUrl(iconKey) {
  return `attachment://${iconKey}.png`;
}

module.exports = { renderIcon, getIconAttachment, getIconUrl, ICON_MAP };
