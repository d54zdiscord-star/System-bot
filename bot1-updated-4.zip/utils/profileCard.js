// ─────────────────────────────────────────────────────────────────
//  utils/profileCard.js
//  رسم كارت البروفايل (بنر + أفاتار + إحصائيات + About Me + شبكة بوستات)
//  منقول حرفيًا من بوت ١ (Commands/Puplic/profile.js -> buildCanvas)
//  ومتكيف مع @napi-rs/canvas + utils/profileDB
// ─────────────────────────────────────────────────────────────────
const fs = require('fs');
const path = require('path');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { fontFamily } = require('./fonts');
const { loadAvatar, roundRect } = require('./cards');
const profileDB = require('./profileDB');

const POSTS_DIR = path.join(__dirname, '..', 'data', 'profiles', 'posts');
const BANNERS_DIR = path.join(__dirname, '..', 'data', 'profiles', 'banners');
fs.mkdirSync(POSTS_DIR, { recursive: true });
fs.mkdirSync(BANNERS_DIR, { recursive: true });

async function buildProfileCanvas(client, targetId, page = 0) {
  const profile = profileDB.get(targetId);
  const user = await client.users.fetch(targetId).catch(() => null);
  if (!user) return null;

  const F = fontFamily('Regular');
  const FB = fontFamily('Bold');

  const _bgBase = profile.bg || '#1a1a2e';
  const _accent = profile.accent || '#F1C40F';
  const _banner = profile.bannerFile;

  const W = 900, H = 1000;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // خلفية متدرجة
  const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
  bgGrad.addColorStop(0, _bgBase);
  bgGrad.addColorStop(1, '#0d0d0d');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  // بنر مخصص أو الديسكورد أو تدرج افتراضي
  let bannerDrawn = false;
  if (_banner && fs.existsSync(_banner)) {
    try {
      const bnrImg = await loadImage(_banner);
      ctx.save();
      ctx.beginPath(); ctx.rect(0, 0, W, 260); ctx.clip();
      const sc = Math.max(W / bnrImg.width, 260 / bnrImg.height);
      ctx.drawImage(bnrImg, (W - bnrImg.width * sc) / 2, (260 - bnrImg.height * sc) / 2, bnrImg.width * sc, bnrImg.height * sc);
      ctx.restore();
      bannerDrawn = true;
    } catch {}
  }
  if (!bannerDrawn) {
    try {
      const fetchedUser = await client.users.fetch(targetId, { force: true });
      const bannerUrl = fetchedUser.bannerURL({ size: 1024 });
      if (bannerUrl) {
        const banner = await loadAvatar(bannerUrl);
        if (banner) {
          ctx.save();
          ctx.beginPath(); ctx.rect(0, 0, W, 260); ctx.clip();
          ctx.drawImage(banner, 0, 0, W, 260);
          ctx.restore();
          bannerDrawn = true;
        }
      }
    } catch {}
  }
  if (!bannerDrawn) {
    const bnrGrad = ctx.createLinearGradient(0, 0, W, 260);
    bnrGrad.addColorStop(0, _bgBase + 'dd');
    bnrGrad.addColorStop(1, '#0d0d0d');
    ctx.fillStyle = bnrGrad;
    ctx.fillRect(0, 0, W, 260);
  }

  // تدرج أسفل البانر
  const grad = ctx.createLinearGradient(0, 180, 0, 260);
  grad.addColorStop(0, 'rgba(17,17,17,0)');
  grad.addColorStop(1, 'rgba(17,17,17,1)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 180, W, 80);

  // أفاتار
  try {
    const avatarUrl = user.displayAvatarURL({ extension: 'png', size: 256 });
    const avatarImg = await loadAvatar(avatarUrl);
    if (avatarImg) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(100, 230, 80, 0, Math.PI * 2);
      ctx.strokeStyle = '#111111';
      ctx.lineWidth = 6;
      ctx.stroke();
      ctx.clip();
      ctx.drawImage(avatarImg, 20, 150, 160, 160);
      ctx.restore();
    }
  } catch {}

  // اسم
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold 32px "${FB}"`;
  ctx.textAlign = 'left';
  ctx.fillText(user.username, 200, 265);

  // رقم الصفحة
  ctx.fillStyle = '#666666';
  ctx.font = `14px "${F}"`;
  ctx.textAlign = 'right';
  ctx.fillText(`Page ${page + 1}/2`, W - 20, 265);
  ctx.textAlign = 'left';

  // خط فاصل
  ctx.strokeStyle = '#2a2a2a';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(20, 310);
  ctx.lineTo(W - 20, 310);
  ctx.stroke();

  // إحصائيات
  const stats = [
    { label: 'Posts', value: profile.posts.length, color: '#ffffff' },
    { label: 'Following', value: profile.following.length, color: '#aaaaaa' },
    { label: 'Followers', value: profile.followers.length, color: '#aaaaaa' }
  ];
  const statsY = 325;
  const bW = (W - 60) / 3;
  stats.forEach((s, i) => {
    const x = 20 + i * (bW + 10);
    ctx.fillStyle = '#1a1a1a';
    roundRect(ctx, x, statsY, bW, 65, 10);
    ctx.fill();
    ctx.fillStyle = s.color;
    ctx.font = `bold 24px "${FB}"`;
    ctx.textAlign = 'center';
    ctx.fillText(s.value.toString(), x + bW / 2, statsY + 28);
    ctx.fillStyle = '#666666';
    ctx.font = `13px "${F}"`;
    ctx.fillText(s.label, x + bW / 2, statsY + 50);
    ctx.textAlign = 'left';
  });

  // About Me
  const _bio = profile.bio;
  const _insta = profile.insta;
  const _tiktok = profile.tiktok;

  if (_bio || _insta || _tiktok) {
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    roundRect(ctx, 20, 400, W - 40, _bio ? 85 : 42, 10);
    ctx.fill();

    if (_bio) {
      ctx.fillStyle = _accent;
      ctx.fillRect(20, 404, 4, 20);
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold 15px "${FB}"`;
      ctx.fillText('ABOUT ME', 30, 420);
      ctx.fillStyle = '#aaaaaa';
      ctx.font = `13px "${F}"`;
      ctx.fillText(_bio.slice(0, 100), 26, 444);
    }

    let sx = 26, sy = _bio ? 466 : 420;
    if (_insta) {
      ctx.fillStyle = '#aaaaaa';
      ctx.font = `12px "${F}"`;
      ctx.fillText('📸 @' + _insta, sx, sy);
      sx += ctx.measureText('📸 @' + _insta).width + 18;
    }
    if (_tiktok) {
      ctx.fillStyle = '#aaaaaa';
      ctx.font = `12px "${F}"`;
      ctx.fillText('🎵 @' + _tiktok, sx, sy);
    }
  }

  // شبكة البوستات 3×2
  const cellSize = 260;
  const cellGap = 15;
  const gridStartX = 20;
  const gridStartY = (_bio || _insta || _tiktok) ? 500 : 410;
  const offset = page * 6;

  for (let i = 0; i < 6; i++) {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const x = gridStartX + col * (cellSize + cellGap);
    const y = gridStartY + row * (cellSize + cellGap);

    ctx.fillStyle = '#1a1a1a';
    roundRect(ctx, x, y, cellSize, cellSize, 10);
    ctx.fill();

    const post = profile.posts[offset + i];
    if (post) {
      const postPath = path.join(POSTS_DIR, post.file);
      if (fs.existsSync(postPath)) {
        try {
          const img = await loadImage(postPath);
          ctx.save();
          roundRect(ctx, x, y, cellSize, cellSize, 10);
          ctx.clip();
          const scale = Math.max(cellSize / img.width, cellSize / img.height);
          const sw = img.width * scale;
          const sh = img.height * scale;
          const sx2 = x - (sw - cellSize) / 2;
          const sy2 = y - (sh - cellSize) / 2;
          ctx.drawImage(img, sx2, sy2, sw, sh);
          ctx.restore();
        } catch (e) {
          console.error('[profile] post load error:', e.message);
        }
      }

      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      roundRect(ctx, x + 8, y + 10, 48, 24, 6);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold 12px "${FB}"`;
      ctx.textAlign = 'center';
      ctx.fillText(`#${offset + i + 1}`, x + 32, y + 26);
      ctx.textAlign = 'left';

      ctx.fillStyle = 'rgba(0,0,0,0.7)';
      roundRect(ctx, x + 8, y + cellSize - 34, 68, 26, 7);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold 13px "${FB}"`;
      ctx.fillText(`${post?.likes?.length || 0}`, x + 16, y + cellSize - 15);
    } else {
      ctx.fillStyle = '#2a2a2a';
      ctx.font = `bold 48px "${FB}"`;
      ctx.textAlign = 'center';
      ctx.fillText('+', x + cellSize / 2, y + cellSize / 2 + 17);
      ctx.textAlign = 'left';
    }
  }

  return canvas.toBuffer('image/png');
}

// ─── أزرار البروفايل (نفس الأزرار لصاحب البروفايل والمشاهد - الفرق بالصلاحيات وقت التنفيذ) ───
function buildOwnerButtons(targetId, page = 0) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`pf_settings_${targetId}`).setLabel('الإعدادات').setEmoji('1477958532325314671').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`pf_show_${targetId}_${page}`).setLabel('عرض').setEmoji('1476252979228053677').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`pf_follow_${targetId}`).setLabel('متابعة').setEmoji('1461768625726816400').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`pf_like_${targetId}`).setLabel('لايك').setEmoji('1461768577546981437').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`pf_followers_${targetId}`).setLabel('المتابعين').setEmoji('1467668590357385348').setStyle(ButtonStyle.Secondary)
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`pf_prevpage_${targetId}_${page}`).setEmoji('<:emoji_39:1478303572197380240>').setStyle(ButtonStyle.Secondary).setDisabled(page === 0),
      new ButtonBuilder().setCustomId(`pf_nextpage_${targetId}_${page}`).setEmoji('<:emoji_40:1478303577377341461>').setStyle(ButtonStyle.Secondary).setDisabled(page === 1)
    )
  ];
}
const buildViewButtons = buildOwnerButtons;

module.exports = { buildProfileCanvas, buildOwnerButtons, buildViewButtons, POSTS_DIR, BANNERS_DIR };
