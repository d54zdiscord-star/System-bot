// ─────────────────────────────────────────────────────────────────
//  utils/profileDB.js
//  تخزين بيانات نظام البروفايل (بوستات/متابعين/بايو..) - منقول من
//  فكرة dbCache بتاع بوت ١: تخزين عالمي لكل يوزر (مش لكل سيرفر لوحده)
// ─────────────────────────────────────────────────────────────────
const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '..', 'data', 'profiles.json');

function loadAll() {
  try {
    if (!fs.existsSync(FILE)) return {};
    return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    return {};
  }
}

let cache = loadAll();

function defaultProfile() {
  return {
    posts: [],       // [{ file, likes: [userId] }]
    followers: [],   // [userId]
    following: [],   // [userId]
    bio: '',
    insta: '',
    tiktok: '',
    bg: '#1a1a2e',
    accent: '#F1C40F',
    bannerFile: null
  };
}

function get(userId) {
  if (!cache[userId]) cache[userId] = defaultProfile();
  // لو ملف قديم ناقص حقول جديدة
  cache[userId] = { ...defaultProfile(), ...cache[userId] };
  return cache[userId];
}

function commit() {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(cache, null, 2));
}

module.exports = { get, commit };
