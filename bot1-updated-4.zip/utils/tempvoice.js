const { button, row, ButtonStyle } = require('./components');
const db = require('./db');

function interfacePanelRows() {
  // ديسكورد بيسمح بحد أقصى 5 Action Rows لكل رسالة - كانت الدالة دي بترجع 10 صف
  // وده كان بيخلي الإرسال يفشل بالكامل (رسالة تحكم التمب ما كانتش بتتبعت أبدًا).
  // اتجمعوا الأزرار في 5 صفوف بحد أقصى 5 أزرار في كل صف عشان نفضل جوه الحد المسموح.
  return [
    row(
      button('tv_name', 'الاسم', ButtonStyle.Secondary, '🆔'),
      button('tv_limit', 'الحد', ButtonStyle.Secondary, '👥'),
      button('tv_privacy', 'الخصوصية', ButtonStyle.Secondary, '🛡️'),
      button('tv_trust', 'ثقة', ButtonStyle.Success, '✅'),
      button('tv_untrust', 'إزالة ثقة', ButtonStyle.Danger, '🚫')
    ),
    row(
      button('tv_invite', 'دعوة', ButtonStyle.Secondary, '📞'),
      button('tv_kick', 'طرد', ButtonStyle.Danger, '📵'),
      button('tv_block', 'حظر', ButtonStyle.Danger, '⛔'),
      button('tv_unblock', 'فك الحظر', ButtonStyle.Success, '♻️')
    ),
    row(
      button('tv_microphone', 'المايك', ButtonStyle.Secondary, '🎙️'),
      button('tv_claim', 'استلام', ButtonStyle.Primary, '👑')
    ),
    row(
      button('tv_transfer', 'نقل الملكية', ButtonStyle.Secondary, '🔁'),
      button('tv_info', 'ℹ️', ButtonStyle.Secondary)
    )
  ];
}

/** يرجع الروم اللي العضو مالكها حاليًا (لو موجود) */
function getOwnedRoom(guildId, userId) {
  const data = db.get(guildId);
  for (const [channelId, room] of Object.entries(data.tempVoice.rooms)) {
    if (room.ownerId === userId) return { channelId, room };
  }
  return null;
}

/** يرجع الروم اللي العضو متصل بيه حاليًا لو كانت من رومات التمب فويس */
function getCurrentRoom(guildId, member) {
  const data = db.get(guildId);
  const channelId = member.voice.channelId;
  if (channelId && data.tempVoice.rooms[channelId]) {
    return { channelId, room: data.tempVoice.rooms[channelId] };
  }
  return null;
}

module.exports = { interfacePanelRows, getOwnedRoom, getCurrentRoom };
