// ─────────────────────────────────────────────────────────────────
//  utils/ticketTranscript.js
//  توليد ترانسكريبت HTML لمحادثة التكت وقت القفل - منقول حرفيًا من بوت ١
//  (handler/ticket.js -> generateTranscriptHTML) بس بنستخدم fetch
//  المدمجة في Node بدل https.get لتنزيل الصور base64
// ─────────────────────────────────────────────────────────────────

async function downloadAsBase64(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(res.status);
    const contentType = res.headers.get('content-type') || 'image/png';
    const buf = Buffer.from(await res.arrayBuffer());
    return `data:${contentType};base64,${buf.toString('base64')}`;
  } catch {
    return 'https://cdn.discordapp.com/embed/avatars/0.png';
  }
}

// ─── يبني مصفوفة رسائل جاهزة للترانسكريبت من روم التكت ───
async function buildTranscriptMessages(channel) {
  const messages = await channel.messages.fetch({ limit: 100 });
  const transcript = [];

  for (const msg of [...messages.values()].reverse()) {
    const avatarBase64 = await downloadAsBase64(msg.author.displayAvatarURL({ extension: 'png', size: 128 }));
    let content = msg.content || '';

    for (const m of (content.match(/<@!?(\d+)>/g) || [])) {
      const uid = m.match(/\d+/)[0];
      try {
        const u = await channel.guild.members.fetch(uid);
        content = content.replace(m, `@${u.user.username}`);
      } catch {
        content = content.replace(m, '@مستخدم');
      }
    }
    for (const m of (content.match(/<@&(\d+)>/g) || [])) {
      const r = channel.guild.roles.cache.get(m.match(/\d+/)[0]);
      content = content.replace(m, r ? `@${r.name}` : '@رول');
    }
    for (const m of (content.match(/<#(\d+)>/g) || [])) {
      const c = channel.guild.channels.cache.get(m.match(/\d+/)[0]);
      content = content.replace(m, c ? `#${c.name}` : '#قناة');
    }

    const msgData = {
      author: msg.author.username,
      authorId: msg.author.id,
      avatar: avatarBase64,
      content,
      timestamp: msg.createdTimestamp,
      attachments: []
    };

    for (const att of msg.attachments.values()) {
      const isImage = att.contentType?.startsWith('image/');
      msgData.attachments.push({
        url: att.url,
        name: att.name,
        isImage,
        proxyUrl: isImage ? await downloadAsBase64(att.proxyURL || att.url) : null
      });
    }

    transcript.push(msgData);
  }

  return transcript;
}

// ─── يبني ملف HTML الترانسكريبت (نفس تصميم بوت ١ بالظبط) ───
function generateTranscriptHTML(messages, ticketInfo, channelName) {
  const esc = t => (!t ? '' : t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'));
  const fmtTime = ts => {
    const d = new Date(ts);
    const time = d.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit', hour12: true });
    const today = new Date();
    const yest = new Date(today);
    yest.setDate(yest.getDate() - 1);
    if (d.toDateString() === today.toDateString()) return `اليوم ${time}`;
    if (d.toDateString() === yest.toDateString()) return `أمس ${time}`;
    return d.toLocaleDateString('ar-SA') + ' ' + time;
  };

  let html = `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>${channelName}</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Segoe UI',sans-serif;background:#313338;color:#dbdee1}
.header{background:#313338;padding:12px 16px;border-bottom:1px solid #26282c;position:sticky;top:0;z-index:100}
.channel-name{color:#f2f3f5;font-size:16px;font-weight:600}.channel-topic{color:#b5bac1;font-size:13px;margin-top:4px}
.messages{padding:16px}.message-group{display:flex;padding:4px 0;margin-bottom:16px}
.avatar{width:40px;height:40px;border-radius:50%;margin-left:16px;flex-shrink:0}
.username{color:#f2f3f5;font-weight:500;margin-left:8px}.timestamp{color:#949ba4;font-size:12px}
.message-text{color:#dbdee1;word-wrap:break-word;white-space:pre-wrap;font-size:15px;line-height:1.4}
.attachment img{max-width:400px;border-radius:8px;margin-top:8px}
.divider{height:1px;background:rgba(79,84,92,.48);margin:16px 0;text-align:center}
.divider span{background:#313338;padding:2px 8px;font-size:12px;color:#949ba4}</style></head>
<body><div class="header"><div class="channel-name">#${esc(channelName)}</div>
<div class="channel-topic">نوع التذكرة: ${esc(ticketInfo.type)} | تاريخ الإنشاء: ${fmtTime(ticketInfo.createdAt || Date.now())}</div></div>
<div class="messages">`;

  let lastDate = null;
  messages.forEach(msg => {
    const d = new Date(msg.timestamp).toDateString();
    if (d !== lastDate) {
      html += `<div class="divider"><span>${new Date(msg.timestamp).toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' })}</span></div>`;
      lastDate = d;
    }
    html += `<div class="message-group"><img src="${msg.avatar}" class="avatar"><div>
<div style="display:flex;align-items:center;margin-bottom:2px"><span class="username">${esc(msg.author)}</span><span class="timestamp">${fmtTime(msg.timestamp)}</span></div>`;
    if (msg.content) {
      const c = esc(msg.content).replace(/@(\S+)/g, '<span style="color:#c9d1ff;background:rgba(88,101,242,.3);padding:0 2px;border-radius:3px">@$1</span>');
      html += `<div class="message-text">${c}</div>`;
    }
    (msg.attachments || []).forEach(att => {
      if (att.isImage && att.proxyUrl) html += `<div class="attachment"><img src="${att.proxyUrl}"></div>`;
      else html += `<div style="margin-top:8px"><a href="${att.url}" style="color:#00a8fc">${esc(att.name)}</a></div>`;
    });
    html += `</div></div>`;
  });
  html += `</div></body></html>`;
  return html;
}

module.exports = { buildTranscriptMessages, generateTranscriptHTML };
