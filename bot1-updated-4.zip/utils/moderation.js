const { baseEmbed, V2_FLAGS } = require('./embed');

/**
 * بيرجع نص السبب جاهز للإضافة في رسالة التأكيد - لو مفيش سبب بيرجع
 * سترنج فاضي (يعني الرسالة تفضل مجرد تأكيد تنفيذ من غير أي ذكر لسبب).
 * لو فيه سبب، بيرجعه بالشكل: " - السبب: xxx"
 */
function reasonSuffix(reason, label = 'السبب') {
  return reason ? ` - ${label}: ${reason}` : '';
}

/**
 * بيحاول يبعت رسالة خاصة (DM) لعضو - مصمم عشان يتستخدم في أي أمر إداري
 * محتاج يبلغ العضو برسالة (زي Ban دلوقتي، وأي أمر تاني مستقبلًا من غير تكرار كود).
 * بيرجع true/false على حسب نجح يبعت ولا لأ، وأي فشل (DM مقفول مثلاً) بيتبلع
 * جوه من غير ما يوقف تنفيذ العملية الأساسية (بان/كيك/... إلخ).
 */
async function sendModDM(member, guild, content) {
  if (!content) return false;
  try {
    await member.send({
      components: [baseEmbed({ title: `رسالة من ${guild.name}`, description: content })],
      flags: V2_FLAGS
    });
    return true;
  } catch {
    return false;
  }
}

module.exports = { reasonSuffix, sendModDM };
