const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data', 'guilds');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// كاش في الميموري عشان نقلل قراءة/كتابة القرص كل شوية (مهم في هوست ضعيف)
const cache = new Map();

function filePath(guildId) {
  return path.join(DATA_DIR, `${guildId}.json`);
}

function defaultData() {
  return {
    prefix: null, // null = يستخدم الديفولت
    settings: {
      allow: {}, // { commandName: [roleId,...] }
      deny: {},  // { commandName: [roleId/userId,...] }
      disabledCommands: [],
      logChannels: {}, // { type: channelId }
      blacklistChannels: [],
      welcome: {
        enabled: true, // تشغيل/تعطيل الويلكم
        mode: 'embed', // 'embed' = رسالة إمبد، 'text' = رسالة عادية + صورة بس
        channelId: null,
        message: null,
        imageUrl: null, // قديم/احتياطي - مش بيتعتمد عليه في الإرسال عشان لينكات الصور بتنتهي صلاحيتها
        imageExt: null, // امتداد الصورة المحفوظة محليًا على السيرفر (jpg/png/gif...) - بتتبعت كمرفق طازة كل مرة عشان تفضل ظاهرة
        dmMessage: null,
        dmEnabled: false
      },
      autorole: null,
      colors: null,
      onlineFakeStatus: false,
      autoClearCategory: null,
      suggestions: { channelId: null },
      infractionsPunishments: {}, // { count: action }
      staffWarnings: {} // { userId: [{reason, mod, modTag, date, id}] }
    },
    tickets: {
      panelChannelId: null,
      panelMessageId: null,
      categoryId: null, // الكاتيجوري اللي هتتفتح فيها روومات التكتات
      counter: 0,
      types: [], // [{id,name,description,emoji,message,adminRoleIds:[]}]
      imageUrl: null,
      menuStyle: 'select', // 'select' أو 'buttons' - شكل لوحة اختيار نوع التكت
      embedDescription: null, // وصف مخصص للوحة التكت
      adminRoleIds: [], // الرولات العامة اللي بتشوف/ترد على كل التكتات أوتوماتيك (بالإضافة لرولات كل نوع لوحده)
      open: {} // { channelId: {number, type, ownerId, claimedBy, locked} }
    },
    tempVoice: {
      waitingChannelId: null,
      categoryId: null,
      trustedRoleId: null,
      untrustedRoleId: null,
      jailRoleId: null,
      soundboardRoleId: null,
      adminRoleIds: [],
      saveSettings: true,
      controlMessage: null,
      rooms: {}, // { voiceChannelId: {ownerId, trusted:[], blocked:[], locked:false, chatClosed:false} }
      userPrefs: {} // { userId: { name, limit, region, locked } }
    },
    leveling: {
      enabled: false,
      channelId: null, // إشعارات اللفل أب
      levelUpMessage: null,
      background: true,
      chatRoles: {}, // { level: roleId }
      voiceRoles: {},
      users: {} // { userId: { chatXp, chatLevel, voiceXp, voiceLevel } }
    },
    autoReplies: {}, // { trigger: response }
    reactionRoles: {}, // { messageId: { emoji: roleId } }
    warnings: {}, // { userId: [ {reason, mod, date} ] }
    points: {}, // { userId: points }
    shop: {
      ranks: [], // [{ roleId, points }] - رتب المتجر (منقول حرفيًا من بوت ١)
      embedText: null,   // نص لوحة المتجر المرسلة في الشات (تخصيص)
      embedImage: null,  // صورة لوحة المتجر
      infoText: null,    // نص صفحة "معلومات"
      infoImage: null,   // صورة صفحة "معلومات"
      generalChannelId: null // شات إشعارات إنجاز المهام (لو DM اتقفل)
    },
    tasks: {
      enabled: false,        // نظام المهام مقفول افتراضيًا
      deletedDaily: [],      // IDs مهام يومية اتشالت
      deletedWeekly: [],     // IDs مهام أسبوعية اتشالت
      customDaily: {},       // { taskId: { points, target } } تعديلات مخصصة
      customWeekly: {},
      users: {} // { userId: { daily: {date, ver, tasks}, weekly: {weekKey, ver, tasks} } }
    },
    infractions: {}, // { userId: { mutes:[], bans:[], prisons:[] } }
    prisoners: {}, // { userId: { savedRoleIds: [...], reason, mod, date, jailed: true } } - بيتفضل موجود حتى لو العضو خرج ودخل تاني عشان نرجعله رولاته الصح ونسجنه أوتوماتيك لو حاول يهرب
    announceEmbeds: {}, // { name: { title, description, image, footer, author, buttons: [{ id, label, emoji, message }] } }
    stickyRoles: {}, // اسم مستقبلي - غير مستخدم حاليًا
    owners: [], // أونرات إضافيين للبوت جوه السيرفر (غير أونر ديسكورد)
    giveaways: {}, // { messageId: { prize, winners, endTime, entries: [], ended, hostId, channelId, guildId } }
    automod: {
      enabled: false,
      logChannel: null,
      whitelistRoles: [],
      whitelistChannels: [],
      filters: {
        spam: { enabled: false, threshold: 5, interval: 5000, action: 'warn' },
        caps: { enabled: false, threshold: 70, action: 'warn' },
        invites: { enabled: false, action: 'delete' },
        links: { enabled: false, action: 'delete' },
        badwords: { enabled: false, words: [], action: 'warn' },
        mentions: { enabled: false, threshold: 5, action: 'warn' }
      },
      actions: { warn: { count: 3, action: 'timeout', duration: 3600000 } }
    },

    afk: {} // { userId: { reason, since, mentions: [{authorTag, timestamp, url}] } }
  };
}

function deepMerge(base, extra) {
  for (const k of Object.keys(extra)) {
    if (
      extra[k] &&
      typeof extra[k] === 'object' &&
      !Array.isArray(extra[k]) &&
      base[k] &&
      typeof base[k] === 'object' &&
      !Array.isArray(base[k])
    ) {
      deepMerge(base[k], extra[k]);
    } else if (!(k in base)) {
      base[k] = extra[k];
    }
  }
  return base;
}

function load(guildId) {
  if (cache.has(guildId)) return cache.get(guildId);
  const fp = filePath(guildId);
  let data;
  if (fs.existsSync(fp)) {
    try {
      data = JSON.parse(fs.readFileSync(fp, 'utf8'));
      data = deepMerge(data, defaultData());
    } catch {
      data = defaultData();
    }
  } else {
    data = defaultData();
  }
  cache.set(guildId, data);
  return data;
}

let saveTimers = new Map();
function save(guildId) {
  // كتابة مؤجلة (debounce) عشان ماتكتبش على القرص كل رسالة - يخفف الحمل على الهوست الضعيف
  if (saveTimers.has(guildId)) clearTimeout(saveTimers.get(guildId));
  const t = setTimeout(() => {
    const data = cache.get(guildId);
    if (!data) return;
    try {
      fs.writeFileSync(filePath(guildId), JSON.stringify(data, null, 2));
    } catch (e) {
      console.error('DB save error:', e);
    }
    saveTimers.delete(guildId);
  }, 1500);
  saveTimers.set(guildId, t);
}

function get(guildId) {
  return load(guildId);
}

function commit(guildId) {
  save(guildId);
}

function flushAll() {
  for (const [guildId, timer] of saveTimers.entries()) {
    clearTimeout(timer);
    saveTimers.delete(guildId);
  }
  for (const [guildId, data] of cache.entries()) {
    try {
      fs.writeFileSync(filePath(guildId), JSON.stringify(data, null, 2));
    } catch (e) {
      console.error('DB flush error:', e);
    }
  }
}

module.exports = { get, commit, flushAll, defaultData };
