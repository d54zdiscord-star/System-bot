const db = require('./db');
const { baseEmbed, V2_FLAGS } = require('./embed');

/*
  معادلة اللفل:
  - كل رسالة (بعد كولداون 60 ثانية) = نقطة واحدة "شات إكس بي"
  - كل دقيقة متصل فويس = نقطة واحدة "فويس إكس بي"
  - عدد النقاط المطلوبة عشان توصل من لفل (n-1) للفل n:
      45n² - 55n + 110
    يعني: لفل 1 = 100 نقطة (100 رسالة/دقيقة)
          لفل 2 = 180 نقطة إضافية (المجموع 280)
          لفل 3 = 350 نقطة إضافية (المجموع 630)
          لفل 4 = 610 نقطة إضافية ... وهكذا (تصاعدي بشكل سلس)
  - نفس المعادلة مستخدمة للفويس كمان (100 دقيقة فويس = لفل 1)
*/

function xpNeededForLevel(level) {
  return 45 * level * level - 55 * level + 110;
}

function totalXpForLevel(level) {
  let total = 0;
  for (let i = 1; i <= level; i++) total += xpNeededForLevel(i);
  return total;
}

function levelFromXp(xp) {
  let level = 0;
  while (xp >= totalXpForLevel(level + 1)) level++;
  return level;
}

// XP اللي داخل اللفل الحالي (مش تراكمي) - ده اللي بيتحط في بار التقدم
function progressInLevel(xp, level) {
  const into = xp - totalXpForLevel(level);
  const needed = xpNeededForLevel(level + 1);
  return { into, needed };
}

function getUserLevelData(guildId, userId) {
  const data = db.get(guildId);
  if (!data.leveling.users[userId]) {
    data.leveling.users[userId] = { chatXp: 0, chatLevel: 0, voiceXp: 0, voiceLevel: 0 };
  }
  return data.leveling.users[userId];
}

// ترتيب العضو بين كل أعضاء السيرفر بالإكس بي (chat أو voice)
function getRank(guildId, userId, type) {
  const data = db.get(guildId);
  const key = type === 'voice' ? 'voiceXp' : 'chatXp';
  const sorted = Object.entries(data.leveling.users)
    .map(([id, u]) => [id, u[key] || 0])
    .sort((a, b) => b[1] - a[1]);
  const idx = sorted.findIndex(([id]) => id === userId);
  return idx === -1 ? sorted.length + 1 : idx + 1;
}

const chatCooldowns = new Map();

async function addChatXp(message) {
  const guildId = message.guild.id;
  const userId = message.author.id;
  const key = `${guildId}-${userId}`;

  const last = chatCooldowns.get(key) || 0;
  if (Date.now() - last < 60_000) return;
  chatCooldowns.set(key, Date.now());

  const data = db.get(guildId);
  const user = getUserLevelData(guildId, userId);
  user.chatXp += 1;

  const newLevel = levelFromXp(user.chatXp);
  if (newLevel > user.chatLevel) {
    user.chatLevel = newLevel;
    await announceLevelUp(message.guild, message.member, 'chat', newLevel, message.channel);
  }
  db.commit(guildId);
}

async function addVoiceXp(guild, member, minutes = 1) {
  const guildId = guild.id;
  const data = db.get(guildId);
  const user = getUserLevelData(guildId, member.id);
  user.voiceXp += minutes;

  const newLevel = levelFromXp(user.voiceXp);
  if (newLevel > user.voiceLevel) {
    user.voiceLevel = newLevel;
    await announceLevelUp(guild, member, 'voice', newLevel, null);
  }
  db.commit(guildId);
}

async function announceLevelUp(guild, member, type, level, fallbackChannel) {
  const data = db.get(guild.id);
  if (!data.leveling.enabled) return;

  const roleMap = type === 'chat' ? data.leveling.chatRoles : data.leveling.voiceRoles;
  if (roleMap && roleMap[level]) {
    const role = guild.roles.cache.get(roleMap[level]);
    if (role) member.roles.add(role).catch(() => {});
  }

  let channel = fallbackChannel;
  if (data.leveling.channelId) {
    channel = guild.channels.cache.get(data.leveling.channelId) || fallbackChannel;
  }
  if (!channel) return;

  const typeLabel = type === 'chat' ? 'CHAT' : 'VOICE';

  try {
    const { renderLevelUpCard } = require('./cards');
    const buffer = await renderLevelUpCard({
      username: member.displayName,
      avatarURL: member.displayAvatarURL({ dynamic: true, size: 128, extension: 'png' }),
      typeLabel,
      oldLevel: level - 1,
      newLevel: level,
      accentColor: type === 'chat' ? '#e3d2a0' : '#a78bfa'
    });
    await channel.send({
      content: `${member}`,
      files: [{ attachment: buffer, name: 'levelup.png' }]
    });
  } catch (e) {
    console.error('فشل رسم كارت اللفل أب:', e);
    // fallback نصي لو فشل رسم الصورة لأي سبب (خط ناقص، مشكلة في المكتبة...)
    const msg = (data.leveling.levelUpMessage || 'مبروك {user}! وصلت لفل **{level}** في {type} 🎉')
      .replace('{user}', `${member}`)
      .replace('{level}', level)
      .replace('{type}', type === 'chat' ? 'الشات' : 'الفويس');
    channel
      .send({ components: [baseEmbed({ description: msg, thumbnail: member.displayAvatarURL({ dynamic: true }) })], flags: V2_FLAGS })
      .catch(() => {});
  }
}

function progressBar(current, needed, size = 14) {
  const ratio = Math.min(current / needed, 1);
  const filled = Math.round(ratio * size);
  return '🟩'.repeat(filled) + '⬜'.repeat(Math.max(size - filled, 0));
}

module.exports = {
  xpNeededForLevel,
  totalXpForLevel,
  levelFromXp,
  progressInLevel,
  getUserLevelData,
  getRank,
  addChatXp,
  addVoiceXp,
  announceLevelUp,
  progressBar
};
