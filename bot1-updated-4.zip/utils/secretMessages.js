// تخزين مؤقت في الميموري لرسايل أمر "مخفي" - بيتخزن بس عشان زرار "عرض" يقدر يجيبها
const store = new Map();
let counter = 0;

function create(senderId, targetId, text) {
  const id = `${Date.now()}-${counter++}`;
  store.set(id, { senderId, targetId, text });
  return id;
}

function get(id) {
  return store.get(id);
}

module.exports = { create, get };
