const {
  joinVoiceChannel,
  getVoiceConnection,
  VoiceConnectionStatus,
  entersState
} = require('@discordjs/voice');

// يدخل البوت الفويس المحدد ويقعد فيه بس (من غير ما يعدل اسمه أو أي حاجة تانية)
function joinVoiceOnlineChannel(channel) {
  const guild = channel.guild;

  // لو فيه اتصال قديم في نفس السيرفر على روم مختلف، اقفله الأول
  const existing = getVoiceConnection(guild.id);
  if (existing && existing.joinConfig.channelId !== channel.id) {
    existing.destroy();
  }

  const connection = joinVoiceChannel({
    channelId: channel.id,
    guildId: guild.id,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: true,
    selfMute: true
  });

  // لو حصل قطع اتصال مؤقت، حاول ترجع تاني بدل ما تسيب الروم
  connection.on(VoiceConnectionStatus.Disconnected, async () => {
    try {
      await Promise.race([
        entersState(connection, VoiceConnectionStatus.Signalling, 5_000),
        entersState(connection, VoiceConnectionStatus.Connecting, 5_000)
      ]);
    } catch {
      connection.destroy();
    }
  });

  return connection;
}

// تستخدم عند تشغيل البوت عشان يرجع يدخل نفس الروم المحفوظة في كل سيرفر
function reconnectAllOnlineChannels(client, db) {
  for (const guild of client.guilds.cache.values()) {
    const data = db.get(guild.id);
    const channelId = data.settings.onlineVoiceChannelId;
    if (!channelId) continue;

    const channel = guild.channels.cache.get(channelId);
    if (!channel) continue;

    try {
      joinVoiceOnlineChannel(channel);
    } catch (e) {
      console.error(`[onlineVoice] فشل الرجوع للفويس في ${guild.name}:`, e.message);
    }
  }
}

module.exports = { joinVoiceOnlineChannel, reconnectAllOnlineChannels };
