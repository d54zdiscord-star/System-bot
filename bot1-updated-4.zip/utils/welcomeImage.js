const fs = require('fs');
const path = require('path');

const DIR = path.join(__dirname, '..', 'data', 'welcome-images');
if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

function extFromContentType(contentType, fallbackName) {
  const map = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' };
  if (contentType && map[contentType]) return map[contentType];
  const m = (fallbackName || '').match(/\.(png|jpe?g|webp|gif)$/i);
  return m ? m[1].toLowerCase().replace('jpeg', 'jpg') : 'png';
}

function pathFor(guildId, ext) {
  return path.join(DIR, `${guildId}.${ext}`);
}

// بيحمل الصورة من رابط المرفق ويحفظها محليًا - عشان روابط مرفقات ديسكورد بتنتهي صلاحيتها
// وبالتالي أي صورة محفوظة كلينك هتبوظ بعد شوية. تخزينها محليًا وإعادة رفعها كمرفق طازة
// كل مرة عضو يدخل هو الحل الوحيد اللي يضمن إنها تفضل ظاهرة على طول.
async function saveWelcomeImage(guildId, attachment) {
  const ext = extFromContentType(attachment.contentType, attachment.name);
  // شيل أي صورة قديمة بامتداد مختلف
  clearWelcomeImage(guildId);
  const res = await fetch(attachment.url);
  const buffer = Buffer.from(await res.arrayBuffer());
  fs.writeFileSync(pathFor(guildId, ext), buffer);
  return ext;
}

function clearWelcomeImage(guildId) {
  for (const file of fs.readdirSync(DIR)) {
    if (file.startsWith(`${guildId}.`)) fs.unlinkSync(path.join(DIR, file));
  }
}

function getWelcomeImageBuffer(guildId, ext) {
  const fp = pathFor(guildId, ext);
  if (!fs.existsSync(fp)) return null;
  return fs.readFileSync(fp);
}

module.exports = { saveWelcomeImage, clearWelcomeImage, getWelcomeImageBuffer };
