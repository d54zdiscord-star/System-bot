const {
  ContainerBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags
} = require('discord.js');
const config = require('../config');

/**
 * نظام الردود بـ Components V2: بديل شفاف بالكامل للإيمبد التقليدي.
 * مفيش خط جانبي (accent color) خالص إلا لو اتحدد صراحة - يعني مفيش
 * الخط الأبيض/الرمادي اللي ديسكورد بيحطه تلقائي على أي إيمبد من غير لون.
 *
 * لو في عنوان (title) ومحتوى بعده (description/fields/صورة) - بيتحط فاصل
 * (separator) بينهم تلقائيًا عشان يدي شكل أنضف ومنظم للرسايل.
 *
 * لازم أي send/reply/update يستخدم الملف ده يحط: flags: V2_FLAGS
 * (أو V2_FLAGS | MessageFlags.Ephemeral لو عايزه ephemeral)
 */

const V2_FLAGS = MessageFlags.IsComponentsV2;

// شيل النقطة والنقطتين (:) من آخر أي نص (طلب: مفيش نقطة/نقطتين في آخر الرسايل)
function stripTrailingDot(text) {
  if (typeof text !== 'string') return text;
  return text.replace(/[.:：]+\s*$/, '');
}

function fieldsToText(fields) {
  return fields
    .map(f => `**${f.name}**\n${stripTrailingDot(f.value ?? '')}`)
    .join('\n\n');
}

function divider() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

/**
 * حاوية (Container) شفافة بديلة للإيمبد القديم.
 * options: { title, description, fields, thumbnail, image, color }
 *
 * لو الرسالة نص بسيط بس (من غير thumbnail/image) بترجع كنص عادي مباشر
 * (TextDisplay من غير Container) - يعني تظهر زي أي رسالة عادية من البوت
 * من غير صندوق ولا خط لوني جانبي، زي "تم تايم أوت الشخص" مثلاً.
 *
 * لو فيها thumbnail/image بتفضل بشكل الكونتينر (بصندوق) عشان تعرض الصورة
 * صح، لأن دي عادةً رسايل عرض مش مجرد تأكيد بسيط.
 */
function baseEmbed(options = {}) {
  // boxed: true بيجبر شكل الكونتينر (خط جانبي ملون + صندوق) حتى من غير صورة -
  // بيتستخدم للرسايل المهمة (إعدادات/معلومات منظمة) اللي محتاجة شكل Embed واضح،
  // من غير ما نضطر نحط صورة وهمية عشانه يطلع بشكل الكونتينر
  const hasMedia = !!(options.thumbnail || options.image || options.boxed);

  if (!hasMedia) {
    const parts = [];
    if (options.title) parts.push(`### ${stripTrailingDot(options.title)}`);
    if (options.description) parts.push(stripTrailingDot(options.description));
    if (options.fields && options.fields.length) parts.push(fieldsToText(options.fields));
    if (!parts.length) parts.push('\u200b');
    return new TextDisplayBuilder().setContent(parts.join('\n\n'));
  }

  const container = new ContainerBuilder();
  const color = options.color ?? config.embedColor;
  if (color !== null && color !== undefined) container.setAccentColor(color);

  const hasTitle = !!options.title;
  const hasDescription = !!options.description;
  const hasFields = !!(options.fields && options.fields.length);

  // كل عنصر هنا دالة بترجع الـ component المناسب - بيتحطوا في الكونتينر
  // بالترتيب مع فاصل بين كل واحد واللي بعده
  const blocks = [];

  if (hasTitle) {
    const titleText = `### ${stripTrailingDot(options.title)}`;
    if (options.thumbnail && !hasDescription) {
      blocks.push(() =>
        container.addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(titleText))
            .setThumbnailAccessory(new ThumbnailBuilder().setURL(options.thumbnail))
        )
      );
    } else {
      blocks.push(() => container.addTextDisplayComponents(new TextDisplayBuilder().setContent(titleText)));
    }
  }

  if (hasDescription) {
    const descText = hasTitle ? stripTrailingDot(options.description) : `**${stripTrailingDot(options.description)}**`;
    if (options.thumbnail) {
      blocks.push(() =>
        container.addSectionComponents(
          new SectionBuilder()
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(descText))
            .setThumbnailAccessory(new ThumbnailBuilder().setURL(options.thumbnail))
        )
      );
    } else {
      blocks.push(() =>
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(descText))
      );
    }
  } else if (options.thumbnail && !hasTitle) {
    blocks.push(() =>
      container.addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(options.thumbnail))
      )
    );
  }

  if (hasFields) {
    blocks.push(() => container.addTextDisplayComponents(new TextDisplayBuilder().setContent(fieldsToText(options.fields))));
  }

  if (options.image) {
    blocks.push(() =>
      container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(options.image)))
    );
  }

  if (!blocks.length) {
    blocks.push(() => container.addTextDisplayComponents(new TextDisplayBuilder().setContent('\u200b')));
  }

  blocks.forEach(addBlock => {
    addBlock();
    // فاصل بعد كل جزء - حتى لو الرسالة جزء واحد بس (طلب: الفاصل يظهر في كل رسالة)
    container.addSeparatorComponents(divider());
  });

  return container;
}

function successEmbed(description, extra = {}) {
  return baseEmbed({ description: `<:true:1533733814105407619> ${description}`, ...extra });
}

function errorEmbed(description, extra = {}) {
  return baseEmbed({ description: `<:fals:1533733827900473366> ${description}`, ...extra });
}

// رسالة استخدام مختصرة ومباشرة - مجرد صيغة الأمر من غير شرح زائد ولا وصف مكرر
function usageEmbed(prefix, cmd, extra = {}) {
  return baseEmbed({
    description: `**الاستخدام:** \`${prefix}${cmd.name} ${cmd.usage || ''}\``,
    ...extra
  });
}

function warningEmbed(description, extra = {}) {
  return baseEmbed({ description: `${config.emojis.warning} ${description}`, ...extra });
}

// كونتينر نص بسيط - بديل سريع لأي حالة كانت بتستخدم content بس (زي @everyone)
function textDisplay(content) {
  return new TextDisplayBuilder().setContent(content);
}

/**
 * كونتينر بشكل "عنوان بارز + فاصل + تفاصيل باهتة تحته" - نفس شكل رسايل
 * الـ AFK (welcome back / is now AFK...). بيستخدم "-# " عشان النص يظهر
 * صغير وباهت (subtext) زي المطلوب.
 * header: سطر أو أسطر (Array) بولد/عادي - بتتحط زي ما هي.
 * details: سطر أو أسطر (Array) هتتحط باهتة تحت الفاصل.
 */
function sectionedContainer(header, details, options = {}) {
  const container = new ContainerBuilder();
  const color = options.color ?? config.embedColor;
  if (color !== null && color !== undefined) container.setAccentColor(color);

  const headerLines = Array.isArray(header) ? header : [header];
  container.addTextDisplayComponents(new TextDisplayBuilder().setContent(headerLines.join('\n')));

  const detailLines = Array.isArray(details) ? details : details ? [details] : [];
  if (detailLines.length) {
    container.addSeparatorComponents(divider());
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(detailLines.map(l => (l ? `-# ${l}` : '')).join('\n'))
    );
  }
  // فاصل ختامي - نفس نظام baseEmbed (الفاصل يظهر في كل رسالة حتى لو جزء واحد بس)
  container.addSeparatorComponents(divider());

  return container;
}

module.exports = {
  baseEmbed,
  successEmbed,
  errorEmbed,
  warningEmbed,
  usageEmbed,
  textDisplay,
  sectionedContainer,
  V2_FLAGS
};
