const {
  ChannelType,
  PermissionsBitField,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ActionRowBuilder,
  AttachmentBuilder
} = require('discord.js');
const db = require('./db');
const { baseEmbed, textDisplay, V2_FLAGS } = require('./embed');
const { button, row, ButtonStyle } = require('./components');
const config = require('../config');
const { buildTranscriptMessages, generateTranscriptHTML } = require('./ticketTranscript');

function ticketControlRow(channelId) {
  return row(
    button(`ticket_mentionmember_${channelId}`, 'منشن الميمبر', ButtonStyle.Secondary, '👤'),
    button(`ticket_lock_${channelId}`, 'قفل', ButtonStyle.Danger, '🔒')
  );
}

function ticketControlRow1b(channelId) {
  return row(button(`ticket_mentionadmin_${channelId}`, 'منشن الإدارة', ButtonStyle.Secondary, '🛡️'));
}

function ticketControlRow2(channelId) {
  return row(
    button(`ticket_addmember_${channelId}`, 'إضافة ميمبر', ButtonStyle.Success, '➕'),
    button(`ticket_removemember_${channelId}`, 'إزالة ميمبر', ButtonStyle.Danger, '➖')
  );
}

function buildPanelSelectMenu(types) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId('ticket_select')
    .setPlaceholder('اختار نوع التكت...')
    .addOptions(
      types.map(t => ({
        label: t.name,
        description: t.description || undefined,
        value: t.id,
        emoji: t.emoji || undefined
      }))
    );
  return new ActionRowBuilder().addComponents(menu);
}

// ─── بناء لوحة تكتات بشكل أزرار (بديل القائمة المنسدلة) - منقول من بوت ١ ───
function buildPanelButtons(types) {
  const rows = [];
  for (let i = 0; i < types.length; i += 5) {
    const rowBtns = new ActionRowBuilder();
    types.slice(i, i + 5).forEach(t => {
      const btn = new ButtonBuilder().setCustomId(`ticket_open_${t.id}`).setLabel(t.name).setStyle(ButtonStyle.Secondary);
      if (t.emoji) btn.setEmoji(t.emoji);
      rowBtns.addComponents(btn);
    });
    rows.push(rowBtns);
  }
  return rows;
}

async function createTicket(interactionOrMessage, guild, member, typeId) {
  const data = db.get(guild.id);
  const type = data.tickets.types.find(t => t.id === typeId);
  if (!type) return null;

  data.tickets.counter += 1;
  const number = data.tickets.counter;

  // الرولات الإدارية = الرولات العامة (ticketadmins) + رولات النوع نفسه (لو موجودة) - من غير تكرار
  const roleIds = [...new Set([...(data.tickets.adminRoleIds || []), ...(type.adminRoleIds || [])])];

  const overwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
    {
      id: member.id,
      allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ReadMessageHistory
      ]
    },
    {
      id: guild.members.me.id,
      allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ManageChannels]
    },
    // بنتأكد إن الرول لسه موجود في السيرفر - لو اتحذف وفضل رقمه محفوظ في القاعدة،
    // guild.channels.create كان بيرمي خطأ "Unknown Role" ويفشل إنشاء التيكت بالكامل بصمت
    ...roleIds
      .filter(roleId => guild.roles.cache.has(roleId))
      .map(roleId => ({
        id: roleId,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
          PermissionsBitField.Flags.AttachFiles,
          PermissionsBitField.Flags.EmbedLinks
        ]
      }))
  ];

  // نتأكد إن الكاتيجوري لسه موجودة قبل ما نستخدمها (زي التحقق من الرولات فوق)
  const parentId = data.tickets.categoryId && guild.channels.cache.has(data.tickets.categoryId) ? data.tickets.categoryId : undefined;

  const channel = await guild.channels.create({
    name: `ticket-${number}`,
    type: ChannelType.GuildText,
    parent: parentId,
    permissionOverwrites: overwrites,
    topic: `تكت #${number} - ${type.name} | صاحب التكت: ${member.id}`
  });

  data.tickets.open[channel.id] = {
    number,
    type: type.name,
    ownerId: member.id,
    claimedBy: null,
    locked: false,
    createdAt: Date.now()
  };
  db.commit(guild.id);

  sendTicketLog(guild, 'open', { channel, number, type: type.name, userId: member.id });

  const embed = baseEmbed({
    title: `${config.emojis.ticket} تكت #${number}`,
    fields: [
      { name: 'نوع التكت', value: type.name, inline: true },
      { name: 'بواسطة', value: `${member}`, inline: true }
    ],
    thumbnail: data.tickets.imageUrl || undefined
  });

  await channel.send({
    components: [
      textDisplay(`${member}`),
      embed,
      ticketControlRow(channel.id),
      ticketControlRow1b(channel.id),
      ticketControlRow2(channel.id)
    ],
    flags: V2_FLAGS
  });

  return channel;
}

// ─── لوج فتح/قفل/حذف التكت (بنفس شكل إمبد باقي البوت - Components V2) ───
async function sendTicketLog(guild, type, payload) {
  const data = db.get(guild.id);
  const logsChannel = data.settings.logChannels?.ticket ? guild.channels.cache.get(data.settings.logChannels.ticket) : null;
  if (!logsChannel) return;

  try {
    if (type === 'open') {
      const { channel, number, type: typeName, userId } = payload;
      await logsChannel.send({
        components: [baseEmbed({
          title: 'تم فتح تذكرة جديدة',
          fields: [
            { name: 'الشخص', value: `<@${userId}>`, inline: true },
            { name: 'القسم', value: typeName, inline: true },
            { name: 'الروم', value: `<#${channel.id}>`, inline: true }
          ]
        })],
        flags: V2_FLAGS,
        allowedMentions: { parse: [] }
      });
      return;
    }

    if (type === 'close') {
      const { channel, ticketInfo, userId } = payload;
      const messages = await buildTranscriptMessages(channel);
      const html = generateTranscriptHTML(messages, ticketInfo, channel.name);
      const fileName = `transcript-${channel.name}-${Date.now()}.html`;
      const htmlFile = new AttachmentBuilder(Buffer.from(html, 'utf8'), { name: fileName });

      const fileMsg = await logsChannel.send({ content: '_ _', files: [htmlFile] });
      const attachUrl = fileMsg.attachments.first()?.url;

      const components = [baseEmbed({
        title: 'تم قفل التذكرة',
        fields: [
          { name: 'الشخص', value: `<@${userId}>`, inline: true },
          { name: 'القسم', value: ticketInfo?.type || 'غير محدد', inline: true },
          { name: 'الروم', value: `<#${channel.id}>`, inline: true }
        ]
      })];
      if (attachUrl) {
        components.push(new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('فتح الترانسكريبت').setStyle(ButtonStyle.Link).setURL(attachUrl)));
      }
      await logsChannel.send({ components, flags: V2_FLAGS, allowedMentions: { parse: [] } });
      return;
    }

    if (type === 'delete') {
      const { channel, ticketInfo, userId } = payload;
      await logsChannel.send({
        components: [baseEmbed({
          title: 'تم حذف التذكرة',
          fields: [
            { name: 'الحاذف', value: `<@${userId}>`, inline: true },
            { name: 'الروم', value: channel.name, inline: true },
            { name: 'القسم', value: ticketInfo?.type || 'غير محدد', inline: true },
            { name: 'الشخص', value: `<@${ticketInfo?.ownerId}>`, inline: true },
            { name: 'وقت الحذف', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
          ]
        })],
        flags: V2_FLAGS,
        allowedMentions: { parse: [] }
      });
      return;
    }
  } catch (e) {
    console.error('[ticket log] error:', e.message);
  }
}

module.exports = { ticketControlRow, ticketControlRow1b, ticketControlRow2, buildPanelSelectMenu, buildPanelButtons, createTicket, sendTicketLog };
