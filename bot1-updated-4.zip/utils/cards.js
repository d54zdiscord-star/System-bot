const { createCanvas, loadImage } = require('@napi-rs/canvas');
const { fontFamily } = require('./fonts');

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

async function loadAvatar(url) {
  try {
    const res = await fetch(url);
    const buf = Buffer.from(await res.arrayBuffer());
    return await loadImage(buf);
  } catch {
    return null;
  }
}

function drawAvatarCircle(ctx, img, cx, cy, r) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();
  if (img) {
    ctx.drawImage(img, cx - r, cy - r, r * 2, r * 2);
  } else {
    ctx.fillStyle = '#2b2b33';
    ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  }
  ctx.restore();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(255,255,255,0.15)';
  ctx.lineWidth = 3;
  ctx.stroke();
}

function drawBar(ctx, x, y, w, h, ratio, colorFrom, colorTo) {
  roundRect(ctx, x, y, w, h, h / 2);
  ctx.fillStyle = '#232329';
  ctx.fill();

  const filledW = Math.max(Math.min(ratio, 1) * w, ratio > 0 ? h : 0);
  if (filledW > 0) {
    const grad = ctx.createLinearGradient(x, 0, x + w, 0);
    grad.addColorStop(0, colorFrom);
    grad.addColorStop(1, colorTo);
    roundRect(ctx, x, y, filledW, h, h / 2);
    ctx.fillStyle = grad;
    ctx.fill();
  }
}

/**
 * كارت الرانك (!rank) - بشكل شات + فويس زي الصورة المرجعية.
 * data: { chatLevel, chatXp, voiceLevel, voiceXp }
 * chatNeeded / voiceNeeded: الإكس بي المطلوب للفل الجاي
 * chatRank / voiceRank: ترتيب العضو بين أعضاء السيرفر
 */
async function renderRankCard({ username, avatarURL, chatLevel, chatXp, chatNeeded, chatRank, voiceLevel, voiceXp, voiceNeeded, voiceTotalMinutes, voiceRank }) {
  const W = 900;
  const H = 360;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // خلفية
  roundRect(ctx, 0, 0, W, H, 28);
  ctx.fillStyle = '#0c0c10';
  ctx.fill();

  // أفاتار
  const avatarImg = await loadAvatar(avatarURL);
  const cx = 150;
  const cy = H / 2;
  const r = 95;
  drawAvatarCircle(ctx, avatarImg, cx, cy, r);

  const bodyX = 280;
  const rightEdge = W - 40;

  // اسم اليوزر
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold 38px "${fontFamily('Bold')}"`;
  ctx.fillText(username, bodyX, 60);

  function section(label, level, xp, needed, rank, y, colorFrom, colorTo, extraFooter) {
    // العنوان + LEVEL/RANK في نفس السطر
    ctx.textAlign = 'left';
    ctx.font = `bold 16px "${fontFamily('Bold')}"`;
    ctx.fillStyle = '#9a9aa3';
    ctx.fillText(label, bodyX, y);

    ctx.textAlign = 'right';
    ctx.font = `13px "${fontFamily('Regular')}"`;
    ctx.fillStyle = '#9a9aa3';
    ctx.fillText('LEVEL', rightEdge - 100, y);
    ctx.fillText('RANK', rightEdge, y);

    // الأرقام (فاصل كبير عن السطر اللي فوق عشان الخط العربي متطلعش متراكبة)
    const numbersY = y + 38;
    ctx.font = `bold 26px "${fontFamily('Bold')}"`;
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`${level}`, rightEdge - 100, numbersY);
    ctx.fillText(`${rank}`, rightEdge, numbersY);

    // البار (فاصل كبير عن الأرقام)
    const barY = numbersY + 22;
    const barW = rightEdge - bodyX;
    drawBar(ctx, bodyX, barY, barW, 14, needed > 0 ? xp / needed : 0, colorFrom, colorTo);

    // تحت البار
    const footerY = barY + 40;
    ctx.font = `13px "${fontFamily('Regular')}"`;
    ctx.fillStyle = '#8b8b94';
    ctx.textAlign = 'left';
    ctx.fillText(`${level} -> ${level + 1}`, bodyX, footerY);
    ctx.textAlign = 'right';
    ctx.fillText(`${xp.toLocaleString()} / ${needed.toLocaleString()} XP`, rightEdge, footerY);

    if (extraFooter) {
      ctx.textAlign = 'left';
      ctx.fillStyle = '#6b6b73';
      ctx.font = `12px "${fontFamily('Regular')}"`;
      ctx.fillText(extraFooter, bodyX, footerY + 20);
    }
  }

  const totalMinutes = voiceTotalMinutes ?? voiceXp;
  const voiceHours = Math.floor(totalMinutes / 60);
  const voiceMinutes = Math.round(totalMinutes % 60);

  section('CHAT', chatLevel, chatXp, chatNeeded, chatRank, 90, '#8a6a3f', '#e3d2a0', null);
  section('VOICE', voiceLevel, voiceXp, voiceNeeded, voiceRank, 215, '#c9c9d1', '#ffffff', `${voiceHours}h ${voiceMinutes}m`);

  return canvas.toBuffer('image/png');
}

/**
 * كارت اللفل أب - كارت صغير بشكل عنوان + "LEVEL UP!" + اللفل القديم/الجديد.
 */
async function renderLevelUpCard({ username, avatarURL, typeLabel, oldLevel, newLevel, accentColor = '#a78bfa' }) {
  const W = 460;
  const H = 140;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  roundRect(ctx, 0, 0, W, H, 22);
  ctx.fillStyle = '#15151a';
  ctx.fill();

  const avatarImg = await loadAvatar(avatarURL);
  ctx.save();
  roundRect(ctx, 20, 20, 70, 70, 14);
  ctx.clip();
  if (avatarImg) {
    ctx.drawImage(avatarImg, 20, 20, 70, 70);
  } else {
    ctx.fillStyle = '#2b2b33';
    ctx.fillRect(20, 20, 70, 70);
  }
  ctx.restore();

  ctx.textAlign = 'left';
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold 24px "${fontFamily('Bold')}"`;
  ctx.fillText(username, 106, 48);

  ctx.fillStyle = accentColor;
  ctx.font = `bold 14px "${fontFamily('Bold')}"`;
  ctx.fillText(`• LEVEL UP! •  ${typeLabel}`, 106, 72);

  // خط فاصل
  ctx.strokeStyle = 'rgba(255,255,255,0.08)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(20, 100);
  ctx.lineTo(W - 20, 100);
  ctx.stroke();

  ctx.fillStyle = '#9a9aa3';
  ctx.font = `13px "${fontFamily('Regular')}"`;
  ctx.fillText('LEVEL', 20, 124);

  ctx.fillStyle = '#ffffff';
  ctx.font = `bold 24px "${fontFamily('Bold')}"`;
  ctx.fillText(`${oldLevel} -> ${newLevel}`, 90, 128);

  return canvas.toBuffer('image/png');
}

/**
 * كارت بروفايل المتجر (زر "بروفايلي") - منقول حرفيًا من بوت ١.
 * data: { username, avatarURL, points, voiceHours, voiceMinutes, dailyDone, dailyTotal,
 *         weeklyDone, weeklyTotal, dailyTasks: [{text, done, progress, target, points}] }
 */
async function renderShopProfileCard(data) {
  const {
    username, avatarURL, points,
    voiceHours = 0, voiceMinutes = 0,
    dailyDone = 0, dailyTotal = 5,
    weeklyDone = 0, weeklyTotal = 3,
    dailyTasks = []
  } = data;

  const F = fontFamily('Regular');
  const FB = fontFamily('Bold');
  const W = 920, H = 480;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // خلفية سوداء متدرجة
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, W, H);

  const grad = ctx.createLinearGradient(W, 0, 0, H);
  grad.addColorStop(0, 'rgba(255,255,255,0.08)');
  grad.addColorStop(0.45, 'rgba(150,150,150,0.04)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);

  const glow1 = ctx.createRadialGradient(W - 80, 70, 0, W - 80, 70, 250);
  glow1.addColorStop(0, 'rgba(220,220,220,0.07)');
  glow1.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = glow1;
  ctx.fillRect(0, 0, W, H);

  const glow2 = ctx.createRadialGradient(90, H - 60, 0, 90, H - 60, 200);
  glow2.addColorStop(0, 'rgba(180,180,180,0.05)');
  glow2.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = glow2;
  ctx.fillRect(0, 0, W, H);

  ctx.strokeStyle = 'rgba(255,255,255,0.07)';
  ctx.lineWidth = 1.5;
  roundRect(ctx, 10, 10, W - 20, H - 20, 22);
  ctx.stroke();

  // أفاتار
  const AX = 105, AY = 145, AR = 88;
  const avatarImg = await loadAvatar(avatarURL);
  drawAvatarCircle(ctx, avatarImg, AX, AY, AR);

  ctx.strokeStyle = 'rgba(255,255,255,0.18)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(AX, AY, AR + 5, 0, Math.PI * 2);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(100,100,100,0.2)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(AX, AY, AR + 12, 0, Math.PI * 2);
  ctx.stroke();

  ctx.fillStyle = 'rgba(255,255,255,0.45)';
  ctx.font = `20px "${F}"`;
  ctx.textAlign = 'center';
  ctx.fillText('♛', AX, AY - AR - 12);

  ctx.fillStyle = '#ffffff';
  ctx.font = `bold 21px "${FB}"`;
  ctx.fillText(username, AX, AY + AR + 26);

  // خط فاصل عمودي
  const lineX = 216;
  const lg = ctx.createLinearGradient(lineX, 30, lineX, H - 30);
  lg.addColorStop(0, 'rgba(255,255,255,0)');
  lg.addColorStop(0.3, 'rgba(255,255,255,0.10)');
  lg.addColorStop(0.7, 'rgba(255,255,255,0.10)');
  lg.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.strokeStyle = lg;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(lineX, 30);
  ctx.lineTo(lineX, H - 30);
  ctx.stroke();

  // بطاقات الإحصائيات
  const cards = [
    { label: 'النقاط', val: String(points), sub: 'Points' },
    { label: 'الفويس', val: `${voiceHours}س ${voiceMinutes}د`, sub: 'Voice Time' },
    { label: 'اليومية', val: `${dailyDone}/${dailyTotal}`, sub: 'Daily' },
    { label: 'الأسبوعية', val: `${weeklyDone}/${weeklyTotal}`, sub: 'Weekly' }
  ];

  const cStartX = 238, cY = 28, cW = 155, cH = 108, cGap = 13;
  cards.forEach((c, i) => {
    const x = cStartX + i * (cW + cGap);
    const cg = ctx.createLinearGradient(x, cY, x, cY + cH);
    cg.addColorStop(0, 'rgba(255,255,255,0.055)');
    cg.addColorStop(1, 'rgba(0,0,0,0.25)');
    ctx.fillStyle = cg;
    roundRect(ctx, x, cY, cW, cH, 14);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.07)';
    ctx.lineWidth = 1;
    roundRect(ctx, x, cY, cW, cH, 14);
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = `bold 26px "${FB}"`;
    ctx.textAlign = 'center';
    ctx.fillText(c.val, x + cW / 2, cY + 50);
    ctx.fillStyle = 'rgba(200,200,200,0.65)';
    ctx.font = `12px "${F}"`;
    ctx.fillText(c.label, x + cW / 2, cY + 74);
    ctx.fillStyle = 'rgba(110,110,110,0.5)';
    ctx.font = `10px "${F}"`;
    ctx.fillText(c.sub, x + cW / 2, cY + 92);
  });

  // منطقة المهام اليومية
  const listX = 238, listY = 158, listW = W - listX - 22, listH = H - listY - 22;

  ctx.fillStyle = 'rgba(255,255,255,0.025)';
  roundRect(ctx, listX, listY, listW, listH, 14);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.05)';
  ctx.lineWidth = 1;
  roundRect(ctx, listX, listY, listW, listH, 14);
  ctx.stroke();

  ctx.fillStyle = 'rgba(255,255,255,0.35)';
  ctx.font = `bold 12px "${FB}"`;
  ctx.textAlign = 'left';
  ctx.fillText('▸  المهام اليومية', listX + 16, listY + 22);

  ctx.strokeStyle = 'rgba(255,255,255,0.05)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(listX + 10, listY + 30);
  ctx.lineTo(listX + listW - 10, listY + 30);
  ctx.stroke();

  const rowH = (listH - 38) / 5;
  dailyTasks.slice(0, 5).forEach((t, i) => {
    const rowY = listY + 36 + i * rowH;
    const done = t.done;

    ctx.fillStyle = done ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.15)';
    roundRect(ctx, listX + 10, rowY + 2, listW - 20, rowH - 6, 8);
    ctx.fill();

    ctx.font = `13px "${F}"`;
    ctx.fillStyle = done ? 'rgba(255,255,255,0.7)' : 'rgba(80,80,80,0.9)';
    ctx.textAlign = 'left';
    ctx.fillText(done ? '✓' : '○', listX + 22, rowY + rowH / 2 + 5);

    const raw = t.text.replace(/\*\*/g, '');
    ctx.fillStyle = done ? 'rgba(140,140,140,0.6)' : 'rgba(210,210,210,0.9)';
    ctx.font = done ? `10px "${F}"` : `bold 10px "${FB}"`;
    const maxTW = listW - 130;
    let txt = raw;
    while (ctx.measureText(txt).width > maxTW && txt.length > 4) txt = txt.slice(0, -1);
    if (txt !== raw) txt += '…';
    ctx.fillText(txt, listX + 42, rowY + rowH / 2 + 5);

    ctx.fillStyle = done ? 'rgba(100,100,100,0.5)' : 'rgba(190,190,190,0.55)';
    ctx.font = `bold 9px "${FB}"`;
    ctx.textAlign = 'right';
    ctx.fillText(`+${t.points}pts`, listX + listW - 16, rowY + rowH / 2 + 5);

    const bX = listX + 42, bY = rowY + rowH - 10, bW = listW - 70, bH = 2;
    ctx.fillStyle = 'rgba(255,255,255,0.05)';
    roundRect(ctx, bX, bY, bW, bH, 1);
    ctx.fill();
    const pct = done ? 1 : Math.min((t.progress || 0) / t.target, 1);
    if (pct > 0) {
      ctx.fillStyle = done ? 'rgba(200,200,200,0.35)' : 'rgba(255,255,255,0.22)';
      roundRect(ctx, bX, bY, bW * pct, bH, 1);
      ctx.fill();
    }
  });

  ctx.fillStyle = 'rgba(60,60,60,0.8)';
  ctx.font = `10px "${F}"`;
  ctx.textAlign = 'right';
  ctx.fillText(new Date().toLocaleDateString('ar-EG'), W - 22, H - 16);

  return canvas.toBuffer('image/png');
}

module.exports = { renderRankCard, renderLevelUpCard, renderShopProfileCard, loadAvatar, roundRect };
