const { ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');

function button(customId, label, style = ButtonStyle.Secondary, emoji = null) {
  const b = new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);
  if (emoji) b.setEmoji(emoji);
  return b;
}

function row(...components) {
  return new ActionRowBuilder().addComponents(...components);
}

module.exports = { button, row, ButtonStyle };
