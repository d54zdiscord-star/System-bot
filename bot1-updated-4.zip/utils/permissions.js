const db = require('./db');
const config = require('../config');

function isGuildOwner(member) {
  return member.guild.ownerId === member.id;
}

function isBotDeveloper(userId) {
  return config.botDevelopers.includes(userId);
}

function isBotOwnerInGuild(member) {
  if (isGuildOwner(member)) return true;
  if (isBotDeveloper(member.id)) return true;
  const data = db.get(member.guild.id);
  return data.owners.includes(member.id);
}

/**
 * يتحقق هل العضو مسموح له يستخدم أمر معين بناءً على:
 * 1. لو أونر بوت/سيرفر -> مسموح دايمًا
 * 2. لو الأمر معطل في السيرفر (locomnd) -> ممنوع للكل غير الأونرات
 * 3. قائمة deny (لو العضو أو أحد روله فيها) -> ممنوع
 * 4. لو الأمر ownerOnly -> لازم يكون أونر
 * 5. لو الأمر permissions (صلاحيات ديسكورد) موجودة ومعندوش -> يتشاف allow list الأول
 */
function canUseCommand(member, command) {
  if (isBotOwnerInGuild(member)) return true;

  const data = db.get(member.guild.id);

  if (data.settings.disabledCommands.includes(command.name)) return false;

  const denyList = data.settings.deny[command.name] || [];
  const memberRoleIds = member.roles.cache.map(r => r.id);
  if (denyList.includes(member.id) || denyList.some(id => memberRoleIds.includes(id))) {
    return false;
  }

  if (command.ownerOnly) return false;

  const allowList = data.settings.allow[command.name] || [];
  const explicitlyAllowed =
    allowList.includes(member.id) || allowList.some(id => memberRoleIds.includes(id));

  if (command.permissions && command.permissions.length > 0) {
    const hasPerms = member.permissions.has(command.permissions);
    return hasPerms || explicitlyAllowed;
  }

  return true;
}

/**
 * نظام رقابة: يمنع العضو إنه يدي رول أعلى من أعلى رول عنده هو،
 * وكمان يمنع إعطاء رول أعلى من أعلى رول عند البوت (البوت مش هيقدر أصلاً ينفذها).
 * بيرجع { allowed: bool, reason: string }
 */
function canAssignRole(actorMember, role) {
  if (isGuildOwner(actorMember) || isBotDeveloper(actorMember.id)) {
    const botMember = actorMember.guild.members.me;
    if (botMember && role.position >= botMember.roles.highest.position) {
      return { allowed: false, reason: 'البوت معندوش صلاحية يدي رول أعلى من أعلى رول عنده.' };
    }
    return { allowed: true };
  }

  const actorHighest = actorMember.roles.highest;
  if (role.position >= actorHighest.position) {
    return { allowed: false, reason: 'متقدرش تدي رول أعلى من (أو مساوي لـ) أعلى رول عندك.' };
  }

  const botMember = actorMember.guild.members.me;
  if (botMember && role.position >= botMember.roles.highest.position) {
    return { allowed: false, reason: 'البوت معندوش صلاحية يدي رول أعلى من أعلى رول عنده.' };
  }

  return { allowed: true };
}

module.exports = { isGuildOwner, isBotDeveloper, isBotOwnerInGuild, canUseCommand, canAssignRole };
