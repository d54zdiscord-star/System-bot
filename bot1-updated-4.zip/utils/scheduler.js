function startScheduler(client) {
  // ملحوظة: اتشال منها تعديل اسم روم "الأونلاين" - البوت بقى بس يدخل يقعد في الروم
  // من غير ما يغير اسمها أو يعمل فيها أي حاجة تانية.
}

module.exports = startScheduler;
