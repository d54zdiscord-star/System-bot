const fs = require('fs');
const path = require('path');
const { GlobalFonts } = require('@napi-rs/canvas');

const FONTS_DIR = path.join(__dirname, '..', 'assets', 'fonts');

let registered = false;
let hasCustomFont = false;

/**
 * بيسجل أي خط .ttf/.otf موجود في assets/fonts عشان يستخدم في كروت
 * الرانك ولفل أب (utils/cards.js). لازم يتنادى مرة وقت بدء تشغيل البوت.
 */
function registerFonts() {
  if (registered) return hasCustomFont;
  registered = true;

  if (!fs.existsSync(FONTS_DIR)) return false;

  const files = fs.readdirSync(FONTS_DIR).filter(f => /\.(ttf|otf)$/i.test(f));
  for (const file of files) {
    try {
      GlobalFonts.registerFromPath(path.join(FONTS_DIR, file), path.parse(file).name);
      hasCustomFont = true;
    } catch (e) {
      console.error(`فشل تحميل الخط ${file}:`, e.message);
    }
  }

  if (!hasCustomFont) {
    console.warn(
      '⚠️ مفيش خط عربي متسجل في assets/fonts - الأسماء العربية ممكن ماتظهرش صح في كروت الرانك/لفل أب. راجع assets/fonts/README.md'
    );
  }

  return hasCustomFont;
}

// اسم الخط اللي هنستخدمه في الرسم - بيرجع اسم الخط المسجل لو موجود، أو fallback عادي
function fontFamily(weight = 'Regular') {
  return hasCustomFont ? weight : 'sans-serif';
}

module.exports = { registerFonts, fontFamily };
